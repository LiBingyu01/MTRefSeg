# # Task 0: NS Val
bash scripts/eval_change.sh \
    "pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    NS_FINAL_CLEAN_val \
    0,1,2,3

# # Task 1: RS
bash scripts/eval_change.sh \
    "pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    RS_FINAL_CLEAN_val \
    0 # ,1,2,3

# Task 2: TC
bash scripts/eval_change.sh \
    "pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    val_FINAL_CLEAN \
    0 #,1,2,3