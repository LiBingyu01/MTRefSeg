# Task 0: NS
bash scripts/eval_change.sh \
    "checkpoint/train_change_ns" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    NS_FINAL_CLEAN_val \
    0 \
    2>&1 | tee eval_train_change_ns.log

# Task 1: RS
bash scripts/eval_change.sh \
    "checkpoint/train_change_rs" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    RS_FINAL_CLEAN_val \
    0 \
    2>&1 | tee eval_train_change_rs.log

# Task 2: TV
bash scripts/eval_change.sh \
    "checkpoint/train_change_train_val" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    val_FINAL_CLEAN \
    0 \
    2>&1 | tee eval_train_change_train_val.log