# Task 0: NS Val
bash scripts/eval_change.sh \
    "pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    NS_FINAL_CLEAN_val \
    0 \
    2>&1 | tee eval_NS_SegEarth-R1-RRSIS-D.log

# Task 1: RS
bash scripts/eval_change.sh \
    "pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    RS_FINAL_CLEAN_val \
    0 \
    2>&1 | tee eval_RS_SegEarth-R1-RRSIS-D.log

# Task 2: TV
bash scripts/eval_change.sh \
    "pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/lby_data01/zhaozy/lby/ChangeRef_Clear" \
    val_FINAL_CLEAN \
    0 \
    2>&1 | tee eval_TV_SegEarth-R1-RRSIS-D.log