#!/bin/bash
# scripts/train_all.sh - 按新版 ChangeRef_Clear 数据结构运行三组变化检测训练实验
# 三组实验：
#   1) train_FINAL_CLEAN     -> val_FINAL_CLEAN
#   2) RS_FINAL_CLEAN_train -> NS_FINAL_CLEAN_val
#   3) NS_FINAL_CLEAN_train -> RS_FINAL_CLEAN_val

set -e

export WANDB_DISABLED=True
export HF_ENDPOINT="https://hf-mirror.com"

# ============================================================
# Project root
# ============================================================
PROJECT_ROOT="/lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/SegEarth-R1-main-down"
cd "${PROJECT_ROOT}"

# ============================================================
# Dataset root
# ============================================================
DATA_ROOT="/lby_data01/zhaozy/lby/ChangeRef_Clear"

# 1) Standard train -> val
TRAIN_FINAL="${DATA_ROOT}/train_FINAL_CLEAN"
VAL_FINAL="${DATA_ROOT}/val_FINAL_CLEAN"

# 2) RS train -> NS val
RS_TRAIN="${DATA_ROOT}/RS_FINAL_CLEAN_train"
RS_VAL="${DATA_ROOT}/RS_FINAL_CLEAN_val"

# 3) NS train -> RS val
NS_TRAIN="${DATA_ROOT}/NS_FINAL_CLEAN_train"
NS_VAL="${DATA_ROOT}/NS_FINAL_CLEAN_val"

# ============================================================
# Pretrained weights
# ============================================================
MODEL="${PROJECT_ROOT}/pretrained_weights/phi-1_5_dev"
VISION_TOWER="${PROJECT_ROOT}/pretrained_weights/model_final_9d7f02.pkl"

# ============================================================
# GPUs
# ============================================================
GPUS="0,1,2,3"

# ============================================================
# Sanity check
# ============================================================
echo "============================================================"
echo "  Checking dataset directories"
echo "============================================================"

for d in \
    "${TRAIN_FINAL}" \
    "${VAL_FINAL}" \
    "${RS_TRAIN}" \
    "${NS_VAL}" \
    "${NS_TRAIN}" \
    "${RS_VAL}"
do
    if [ ! -d "$d" ]; then
        echo "[WARNING] Dataset directory not found: $d"
    else
        echo "[OK] $d"
    fi
done

echo "============================================================"
echo "  Checking pretrained weights"
echo "============================================================"

if [ ! -d "${MODEL}" ]; then
    echo "[WARNING] MODEL directory not found: ${MODEL}"
else
    echo "[OK] MODEL: ${MODEL}"
fi

if [ ! -f "${VISION_TOWER}" ]; then
    echo "[WARNING] VISION_TOWER file not found: ${VISION_TOWER}"
else
    echo "[OK] VISION_TOWER: ${VISION_TOWER}"
fi

# ============================================================
# 1. train_FINAL_CLEAN -> val_FINAL_CLEAN
# ============================================================
echo "============================================================"
echo "  [1/3] train_change_train_val: train_FINAL_CLEAN -> val_FINAL_CLEAN"
echo "============================================================"

bash scripts/train_change_train_val.sh \
 "${TRAIN_FINAL}" \
 "${VAL_FINAL}" \
 "${MODEL}" \
 "${VISION_TOWER}" \
 "./checkpoint/train_change_train_val" \
 "${GPUS}"

# ============================================================
# 2. RS_FINAL_CLEAN_train -> RS_FINAL_CLEAN_val
# ============================================================
echo "============================================================"
echo "  [2/3] train_change_rs: RS_FINAL_CLEAN_train -> RS_FINAL_CLEAN_val"
echo "============================================================"

bash scripts/train_change_rs.sh \
 "${RS_TRAIN}" \
 "${RS_VAL}" \
 "${MODEL}" \
 "${VISION_TOWER}" \
 "./checkpoint/train_change_rs" \
 "${GPUS}"

# ============================================================
# 3. NS_FINAL_CLEAN_train -> NS_FINAL_CLEAN_val
# ============================================================
echo "============================================================"
echo "  [3/3] train_change_ns: NS_FINAL_CLEAN_train -> NS_FINAL_CLEAN_val"
echo "============================================================"

bash scripts/train_change_ns.sh \
 "${NS_TRAIN}" \
 "${NS_VAL}" \
 "${MODEL}" \
 "${VISION_TOWER}" \
 "./checkpoint/train_change_ns" \
 "${GPUS}"

echo "============================================================"
echo "  All experiments finished."
echo "============================================================"