import torch

sd = torch.load("/gemini/space/zhaozy/libingyu/LISA-main-new/run_7B_bifusion/lisa-bitemporal-run-NS-RS/ckpt_model/global_step4500/bf16_zero_pp_rank_0_mp_rank_00_optim_states.pt", map_location="cpu", weights_only=True)
print(len(sd))
for k in list(sd.keys()):
    print(k)