#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LVLM_ROOT="$(cd "${ROOT_DIR}/.." && pwd)"
DATA_ROOT="$(bash "${LVLM_ROOT}/prepare_vis_subset.sh")"
OUTPUT_ROOT="${LVLM_ROOT}/vis_segmap/LISA-bi_fusion"
mkdir -p "${OUTPUT_ROOT}"

CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" python "${ROOT_DIR}/batch_chat_visualize.py" \
  --version "${ROOT_DIR}/run_7B/LISA_bi_fusion_7B" \
  --vision-tower "${ROOT_DIR}/pretrained_weights/clip-vit-large-patch14" \
  --precision bf16 \
  --json_dir "${DATA_ROOT}/referring_expression" \
  --image_dir_A "${DATA_ROOT}/A" \
  --image_dir_B "${DATA_ROOT}/B" \
  --mask_root "${DATA_ROOT}/masks" \
  --output_dir "${OUTPUT_ROOT}" \
  --save_canvas \
  --save_gt
