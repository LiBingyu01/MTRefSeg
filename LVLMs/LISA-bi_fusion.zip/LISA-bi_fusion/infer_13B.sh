# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp1: train -> val
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-13B-llama2-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|NS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|NS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-eval-ns-NS" \
  --log_base_dir "run_13B_eval" \
  --steps_per_epoch 500 \
  --epochs 20 \
  --eval_only 2>&1 | tee eval_NS_13B.log

# =============================================================================

# # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# # exp1: NS
# # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-13B-llama2-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|RS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|RS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-RS" \
  --log_base_dir "run_13B_eval" \
  --steps_per_epoch 500 \
  --epochs 20 \
  --eval_only 2>&1 | tee eval_RS_13B.log
# =============================================================================


# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-13B-llama2-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|train_FINAL_CLEAN" \
  --val_dataset "ChangeRef_Clear|val_FINAL_CLEAN" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run" \
  --log_base_dir "run_13B_eval" \
  --steps_per_epoch 500 \
  --epochs 20 \
  --eval_only 2>&1 | tee eval_all_13B.log
# =============================================================================














# # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# # exp1: NS
# # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "run_13B/LISA_bi_fusion_13B_NS" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|NS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|NS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-eval-NS" \
  --log_base_dir "run_13B_eval_finetuning" \
  --steps_per_epoch 500 \
  --epochs 20 \
  --eval_only 2>&1 | tee eval_NS_13B_finetuning.log

# =============================================================================

# # # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# # # exp1: RS
# # # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "run_13B/LISA_bi_fusion_13B_RS" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|RS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|RS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-RS" \
  --log_base_dir "run_13B_eval_finetuning" \
  --steps_per_epoch 500 \
  --epochs 20 \
  --eval_only 2>&1 | tee eval_RS_13B_finetuning.log
# =============================================================================


# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "run_13B/LISA_bi_fusion_13B" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|train_FINAL_CLEAN" \
  --val_dataset "ChangeRef_Clear|val_FINAL_CLEAN" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run" \
  --log_base_dir "run_13B_eval_finetuning" \
  --steps_per_epoch 500 \
  --epochs 20 \
  --eval_only  2>&1 | tee eval_all_13B_finetuning.log
# =============================================================================