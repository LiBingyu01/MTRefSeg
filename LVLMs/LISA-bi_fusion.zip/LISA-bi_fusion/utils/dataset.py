import glob
import os
import random
import json

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from pycocotools import mask
from transformers import CLIPImageProcessor

from model.llava import conversation as conversation_lib
from model.llava.constants import (DEFAULT_IMAGE_TOKEN, IGNORE_INDEX,
                                   IMAGE_TOKEN_INDEX)
from model.llava.mm_utils import tokenizer_image_token
from model.segment_anything.utils.transforms import ResizeLongestSide

from .utils import (DEFAULT_IM_END_TOKEN, DEFAULT_IM_START_TOKEN,
                    DEFAULT_IMAGE_TOKEN,DEFAULT_IMAGE_TOKEN_T1, DEFAULT_IMAGE_TOKEN_T2)


def collate_fn(
    batch, 
    tokenizer=None, 
    conv_type="llava_v1", 
    use_mm_start_end=True, 
    local_rank=-1
):
    image_path_list = []
    # 修改：分别存储 T1 和 T2 的图像
    images_t1_list = []
    images_t2_list = []
    images_clip_t1_list = []
    images_clip_t2_list = []
    
    conversation_list = []
    masks_list = []
    label_list = []
    resize_list = []
    questions_list = []
    sampled_classes_list = []
    offset_list = [0]
    cnt = 0
    inferences = []

    for (
        image_path,
        images_t1,
        images_t2,
        images_clip_t1,
        images_clip_t2, 
        conversations,
        masks,
        label,
        resize,
        questions,
        sampled_classes,
        inference
    ) in batch:
        image_path_list.append(image_path)
        
        # 收集双图数据
        images_t1_list.append(images_t1)
        images_t2_list.append(images_t2)
        images_clip_t1_list.append(images_clip_t1)
        images_clip_t2_list.append(images_clip_t2)
        
        conversation_list.extend(conversations)
        label_list.append(label)
        masks_list.append(masks.float())
        resize_list.append(resize)
        questions_list.append(questions)
        sampled_classes_list.append(sampled_classes)
        cnt += len(conversations)
        offset_list.append(cnt)
        inferences.append(inference)

    # --- 以下处理 Conversation Token 的逻辑保持不变 ---
    if use_mm_start_end:
        # replace <image> token
        for i in range(len(conversation_list)):
            replace_token = DEFAULT_IMAGE_TOKEN
            replace_token = (
                DEFAULT_IM_START_TOKEN + replace_token + DEFAULT_IM_END_TOKEN
            )
            # T1
            conversation_list[i] = conversation_list[i].replace(
                DEFAULT_IMAGE_TOKEN_T1, replace_token
            )
            # T2
            conversation_list[i] = conversation_list[i].replace(
                DEFAULT_IMAGE_TOKEN_T2, replace_token
            )
    input_ids = [
        tokenizer_image_token(prompt, tokenizer, return_tensors="pt")
        for prompt in conversation_list
    ]
    input_ids = torch.nn.utils.rnn.pad_sequence(
        input_ids, batch_first=True, padding_value=tokenizer.pad_token_id
    )
    attention_masks = input_ids.ne(tokenizer.pad_token_id)

    conv = conversation_lib.default_conversation.copy()
    targets = input_ids.clone()

    if conv_type == "llava_v1":
        sep = conv.sep + conv.roles[1] + ": "
    else:
        sep = "[/INST] "

    for conversation, target in zip(conversation_list, targets):
        total_len = int(target.ne(tokenizer.pad_token_id).sum())
        rounds = conversation.split(conv.sep2)
        cur_len = 1
        target[:cur_len] = IGNORE_INDEX
        for i, rou in enumerate(rounds):
            if rou == "":
                break
            parts = rou.split(sep)
            if len(parts) != 2:
                break
            parts[0] += sep

            if DEFAULT_IMAGE_TOKEN in conversation:
                round_len = len(tokenizer_image_token(rou, tokenizer))
                instruction_len = len(tokenizer_image_token(parts[0], tokenizer)) - 2
            else:
                round_len = len(tokenizer(rou).input_ids)
                instruction_len = len(tokenizer(parts[0]).input_ids) - 2

            target[cur_len : cur_len + instruction_len] = IGNORE_INDEX
            cur_len += round_len
        target[cur_len:] = IGNORE_INDEX

        if cur_len < tokenizer.model_max_length:
            assert cur_len == total_len

    if inferences[0] == False:
        truncate_len = tokenizer.model_max_length - 255

        if input_ids.shape[1] > truncate_len:
            input_ids = input_ids[:, :truncate_len]
            targets = targets[:, :truncate_len]
            attention_masks = attention_masks[:, :truncate_len]
            
    return {
        "image_paths": image_path_list,
        # 修改：返回双图 Batch
        "images_t1": torch.stack(images_t1_list, dim=0),
        "images_t2": torch.stack(images_t2_list, dim=0),
        "images_clip_t1": torch.stack(images_clip_t1_list, dim=0),
        "images_clip_t2": torch.stack(images_clip_t2_list, dim=0),
        "input_ids": input_ids,
        "labels": targets,
        "attention_masks": attention_masks,
        "masks_list": masks_list,
        "label_list": label_list,
        "resize_list": resize_list,
        "offset": torch.LongTensor(offset_list),
        "questions_list": questions_list,
        "sampled_classes_list": sampled_classes_list,
        "inference": inferences[0],
        "conversation_list": conversation_list,
    }

from .changeref_seg_dataset import ChangeReferDataset 

class HybridDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        base_image_dir,
        tokenizer,
        vision_tower,
        samples_per_epoch=500 * 8 * 2 * 10,
        precision: str = "fp32",
        image_size: int = 224,
        num_classes_per_sample: int = 3,
        exclude_val=False,
        dataset="change_refer", 
        change_refer_seg_data='changeref|train',
        **kwargs,
    ):
        self.samples_per_epoch = samples_per_epoch
        self.change_refer_ds = ChangeReferDataset(
            base_image_dir=base_image_dir,
            tokenizer=tokenizer,
            vision_tower=vision_tower,
            samples_per_epoch=samples_per_epoch,
            precision=precision,
            image_size=image_size,
            num_classes_per_sample=num_classes_per_sample,
            exclude_val=exclude_val,
            refer_seg_data=change_refer_seg_data # 你的数据集名称
        )

    def __len__(self):
        return self.samples_per_epoch

    def __getitem__(self, idx):
        return self.change_refer_ds[idx]


import glob
import json
import os

import cv2
import numpy as np
import torch
import torch.nn.functional as F
# 假设以下依赖已经在你的文件中导入
# from transformers import CLIPImageProcessor
# from model.segment_anything.utils.transforms import ResizeLongestSide
# from model.llava import conversation as conversation_lib
# from .utils import DEFAULT_IMAGE_TOKEN_T1, DEFAULT_IMAGE_TOKEN_T2

class ValDataset(torch.utils.data.Dataset):
    pixel_mean = torch.Tensor([123.675, 116.28, 103.53]).view(-1, 1, 1)
    pixel_std = torch.Tensor([58.395, 57.12, 57.375]).view(-1, 1, 1)
    img_size = 1024
    ignore_label = 255

    def __init__(
        self,
        base_image_dir,
        tokenizer,
        vision_tower,
        val_dataset,
        image_size=1024,
    ):
        self.base_image_dir = base_image_dir
        self.image_size = image_size
        self.tokenizer = tokenizer
        self.transform = ResizeLongestSide(image_size)
        self.clip_image_processor = CLIPImageProcessor.from_pretrained(vision_tower)
        
        # --- 1. 按照新版结构解析并定义数据路径 ---
        dataset_name, split = val_dataset.split("|")
        self.root = os.path.join(base_image_dir, dataset_name, split)
        self.dir_A = os.path.join(self.root, 'A')
        self.dir_B = os.path.join(self.root, 'B')
        self.dir_mask = os.path.join(self.root, 'masks')
        self.dir_json = os.path.join(self.root, 'referring_expression')
        
        json_pattern = os.path.join(self.dir_json, "*.json")
        self.json_paths = glob.glob(json_pattern)
             
        print(f"Validation set size: {len(self.json_paths)}")

    def __len__(self):
        return len(self.json_paths)
    
    def preprocess(self, x: torch.Tensor) -> torch.Tensor:
        x = (x - self.pixel_mean) / self.pixel_std
        h, w = x.shape[-2:]
        padh = self.img_size - h
        padw = self.img_size - w
        x = F.pad(x, (0, padw, 0, padh))
        return x

    def __getitem__(self, idx):
        json_path = self.json_paths[idx]
        file_id = os.path.splitext(os.path.basename(json_path))[0]
        
        with open(json_path, "r", encoding='utf-8') as f:
            data = json.load(f)

        # --- 2. 使用 file_id 直接拼接 A 和 B 图像路径 (.jpg) ---
        img_name = f"{file_id}.jpg"
        path_A = os.path.join(self.dir_A, img_name)
        path_B = os.path.join(self.dir_B, img_name)

        image_A = cv2.imread(path_A)
        image_B = cv2.imread(path_B)
        if image_A is None or image_B is None:
            print(f"Error loading images: {path_A} or {path_B}")
            return self.__getitem__(0)
        image_A = cv2.cvtColor(image_A, cv2.COLOR_BGR2RGB)
        image_B = cv2.cvtColor(image_B, cv2.COLOR_BGR2RGB)

        # --- 3. CLIP 预处理 (双图) ---
        image_clip_A = self.clip_image_processor.preprocess(image_A, 
                                    return_tensors="pt")["pixel_values"][0]
        image_clip_B = self.clip_image_processor.preprocess(image_B, 
                                    return_tensors="pt")["pixel_values"][0]

        # SAM transform
        image_A_sam = self.transform.apply_image(image_A)
        image_B_sam = self.transform.apply_image(image_B)
        resize = image_A_sam.shape[:2]
        image_A_tensor = self.preprocess(torch.from_numpy(image_A_sam).permute(2, 0, 1).contiguous())
        image_B_tensor = self.preprocess(torch.from_numpy(image_B_sam).permute(2, 0, 1).contiguous())

        # Construct Conversation & Load Masks
        ref_exps = data.get("referring_expressions", [])
        questions = []
        answers = [] 
        masks = []
        
        ori_h, ori_w = image_A.shape[:2]
        
        for i, text in enumerate(ref_exps):
            # 组装对话
            questions.append(DEFAULT_IMAGE_TOKEN_T1 + " is the earlier image, and " + 
                             DEFAULT_IMAGE_TOKEN_T2 + " is the later image." + "\n" +
                             f"\n Compare the two images and segment {text}. Please output segmentation mask.")
            answers.append("[SEG].")

            # --- 4. 使用新版逻辑读取对应的 Mask 图像 ---
            m = np.zeros((ori_h, ori_w), dtype=np.uint8)
            mask_path = os.path.join(self.dir_mask, file_id, f"{i}.png")
            
            if os.path.exists(mask_path):
                m_file = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
                if m_file is not None:
                    # 二值化处理为 0/1 标签
                    m[m_file > 0] = 1
            masks.append(m.astype(np.uint8))

        if len(masks) == 0:
            masks = torch.zeros(0, ori_h, ori_w)
        else:
            masks = np.stack(masks, axis=0)
            masks = torch.from_numpy(masks)
            
        label = torch.ones(masks.shape[1], masks.shape[2]) * self.ignore_label

        conversations = []
        conv = conversation_lib.default_conversation.copy()
        for i in range(len(questions)):
            conv.messages = []
            conv.append_message(conv.roles[0], questions[i])
            conv.append_message(conv.roles[1], answers[i])
            conversations.append(conv.get_prompt())

        inference = True
        return (
            path_A,
            image_A_tensor,
            image_B_tensor,
            image_clip_A,
            image_clip_B,
            conversations,
            masks,
            label,
            resize,
            questions,
            ref_exps,
            inference
        )