
from huggingface_hub import snapshot_download
import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"


# snapshot_download(
#     repo_id="xinlai/LISA-7B-v1",
#     repo_type="model",
#     local_dir="pretrained_weights/LISA-7B-v1",
#     local_dir_use_symlinks=False
# )



snapshot_download(
    repo_id="xinlai/LISA-13B-llama2-v1",
    repo_type="model",
    local_dir="pretrained_weights/LISA-13B-llama2-v1",
    local_dir_use_symlinks=False
)


