# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "/lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/UniChange-main/pretrained_weights/LLaVA-Lightning-7B-delta-v1-1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|MTRefSeg_pretrain" \
  --val_dataset "ChangeRef_Clear|MTRefSeg_pretrain_500" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-MTRefSeg_pretrain" \
  --log_base_dir "run_7B_MTRefSeg_pretrain" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_MTRefSeg_pretrain_7B.log
# =============================================================================
