
from huggingface_hub import snapshot_download
import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"


snapshot_download(
    repo_id="openai/clip-vit-large-patch14",
    repo_type="model",
    local_dir="pretrained_weights/clip-vit-large-patch14",
    local_dir_use_symlinks=False
)
