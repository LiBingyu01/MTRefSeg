import argparse
import os
import re
import sys

import bleach
import cv2
import gradio as gr
import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, BitsAndBytesConfig, CLIPImageProcessor

from model.LISA import LISAForCausalLM
from model.llava import conversation as conversation_lib
from model.llava.mm_utils import tokenizer_image_token
from model.segment_anything.utils.transforms import ResizeLongestSide
from utils.utils import (
    DEFAULT_IM_END_TOKEN,
    DEFAULT_IM_START_TOKEN,
    DEFAULT_IMAGE_TOKEN,
    IMAGE_TOKEN_INDEX,
)


def parse_args(args):
    parser = argparse.ArgumentParser(description="LISA dual-temporal chat")
    parser.add_argument("--version", default="xinlai/LISA-13B-llama2-v1")
    parser.add_argument("--vis_save_path", default="./vis_output", type=str)
    parser.add_argument(
        "--precision",
        default="fp16",
        type=str,
        choices=["fp32", "bf16", "fp16"],
        help="precision for inference",
    )
    parser.add_argument("--image_size", default=1024, type=int, help="image size")
    parser.add_argument("--model_max_length", default=512, type=int)
    parser.add_argument("--lora_r", default=8, type=int)
    parser.add_argument(
        "--vision-tower", default="openai/clip-vit-large-patch14", type=str
    )
    parser.add_argument("--local-rank", default=0, type=int, help="node rank")
    parser.add_argument("--load_in_8bit", action="store_true", default=False)
    parser.add_argument("--load_in_4bit", action="store_true", default=False)
    parser.add_argument("--use_mm_start_end", action="store_true", default=True)
    parser.add_argument(
        "--conv_type",
        default="llava_v1",
        type=str,
        choices=["llava_v1", "llava_llama_2"],
    )
    return parser.parse_args(args)


def preprocess(
    x,
    pixel_mean=torch.Tensor([123.675, 116.28, 103.53]).view(-1, 1, 1),
    pixel_std=torch.Tensor([58.395, 57.12, 57.375]).view(-1, 1, 1),
    img_size=1024,
) -> torch.Tensor:
    """Normalize pixel values and pad to a square input."""
    x = (x - pixel_mean) / pixel_std
    h, w = x.shape[-2:]
    padh = img_size - h
    padw = img_size - w
    x = F.pad(x, (0, padw, 0, padh))
    return x


def cast_tensor_precision(x):
    if args.precision == "bf16":
        return x.bfloat16()
    if args.precision == "fp16":
        return x.half()
    return x.float()


def load_and_prepare_image(image_path):
    image_np = cv2.imread(image_path)
    if image_np is None:
        raise ValueError(f"Failed to read image: {image_path}")
    image_np = cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB)

    original_size = image_np.shape[:2]

    image_clip = clip_image_processor.preprocess(
        image_np, return_tensors="pt"
    )["pixel_values"][0].unsqueeze(0).cuda()
    image_clip = cast_tensor_precision(image_clip)

    image_sam = transform.apply_image(image_np)
    resize_shape = image_sam.shape[:2]
    image_sam = preprocess(
        torch.from_numpy(image_sam).permute(2, 0, 1).contiguous(),
        img_size=args.image_size,
    ).unsqueeze(0).cuda()
    image_sam = cast_tensor_precision(image_sam)

    return image_np, image_clip, image_sam, resize_shape, original_size


def build_prompt(input_str):
    prompt = DEFAULT_IMAGE_TOKEN + "\n" + DEFAULT_IMAGE_TOKEN + "\n" + input_str
    if args.use_mm_start_end:
        replace_token = (
            DEFAULT_IM_START_TOKEN + DEFAULT_IMAGE_TOKEN + DEFAULT_IM_END_TOKEN
        )
        prompt = prompt.replace(DEFAULT_IMAGE_TOKEN, replace_token)

    conv = conversation_lib.conv_templates[args.conv_type].copy()
    conv.messages = []
    conv.append_message(conv.roles[0], prompt)
    conv.append_message(conv.roles[1], "")
    return conv.get_prompt()


def call_model_evaluate_dual(
    image_clip_t1,
    image_t1,
    image_clip_t2,
    image_t2,
    input_ids,
    resize_list,
    original_size_list,
):
    last_error = None

    attempts = [
        lambda: model.evaluate(
            images_clip_t1=image_clip_t1,
            images_t1=image_t1,
            images_clip_t2=image_clip_t2,
            images_t2=image_t2,
            input_ids=input_ids,
            resize_list=resize_list,
            original_size_list=original_size_list,
            max_new_tokens=512,
            tokenizer=tokenizer,
        ),
        lambda: model.evaluate(
            image_clip_t1,
            image_t1,
            image_clip_t2,
            image_t2,
            input_ids,
            resize_list,
            original_size_list,
            max_new_tokens=512,
            tokenizer=tokenizer,
        ),
    ]

    for attempt in attempts:
        try:
            return attempt()
        except TypeError as exc:
            last_error = exc

    raise RuntimeError(
        "The loaded model does not appear to expose a dual-temporal evaluate() interface. "
        "Please make sure the model code has been updated together with the inference script."
    ) from last_error


def overlay_mask(base_image, pred_masks):
    save_img = None
    for pred_mask in pred_masks:
        if pred_mask.shape[0] == 0:
            continue

        pred_mask = pred_mask.detach().cpu().numpy()[0]
        pred_mask = pred_mask > 0

        save_img = base_image.copy()
        save_img[pred_mask] = (
            base_image * 0.5
            + pred_mask[:, :, None].astype(np.uint8) * np.array([255, 0, 0]) * 0.5
        )[pred_mask]

    if save_img is None:
        return cv2.imread("./resources/no_seg_out.png")[:, :, ::-1]
    return save_img


args = parse_args(sys.argv[1:])
os.makedirs(args.vis_save_path, exist_ok=True)

tokenizer = AutoTokenizer.from_pretrained(
    args.version,
    cache_dir=None,
    model_max_length=args.model_max_length,
    padding_side="right",
    use_fast=False,
)
tokenizer.pad_token = tokenizer.unk_token
args.seg_token_idx = tokenizer("[SEG]", add_special_tokens=False).input_ids[0]

torch_dtype = torch.float32
if args.precision == "bf16":
    torch_dtype = torch.bfloat16
elif args.precision == "fp16":
    torch_dtype = torch.half

kwargs = {"torch_dtype": torch_dtype}
if args.load_in_4bit:
    kwargs.update(
        {
            "torch_dtype": torch.half,
            "load_in_4bit": True,
            "quantization_config": BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4",
                llm_int8_skip_modules=["visual_model"],
            ),
        }
    )
elif args.load_in_8bit:
    kwargs.update(
        {
            "torch_dtype": torch.half,
            "quantization_config": BitsAndBytesConfig(
                llm_int8_skip_modules=["visual_model"],
                load_in_8bit=True,
            ),
        }
    )

model = LISAForCausalLM.from_pretrained(
    args.version,
    low_cpu_mem_usage=True,
    vision_tower=args.vision_tower,
    seg_token_idx=args.seg_token_idx,
    **kwargs,
)

model.config.eos_token_id = tokenizer.eos_token_id
model.config.bos_token_id = tokenizer.bos_token_id
model.config.pad_token_id = tokenizer.pad_token_id

model.get_model().initialize_vision_modules(model.get_model().config)
vision_tower = model.get_model().get_vision_tower()
vision_tower.to(dtype=torch_dtype)

if args.precision == "bf16":
    model = model.bfloat16().cuda()
elif (
    args.precision == "fp16" and (not args.load_in_4bit) and (not args.load_in_8bit)
):
    vision_tower = model.get_model().get_vision_tower()
    model.model.vision_tower = None
    import deepspeed

    model_engine = deepspeed.init_inference(
        model=model,
        dtype=torch.half,
        replace_with_kernel_inject=True,
        replace_method="auto",
    )
    model = model_engine.module
    model.model.vision_tower = vision_tower.half().cuda()
elif args.precision == "fp32":
    model = model.float().cuda()

vision_tower = model.get_model().get_vision_tower()
vision_tower.to(device=args.local_rank)

clip_image_processor = CLIPImageProcessor.from_pretrained(model.config.vision_tower)
transform = ResizeLongestSide(args.image_size)

model.eval()

examples = [
    [
        "What changed between these two images? Please output segmentation mask.",
        "./resources/imgs/example1.jpg",
        "./resources/imgs/example1.jpg",
    ],
    [
        "Can you segment the changed region between the two timestamps and explain why?",
        "./resources/imgs/example2.jpg",
        "./resources/imgs/example2.jpg",
    ],
]
output_labels = ["Segmentation Output"]

title = "LISA: Dual-Temporal Reasoning Segmentation"

description = """
<font size=4>
This is the online demo of LISA with dual-temporal image input. \n
Please upload two images corresponding to different timestamps (T1 and T2). \n
**Note**: The prompt should explicitly describe the changed target or ask for changed-region segmentation. \n
**Note**: The output mask is rendered on the T2 image by default. \n
**Usage**: <br>
&ensp;(1) To segment changed regions, input prompts like: "What changed between these two images? Please output segmentation mask." <br>
&ensp;(2) To obtain an explanation together with the mask, input prompts like: "Please output segmentation mask and explain why." <br>
</font>
"""

article = """
<p style='text-align: center'>
<a href='https://arxiv.org/abs/2308.00692' target='_blank'>
Preprint Paper
</a>
\n
<p style='text-align: center'>
<a href='https://github.com/dvlab-research/LISA' target='_blank'>   Github Repo </a></p>
"""


def inference(input_str, input_image_t1, input_image_t2):
    input_str = bleach.clean(input_str)

    print(
        "input_str:",
        input_str,
        "input_image_t1:",
        input_image_t1,
        "input_image_t2:",
        input_image_t2,
    )

    if not re.match(r"^[A-Za-z0-9 ,.!?\'\"\-:;()]+$", input_str) or len(input_str) < 1:
        output_str = f"[Error] Invalid input: {input_str}"
        output_image = cv2.imread("./resources/error_happened.png")[:, :, ::-1]
        return output_image, output_str

    if not input_image_t1 or not input_image_t2:
        output_str = "[Error] Please provide both T1 and T2 images."
        output_image = cv2.imread("./resources/error_happened.png")[:, :, ::-1]
        return output_image, output_str

    prompt = build_prompt(input_str)

    image_np_t1, image_clip_t1, image_t1, resize_t1, original_size_t1 = load_and_prepare_image(
        input_image_t1
    )
    image_np_t2, image_clip_t2, image_t2, resize_t2, original_size_t2 = load_and_prepare_image(
        input_image_t2
    )

    input_ids = tokenizer_image_token(prompt, tokenizer, return_tensors="pt")
    input_ids = input_ids.unsqueeze(0).cuda()

    output_ids, pred_masks = call_model_evaluate_dual(
        image_clip_t1,
        image_t1,
        image_clip_t2,
        image_t2,
        input_ids,
        [resize_t1, resize_t2],
        [original_size_t1, original_size_t2],
    )
    output_ids = output_ids[0][output_ids[0] != IMAGE_TOKEN_INDEX]

    text_output = tokenizer.decode(output_ids, skip_special_tokens=False)
    text_output = text_output.replace("\n", "").replace("  ", " ")
    text_output = text_output.split("ASSISTANT: ")[-1]

    print("text_output:", text_output)
    output_image = overlay_mask(image_np_t2, pred_masks)
    output_str = "ASSISTANT: " + text_output
    return output_image, output_str


demo = gr.Interface(
    inference,
    inputs=[
        gr.Textbox(lines=1, placeholder=None, label="Text Instruction"),
        gr.Image(type="filepath", label="Input Image T1"),
        gr.Image(type="filepath", label="Input Image T2"),
    ],
    outputs=[
        gr.Image(type="pil", label="Segmentation Output"),
        gr.Textbox(lines=1, placeholder=None, label="Text Output"),
    ],
    title=title,
    description=description,
    article=article,
    examples=examples,
    allow_flagging="auto",
)

demo.queue()
demo.launch()
