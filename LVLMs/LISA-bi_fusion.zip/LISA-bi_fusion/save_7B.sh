cd ./run_7B/lisa-bitemporal-run-RS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/LISA-bi_fusion
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-7B-v1" \
  --weight="./run_7B/lisa-bitemporal-run-RS/pytorch_model.bin" \
  --save_path="./run_7B/LISA_bi_fusion_7B_RS"




cd ./run_7B/lisa-bitemporal-run-NS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/LISA-bi_fusion
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-7B-v1" \
  --weight="./run_7B/lisa-bitemporal-run-NS/pytorch_model.bin" \
  --save_path="./run_7B/LISA_bi_fusion_7B_NS"




cd ./run_7B/lisa-bitemporal-run/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/LISA-bi_fusion
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-7B-v1" \
  --weight="./run_7B/lisa-bitemporal-run/pytorch_model.bin" \
  --save_path="./run_7B/LISA_bi_fusion_7B"








cd ./run_13B/lisa-bitemporal-run-RS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/LISA-bi_fusion
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-13B-llama2-v1" \
  --weight="./run_13B/lisa-bitemporal-run-RS/pytorch_model.bin" \
  --save_path="./run_13B/LISA_bi_fusion_13B_RS"




cd ./run_13B/lisa-bitemporal-run-NS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/LISA-bi_fusion
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-13B-llama2-v1" \
  --weight="./run_13B/lisa-bitemporal-run-NS/pytorch_model.bin" \
  --save_path="./run_13B/LISA_bi_fusion_13B_NS"




cd ./run_13B/lisa-bitemporal-run/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/LISA-bi_fusion
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-13B-llama2-v1" \
  --weight="./run_13B/lisa-bitemporal-run/pytorch_model.bin" \
  --save_path="./run_13B/LISA_bi_fusion_13B"