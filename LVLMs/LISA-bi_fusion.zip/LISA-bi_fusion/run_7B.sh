# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp1: NS
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-7B-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|NS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|NS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-NS" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_NS_7B.log
# =============================================================================


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp2: RS
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-7B-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|RS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|RS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-RS" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_RS_7B.log
# =============================================================================

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp3: train -> val
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-7B-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|train_FINAL_CLEAN" \
  --val_dataset "ChangeRef_Clear|val_FINAL_CLEAN" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_all_7B.log
# =============================================================================














# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp1: train -> val
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-13B-llama2-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|train_FINAL_CLEAN" \
  --val_dataset "ChangeRef_Clear|val_FINAL_CLEAN" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run" \
  --log_base_dir "run_13B" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_all_13B.log
# =============================================================================


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp2: NS
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-13B-llama2-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|NS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|NS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-NS" \
  --log_base_dir "run_13B" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_NS_13B.log
# =============================================================================


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp3: RS
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-13B-llama2-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "ChangeRef_Clear|RS_FINAL_CLEAN_train" \
  --val_dataset "ChangeRef_Clear|RS_FINAL_CLEAN_val" \
  --dataset_dir "/lby_data01/zhaozy/lby" \
  --exp_name "lisa-bitemporal-run-RS" \
  --log_base_dir "run_13B" \
  --steps_per_epoch 500 \
  --epochs 10 2>&1 | tee train_RS_13B.log
# =============================================================================