"""
Evaluate GeoPixel on ChangeRef-style val/test JSON.

Usage:
    python evaluate_changeref.py \
        --model_path output/checkpoint-last \
        --val_json data/changeref_val.json \
        --output_file results/val_metrics.json \
        --num_gpus 4

Metrics: cIoU, mIoU, Precision@{0.5,0.6,0.7,0.8,0.9}

Speed tips:
  --num_gpus N   : split samples across N GPUs (each GPU loads its own model)
  --hd_num 1     : lower resolution → faster, slightly lower accuracy
"""

import argparse
import json
import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

import sys
import math

import cv2
import numpy as np
import torch
import torch.multiprocessing as mp
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(__file__))
from model.geopixel import GeoPixelForCausalLM
from peft import PeftModel
import transformers


# ── helpers ──────────────────────────────────────────────────────────────────

def build_gt_mask(polygons_changeref):
    pc = polygons_changeref
    h, w = pc["h"], pc["w"]
    mask = np.zeros((h, w), dtype=np.uint8)
    for ring in pc["polygons"]:
        if len(ring) < 3:
            continue
        pts = np.array(ring, dtype=np.int32)
        cv2.fillPoly(mask, [pts], color=1)
    return mask


def compute_iou(pred_mask: np.ndarray, gt_mask: np.ndarray):
    pred_bin = (pred_mask > 0).astype(np.uint8)
    gt_bin   = (gt_mask  > 0).astype(np.uint8)
    intersection = (pred_bin & gt_bin).sum()
    union        = (pred_bin | gt_bin).sum()
    if union == 0:
        return 1.0, 1, 1
    return intersection / union, int(intersection), int(union)

def attach_tokenizer_to_model(model, tokenizer):
    """
    Attach tokenizer to all possible wrapped / inner modules.
    This is needed because PeftModel wraps the original GeoPixel model,
    while interleav_wrap_chat() may be called from the inner model.
    """
    model.tokenizer = tokenizer

    # PEFT wrapper: PeftModel -> base_model -> model
    if hasattr(model, "base_model"):
        model.base_model.tokenizer = tokenizer

        if hasattr(model.base_model, "model"):
            model.base_model.model.tokenizer = tokenizer

            if hasattr(model.base_model.model, "get_model"):
                inner = model.base_model.model.get_model()
                if inner is not None:
                    inner.tokenizer = tokenizer

    # Normal GeoPixel model
    if hasattr(model, "get_model"):
        inner = model.get_model()
        if inner is not None:
            inner.tokenizer = tokenizer

    # Some implementations use .model as inner language model
    if hasattr(model, "model"):
        model.model.tokenizer = tokenizer

        if hasattr(model.model, "get_model"):
            inner = model.model.get_model()
            if inner is not None:
                inner.tokenizer = tokenizer

    # Last-resort: attach to every submodule that already has tokenizer attr
    for module in model.modules():
        if hasattr(module, "tokenizer"):
            module.tokenizer = tokenizer

    return model

def load_model(base_model_path, lora_path, vision_pretrained, device, use_lora=True):
    """
    base_model_path: 原始 GeoPixel 底座模型路径
    lora_path      : LoRA checkpoint 路径
    use_lora       : True 表示加载 LoRA；False 表示 zero-shot，直接加载 base model
    """

    # 1. 加载 tokenizer
    if use_lora:
        try:
            tokenizer = transformers.AutoTokenizer.from_pretrained(
                lora_path,
                padding_side="right",
                use_fast=False,
                trust_remote_code=True,
            )
        except Exception:
            tokenizer = transformers.AutoTokenizer.from_pretrained(
                base_model_path,
                padding_side="right",
                use_fast=False,
                trust_remote_code=True,
            )
    else:
        tokenizer = transformers.AutoTokenizer.from_pretrained(
            base_model_path,
            padding_side="right",
            use_fast=False,
            trust_remote_code=True,
        )

    tokenizer.pad_token = tokenizer.unk_token

    special_tokens = ["[SEG]", "<p>", "</p>"]
    tokenizer.add_tokens(special_tokens, special_tokens=True)

    seg_token_idx, bop_token_idx, eop_token_idx = [
        tokenizer(tok, add_special_tokens=False).input_ids[0]
        for tok in special_tokens
    ]

    # 2. 加载底座模型
    model = GeoPixelForCausalLM.from_pretrained(
        base_model_path,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=True,
        seg_token_idx=seg_token_idx,
        bop_token_idx=bop_token_idx,
        eop_token_idx=eop_token_idx,
        vision_pretrained=vision_pretrained,
    )

    # 先 resize base model，再加载 LoRA
    model.resize_token_embeddings(len(tokenizer))

    if use_lora:
        print(f"Loading LoRA weights from {lora_path}...")
        model = PeftModel.from_pretrained(model, lora_path)
    else:
        print("Zero-shot mode: using base model directly, no LoRA loaded.")

    model = attach_tokenizer_to_model(model, tokenizer)
    model = model.to(device).eval()
    model = attach_tokenizer_to_model(model, tokenizer)

    return model, tokenizer


# ── per-GPU worker ────────────────────────────────────────────────────────────

def worker(rank, args, samples, result_queue):
    try:
        device = torch.device(f"cuda:{rank}")
        torch.cuda.set_device(device)

        model, tokenizer = load_model(
            args.base_model_path,
            args.model_path,
            args.vision_pretrained,
            device,
            use_lora=args.use_lora,
        )
        thresholds = [0.5, 0.6, 0.7, 0.8, 0.9]
        total_intersection = 0
        total_union = 0
        per_sample_ious = []
        precision_hits = {t: 0 for t in thresholds}
        skipped = 0

        iterable = tqdm(samples, desc=f"GPU {rank}", position=rank) if rank == 0 else samples

        for item in iterable:
            human_val = item["conversations"][0]["value"]
            query = human_val.replace("[SEG]", "").strip()

            images = item["image"]
            if not isinstance(images, list):
                images = [images]

            if "polygons_changeref" not in item:
                skipped += 1
                continue

            gt_mask = build_gt_mask(item["polygons_changeref"])

            try:
                with torch.no_grad(), torch.cuda.amp.autocast(dtype=torch.bfloat16):
                    _, pred_masks = model.evaluate(
                        tokenizer,
                        query=query,
                        images=images,
                        hd_num=args.hd_num,
                        max_new_tokens=args.max_new_tokens,
                    )
            except Exception:
                import traceback
                tqdm.write(f"[GPU {rank}] inference failed!")
                tqdm.write(traceback.format_exc())
                skipped += 1
                continue

            # 兼容返回 []、[[]]、空 Tensor 的情况
            is_empty_mask = False
            if not pred_masks or len(pred_masks) == 0:
                is_empty_mask = True
            elif isinstance(pred_masks[0], list) and len(pred_masks[0]) == 0:
                is_empty_mask = True
            elif hasattr(pred_masks[0], "numel") and pred_masks[0].numel() == 0:
                is_empty_mask = True

            if is_empty_mask:
                if gt_mask.sum() == 0:
                    # True Negative
                    per_sample_ious.append(1.0)
                    total_intersection += 1
                    total_union += 1
                    for t in thresholds:
                        precision_hits[t] += 1
                else:
                    # False Negative
                    per_sample_ious.append(0.0)
                    total_union += int(gt_mask.sum())
                continue

            pred_tensor = pred_masks[0][0]
            pred_np = (pred_tensor.sigmoid().cpu().float().numpy() > 0.5).astype(np.uint8)

            if pred_np.shape != gt_mask.shape:
                pred_np = cv2.resize(
                    pred_np,
                    (gt_mask.shape[1], gt_mask.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                )

            iou, inter, union = compute_iou(pred_np, gt_mask)
            per_sample_ious.append(iou)
            total_intersection += inter
            total_union += union

            for t in thresholds:
                if iou >= t:
                    precision_hits[t] += 1

        result_queue.put({
            "ok": True,
            "rank": rank,
            "total_intersection": total_intersection,
            "total_union": total_union,
            "per_sample_ious": per_sample_ious,
            "precision_hits": precision_hits,
            "skipped": skipped,
        })

    except Exception:
        import traceback
        result_queue.put({
            "ok": False,
            "rank": rank,
            "error": traceback.format_exc(),
        })


# ── main ──────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser()

    p.add_argument("--base_model_path", required=True, help="原始底座模型的路径")
    p.add_argument("--model_path", required=True)
    p.add_argument("--val_json", required=True)

    p.add_argument(
        "--vision_pretrained",
        default="facebook/sam2-hiera-large",
        help="SAM2 HuggingFace model id",
    )

    p.add_argument("--output_file", default=None)
    p.add_argument("--max_samples", type=int, default=None)

    p.add_argument(
        "--hd_num",
        type=int,
        default=9,
        help="Image resolution tiles. Lower = faster (try 1 or 4)",
    )

    p.add_argument(
        "--num_gpus",
        type=int,
        default=1,
        help="Number of GPUs to use for parallel inference",
    )

    p.add_argument(
        "--max_new_tokens",
        type=int,
        default=256,
        help="Max tokens to generate per sample",
    )

    p.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for --max_samples subsampling",
    )

    p.add_argument(
        "--use_lora",
        action="store_true",
        help="Load LoRA adapter from --model_path. If not set, run zero-shot with base model only.",
    )

    return p.parse_args()


def main():
    args = parse_args()

    with open(args.val_json) as f:
        samples = json.load(f)
    if args.max_samples and args.max_samples < len(samples):
        import random
        random.seed(args.seed)
        samples = random.sample(samples, args.max_samples)
    print(f"Evaluating {len(samples)} samples | GPUs: {args.num_gpus} | hd_num: {args.hd_num} | max_new_tokens: {args.max_new_tokens}")
    num_gpus = min(args.num_gpus, torch.cuda.device_count())
    if num_gpus <= 1:
        # single-GPU path (no multiprocessing overhead)
        result_queue = mp.SimpleQueue()
        worker(0, args, samples, result_queue)
        results = [result_queue.get()]
    else:
        # split samples evenly across GPUs
        chunk = math.ceil(len(samples) / num_gpus)
        splits = [samples[i * chunk: (i + 1) * chunk] for i in range(num_gpus)]

        mp.set_start_method("spawn", force=True)
        result_queue = mp.Queue()
        procs = []
        for rank in range(num_gpus):
            p = mp.Process(target=worker, args=(rank, args, splits[rank], result_queue))
            p.start()
            procs.append(p)
            
        # 必须先从队列中取出结果，再等待进程结束
        # 同时检查 worker 是否失败，避免 result_queue.get() 静默卡死
        results = []
        for _ in range(num_gpus):
            r = result_queue.get()

            if not r.get("ok", False):
                print(f"\n[GPU {r.get('rank')}] worker failed:")
                print(r.get("error", "Unknown error"))

                for p in procs:
                    if p.is_alive():
                        p.terminate()
                for p in procs:
                    p.join()

                raise RuntimeError("Evaluation worker failed. See traceback above.")

            results.append(r)

        for p in procs:
            p.join()

    # ── aggregate ────────────────────────────────────────────────────────────
    thresholds = [0.5, 0.6, 0.7, 0.8, 0.9]
    total_intersection = sum(r["total_intersection"] for r in results)
    total_union        = sum(r["total_union"]        for r in results)
    all_ious           = [iou for r in results for iou in r["per_sample_ious"]]
    precision_hits     = {t: sum(r["precision_hits"][t] for r in results) for t in thresholds}
    skipped            = sum(r["skipped"] for r in results)

    n    = len(all_ious)
    ciou = total_intersection / (total_union + 1e-8)
    miou = float(np.mean(all_ious)) if n else 0.0
    precisions = {t: precision_hits[t] / n if n else 0.0 for t in thresholds}

    print(f"\n{'='*40}")
    print(f"Val JSON : {args.val_json}")
    print(f"Samples  : {len(samples)}  (skipped: {skipped})")
    print(f"cIoU     : {ciou:.4f}")
    print(f"mIoU     : {miou:.4f}")
    for t in thresholds:
        print(f"Prec@{t}  : {precisions[t]*100:.2f}%")
    print(f"{'='*40}\n")

    metrics = {
        "val_json": args.val_json,
        "num_samples": len(samples),
        "skipped": skipped,
        "cIoU": ciou,
        "mIoU": miou,
        **{f"Prec@{t}": precisions[t] for t in thresholds},
    }

    if args.output_file:
        os.makedirs(os.path.dirname(os.path.abspath(args.output_file)), exist_ok=True)
        with open(args.output_file, "w") as f:
            json.dump(metrics, f, indent=2)
        print(f"Metrics saved to {args.output_file}")

    return metrics


if __name__ == "__main__":
    main()