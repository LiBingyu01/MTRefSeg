#!/bin/bash
set -e

# Zero-shot evaluation: use pretrained model directly, no finetuning.
# Runs evaluate_changeref.py on all three val/test splits.

export CUDA_DEVICE_MAX_CONNECTIONS=4
export HF_ENDPOINT="https://hf-mirror.com"

MODEL="pretrain_weights/GeoPixel-7B-RES"
SAM2="pretrain_weights/sam2-hiera-large"

OUTPUT_DIR="output/zero_shot"

NUM_GPUS=4
HD_NUM=4
MAX_NEW_TOKENS=128

mkdir -p "${OUTPUT_DIR}"

echo "=========================================="
echo "Zero-shot eval with model: ${MODEL}"
echo "=========================================="

echo "[1/3] changeref_val ..."
python evaluate_changeref.py \
    --base_model_path "${MODEL}" \
    --model_path "${MODEL}" \
    --vision_pretrained "${SAM2}" \
    --val_json data/changeref_val_FINAL_CLEAN.json \
    --output_file "${OUTPUT_DIR}/eval_changeref_val.json" \
    --num_gpus "${NUM_GPUS}" \
    --max_new_tokens "${MAX_NEW_TOKENS}" \
    --hd_num "${HD_NUM}"

# echo "[2/3] changeref_RS ..."
# python evaluate_changeref.py \
#     --base_model_path "${MODEL}" \
#     --model_path "${MODEL}" \
#     --vision_pretrained "${SAM2}" \
#     --val_json data/changeref_RS_FINAL_CLEAN_val.json \
#     --output_file "${OUTPUT_DIR}/eval_changeref_RS.json" \
#     --num_gpus "${NUM_GPUS}" \
#     --max_new_tokens "${MAX_NEW_TOKENS}" \
#     --hd_num "${HD_NUM}"

# echo "[3/3] changeref_NS ..."
# python evaluate_changeref.py \
#     --base_model_path "${MODEL}" \
#     --model_path "${MODEL}" \
#     --vision_pretrained "${SAM2}" \
#     --val_json data/changeref_NS_FINAL_CLEAN_val.json \
#     --output_file "${OUTPUT_DIR}/eval_changeref_NS.json" \
#     --num_gpus "${NUM_GPUS}" \
#     --max_new_tokens "${MAX_NEW_TOKENS}" \
#     --hd_num "${HD_NUM}"

echo ""
echo "=========================================="
echo "All done. Results in ${OUTPUT_DIR}/"
echo "=========================================="

python3 - <<'EOF'
import json
import glob
import os

for f in sorted(glob.glob("output/zero_shot/eval_*.json")):
    d = json.load(open(f))
    name = os.path.basename(f)
    prec = "  ".join(
        f"P@{k.split('@')[1]}={v * 100:.2f}%"
        for k, v in d.items()
        if k.startswith("Prec@")
    )
    print(
        f"{name}: "
        f"cIoU={d['cIoU']:.4f}  "
        f"mIoU={d['mIoU']:.4f}  "
        f"{prec}"
    )
EOF