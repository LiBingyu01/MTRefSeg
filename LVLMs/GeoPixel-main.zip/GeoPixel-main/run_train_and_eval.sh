#!/bin/bash
set -e

# ============================================================
# Train + Eval for paired ChangeRef splits
# ============================================================

export CUDA_DEVICE_MAX_CONNECTIONS=1
export HF_ENDPOINT="https://hf-mirror.com"
export PYTHONWARNINGS="ignore"

# -----------------------------
# Global settings
# -----------------------------
GPUS_PER_NODE=4
EVAL_NUM_GPUS=4

BASE_MODEL="pretrain_weights/GeoPixel-7B-RES"
SAM2="pretrain_weights/sam2-hiera-large"
DATA_ROOT="/lby_data01/zhaozy/lby/ChangeRef_Clear"

MASTER_PORT_BASE=6002

# -----------------------------
# Training settings
# -----------------------------
NUM_TRAIN_EPOCHS=3
PER_DEVICE_BATCH_SIZE=1
GRAD_ACC_STEPS=8
TRAIN_BATCH_SIZE=2

TRAIN_HD_NUM=1
MAX_LENGTH=4096

LR=3e-4
WARMUP_STEPS=100

# -----------------------------
# Evaluation settings
# -----------------------------
EVAL_HD_NUM=4
EVAL_MAX_NEW_TOKENS=128

# 调试时可以打开，例如每个 val 只评测 100 条
# EVAL_MAX_SAMPLES=100

# -----------------------------
# Output root
# -----------------------------
OUTPUT_ROOT="output/pair_experiments"
LOG_ROOT="logs/pair_experiments"

mkdir -p "${OUTPUT_ROOT}"
mkdir -p "${LOG_ROOT}"


# ============================================================
# Dataset pairs
# 格式：
# EXP_NAME|TRAIN_JSON|VAL_JSON
# ============================================================

DATASET_PAIRS=(
# "test|data/test.json|data/test.json"
"NS|data/changeref_NS_FINAL_CLEAN_train.json|data/changeref_NS_FINAL_CLEAN_val.json"
"RS|data/changeref_RS_FINAL_CLEAN_train.json|data/changeref_RS_FINAL_CLEAN_val.json"
"TV|data/changeref_train_FINAL_CLEAN.json|data/changeref_val_FINAL_CLEAN.json"
)


# ============================================================
# Function: train one pair
# ============================================================

run_one_experiment () {
    EXP_NAME=$1
    TRAIN_JSON=$2
    VAL_JSON=$3
    MASTER_PORT=$4

    OUTPUT_DIR="${OUTPUT_ROOT}/${EXP_NAME}"
    LOG_DIR="${LOG_ROOT}/${EXP_NAME}"
    EVAL_DIR="${OUTPUT_DIR}/eval_results"
    CKPT_DIR="${OUTPUT_DIR}/checkpoint-last"

    mkdir -p "${OUTPUT_DIR}"
    mkdir -p "${LOG_DIR}"
    mkdir -p "${EVAL_DIR}"

    echo ""
    echo "============================================================"
    echo "Experiment: ${EXP_NAME}"
    echo "Train json: ${TRAIN_JSON}"
    echo "Val json  : ${VAL_JSON}"
    echo "Output dir: ${OUTPUT_DIR}"
    echo "Master port: ${MASTER_PORT}"
    echo "============================================================"

    if [ ! -f "${TRAIN_JSON}" ]; then
        echo "Error: train json not found: ${TRAIN_JSON}"
        exit 1
    fi

    if [ ! -f "${VAL_JSON}" ]; then
        echo "Error: val json not found: ${VAL_JSON}"
        exit 1
    fi

    # ------------------------------------------------------------
    # 1. Train
    # ------------------------------------------------------------

    echo ""
    echo "------------------------------------------------------------"
    echo "[${EXP_NAME}] Start training"
    echo "------------------------------------------------------------"

    # torchrun \
    #     --nproc_per_node "${GPUS_PER_NODE}" \
    #     --nnodes 1 \
    #     --node_rank 0 \
    #     --master_addr localhost \
    #     --master_port "${MASTER_PORT}" \
    #     train.py \
    #     --model_name_or_path "${BASE_MODEL}" \
    #     --data_path "${TRAIN_JSON}" \
    #     --data_root "${DATA_ROOT}" \
    #     --is_pretrained True \
    #     --given_num False \
    #     --bf16 True \
    #     --fix_vit True \
    #     --fix_sampler False \
    #     --use_lora True \
    #     --hd_num "${TRAIN_HD_NUM}" \
    #     --output_dir "${OUTPUT_DIR}" \
    #     --num_train_epochs "${NUM_TRAIN_EPOCHS}" \
    #     --batch_size "${TRAIN_BATCH_SIZE}" \
    #     --per_device_train_batch_size "${PER_DEVICE_BATCH_SIZE}" \
    #     --per_device_eval_batch_size 1 \
    #     --gradient_accumulation_steps "${GRAD_ACC_STEPS}" \
    #     --evaluation_strategy "no" \
    #     --save_strategy "epoch" \
    #     --save_total_limit 3 \
    #     --learning_rate "${LR}" \
    #     --weight_decay 0.0 \
    #     --adam_beta2 0.95 \
    #     --warmup_steps "${WARMUP_STEPS}" \
    #     --lr_scheduler_type "cosine" \
    #     --logging_steps 10 \
    #     --logging_dir "${LOG_DIR}" \
    #     --report_to "tensorboard" \
    #     --max_length "${MAX_LENGTH}" \
    #     --deepspeed ds_config_zero2.json \
    #     --gradient_checkpointing True

    # echo ""
    # echo "[${EXP_NAME}] Training finished."

    # ------------------------------------------------------------
    # 2. Check checkpoint
    # ------------------------------------------------------------

    if [ ! -d "${CKPT_DIR}" ]; then
        echo "Error: checkpoint-last not found: ${CKPT_DIR}"
        exit 1
    fi

    echo "[${EXP_NAME}] Checkpoint found: ${CKPT_DIR}"

    # ------------------------------------------------------------
    # 3. Eval
    # ------------------------------------------------------------

    echo ""
    echo "------------------------------------------------------------"
    echo "[${EXP_NAME}] Start evaluation"
    echo "------------------------------------------------------------"

    OUT_FILE="${EVAL_DIR}/eval_${EXP_NAME}.json"

    CMD="python evaluate_changeref.py \
        --base_model_path ${BASE_MODEL} \
        --model_path ${CKPT_DIR} \
        --vision_pretrained ${SAM2} \
        --val_json ${VAL_JSON} \
        --output_file ${OUT_FILE} \
        --num_gpus ${EVAL_NUM_GPUS} \
        --max_new_tokens ${EVAL_MAX_NEW_TOKENS} \
        --hd_num ${EVAL_HD_NUM} \
        --use_lora "
        

    if [ ! -z "${EVAL_MAX_SAMPLES}" ]; then
        CMD="${CMD} --max_samples ${EVAL_MAX_SAMPLES}"
    fi

    echo "${CMD}"
    eval "${CMD}"

    echo ""
    echo "[${EXP_NAME}] Evaluation finished."
    echo "[${EXP_NAME}] Result saved to: ${OUT_FILE}"
}


# ============================================================
# Run all experiments
# ============================================================

IDX=0

for PAIR in "${DATASET_PAIRS[@]}"; do
    IFS="|" read -r EXP_NAME TRAIN_JSON VAL_JSON <<< "${PAIR}"

    MASTER_PORT=$((MASTER_PORT_BASE + IDX))

    run_one_experiment \
        "${EXP_NAME}" \
        "${TRAIN_JSON}" \
        "${VAL_JSON}" \
        "${MASTER_PORT}"

    IDX=$((IDX + 1))
done


# ============================================================
# Summary
# ============================================================

echo ""
echo "============================================================"
echo "All experiments finished. Summary:"
echo "============================================================"

python3 - <<EOF
import json
import glob
import os

files = sorted(glob.glob("${OUTPUT_ROOT}/*/eval_results/eval_*.json"))

if not files:
    print("No eval result json found.")
else:
    for f in files:
        try:
            d = json.load(open(f))
            exp = f.split("/")[-3]
            name = os.path.basename(f)

            prec_items = []
            for k, v in d.items():
                if k.startswith("Prec@"):
                    threshold = k.split("@")[1]
                    prec_items.append(f"P@{threshold}={v * 100:.2f}%")

            prec = "  ".join(prec_items)

            print(
                f"{exp}: "
                f"cIoU={d.get('cIoU', 0):.4f}  "
                f"mIoU={d.get('mIoU', 0):.4f}  "
                f"{prec}"
            )

        except Exception as e:
            print(f"Failed to read {f}: {e}")
EOF

echo ""
echo "============================================================"
echo "Done."
echo "All outputs saved under: ${OUTPUT_ROOT}"
echo "============================================================"