from huggingface_hub import snapshot_download

snapshot_download(
    repo_id="MBZUAI/GeoPixel-7B-RES",
    repo_type="model",
    local_dir="pretrain_weights/GeoPixel-7B-RES",
    local_dir_use_symlinks=False,
    resume_download=True  # 显式开启断点续传（新版本默认自动开启）
)