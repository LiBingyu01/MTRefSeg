import os
import json
import argparse
import cv2
import numpy as np
from PIL import Image
from tqdm import tqdm


import cv2

def mask_to_polygons(mask_path):
    """
    读取二值化掩码图并将其转换为多边形列表。
    支持 0/1 和 0/255 格式的掩码图像。
    返回格式: [[[x1,y1], [x2,y2], ...], ...]
    """
    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    if mask is None:
        return None
    
    # 将阈值设为 0。这样大于 0 的像素（1 或 255）都会变成 255
    _, binary = cv2.threshold(mask, 0, 255, cv2.THRESH_BINARY)
    
    # 提取外部轮廓
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    poly_pairs = []
    for contour in contours:
        # 多边形至少需要3个点
        if len(contour) >= 3:
            # contour 的原始形状是 (N, 1, 2)，使用 squeeze 去掉中间的维度并转换为列表
            poly = contour.squeeze(1).tolist()
            
            # 有时 squeeze 后一维数组会导致 tolist 格式不符，增加一层安全检查
            if isinstance(poly[0], (int, float)): 
                poly = [poly]
                
            poly_pairs.append(poly)
            
    return poly_pairs


def convert_split(data_root, split, output_path):
    ref_dir   = os.path.join(data_root, split, "referring_expression")
    a_dir     = os.path.join(data_root, split, "A")
    b_dir     = os.path.join(data_root, split, "B")
    mask_dir  = os.path.join(data_root, split, "masks")

    samples = []
    json_files = sorted(os.listdir(ref_dir))

    for fname in tqdm(json_files, desc=split):
        stem = os.path.splitext(fname)[0]   # e.g. "BANDON_bj_t1VSt2_L81_00655_784311"

        with open(os.path.join(ref_dir, fname)) as f:
            meta = json.load(f)

        img_a = os.path.join(a_dir, stem + ".jpg")
        img_b = os.path.join(b_dir, stem + ".jpg")

        if not os.path.exists(img_a) or not os.path.exists(img_b):
            # try .png
            img_a = os.path.join(a_dir, stem + ".png")
            img_b = os.path.join(b_dir, stem + ".png")
        if not os.path.exists(img_a):
            print(f"[WARN] image not found: {img_a}, skipping")
            continue

        # get image size from B (reference for masks)
        with Image.open(img_b) as im:
            w, h = im.size

        # 读取新的 JSON 格式中的文本表达式
        expressions = meta.get("referring_expressions", [])
        
        if not expressions:
            print(f"[WARN] {stem}: no expressions found, skipping")
            continue

        # 遍历每一个表达式并寻找对应的掩码图 {idx}.png
        for idx, expr in enumerate(expressions):
            mask_path = os.path.join(mask_dir, stem, f"{idx}.png")
            
            if not os.path.exists(mask_path):
                print(f"[WARN] Mask not found: {mask_path}, skipping this expression.")
                continue

            # 从掩码图提取多边形坐标
            poly_pairs = mask_to_polygons(mask_path)
            
            if poly_pairs is None:
                print(f"[WARN] Failed to read mask: {mask_path}, skipping this expression.")
                continue

            sample = {
                "image": [img_a, img_b],
                "conversations": [
                    {
                        "from": "human",
                        "value": (
                            "<ImageHere> is the pre-change image, "
                            "<ImageHere> is the post-change image. "
                            f"Segment the {expr}. [SEG]"
                        ),
                    },
                    {
                        "from": "bot",
                        "value": "Sure, [SEG].",
                    },
                ],
                "polygons_changeref": {
                    "h": h,
                    "w": w,
                    "polygons": poly_pairs,   # list of rings, each ring is [[x,y],...]
                },
            }
            samples.append(sample)

    with open(output_path, "w") as f:
        json.dump(samples, f)
    print(f"Saved {len(samples)} samples -> {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # 修改 data_root 为公共的父级目录
    parser.add_argument("--data_root", default="/lby_data01/zhaozy/lby/ChangeRef_Clear")
    parser.add_argument("--output_dir", default="/lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/GeoPixel-main/data")
    # 将提取出的文件夹名称作为 splits 的默认列表
    parser.add_argument("--splits", nargs="+", default=[
        "NS_FINAL_CLEAN_train", 
        "NS_FINAL_CLEAN_val", 
        "RS_FINAL_CLEAN_train", 
        "RS_FINAL_CLEAN_val", 
        "train_FINAL_CLEAN", 
        "val_FINAL_CLEAN"
    ])
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    for split in args.splits:
        split_path = os.path.join(args.data_root, split)
        if not os.path.isdir(split_path):
            print(f"[SKIP] {split_path} not found")
            continue
        out = os.path.join(args.output_dir, f"changeref_{split}.json")
        convert_split(args.data_root, split, out)