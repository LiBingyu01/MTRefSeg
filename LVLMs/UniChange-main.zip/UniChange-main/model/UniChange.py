from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BitsAndBytesConfig, CLIPVisionModel

from utils.utils import (DEFAULT_IM_END_TOKEN, DEFAULT_IM_START_TOKEN,
                         DEFAULT_IMAGE_PATCH_TOKEN)

from .llava.model.language_model.llava_llama import (LlavaLlamaForCausalLM,
                                                     LlavaLlamaModel)
from .segment_anything import build_sam_vit_h, build_cd_sam_vit_h
from .common import LayerNorm2d, FusionModule, AggregatorModel
from peft import get_peft_model, LoraConfig
import sys
import os
sys.path.append('./ARSeg')
from opencd.models import FoundationEncoderDecoder

sys.path.append('/UniChange')
import numpy as np
from skimage import io
from .seg_loss import create_loss_functions

import math


def dice_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    num_masks: float,
    scale=1000,
    eps=1e-6,
):
    """
    Compute the DICE loss, similar to generalized IOU for masks
    Args:
        inputs: A float tensor of arbitrary shape.
                The predictions for each example.
        targets: A float tensor with the same shape as inputs. Stores the binary
                 classification label for each element in inputs
                 (0 for the negative class and 1 for the positive class).
    """
    inputs = inputs.sigmoid()
    inputs = inputs.flatten(1, 2)
    targets = targets.flatten(1, 2)
    numerator = 2 * (inputs / scale * targets).sum(-1)
    denominator = (inputs / scale).sum(-1) + (targets / scale).sum(-1)
    loss = 1 - (numerator + eps) / (denominator + eps)
    loss = loss.sum() / (num_masks + 1e-8)
    return loss


def sigmoid_ce_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    num_masks: float,
):
    """
    Args:
        inputs: A float tensor of arbitrary shape.
                The predictions for each example.
        targets: A float tensor with the same shape as inputs. Stores the binary
                 classification label for each element in inputs
                 (0 for the negative class and 1 for the positive class).
    Returns:
        Loss tensor
    """
    loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction="none")
    loss = loss.flatten(1, 2).mean(1).sum() / (num_masks + 1e-8)
    return loss


def create_model(model_path: str):
    file_name = os.path.basename(model_path)
    if file_name == 'ViT_L.pth' or file_name == 'vit-large-p16_sam-pre_3rdparty_sa1b-1024px_20230411-595feafd.pth':
        arch1 = 'large'
        in_channels1 = 1024
    elif file_name == 'ViT_B.pth':
        arch1 = 'base'
        in_channels1 = 768
    else:
        raise ValueError(f"Unsupported model file: {file_name}")

    model = FoundationEncoderDecoder(
        backbone=dict(
            type='ViTSAM_Normal',
            arch=arch1,
            img_size=512,
            patch_size=16,
            in_channels=3,
            out_channels=-1,
            use_abs_pos=True,
            use_rel_pos=True,
            window_size=7,
            drop_path_rate=0.1,
            init_cfg=None
        ),
        decode_head=dict(
            type='Foundation_Decoder_v1',
            in_channels=in_channels1,
            out_channels=256,
            drop=0.0,
            loss_type='BCELoss',
            num_classes=2,
            loss_weight=[1, 1, 1],
            fake_loss_weight=0,
            init_cfg=None,
            finetune_cfg=None,
        ),
        train_cfg=None,
        test_cfg=None,
        data_preprocessor=dict(
            type='FoundationInputSegDataPreProcessor',
            mean=[123.675, 116.28, 103.53] * 2,
            std=[58.395, 57.12, 57.375] * 2,
            bgr_to_rgb=True,
            rgb_to_bgr=False,
            size_divisor=32,
            pad_val=0,
            seg_pad_val=255,
            test_cfg=dict(size_divisor=32),
        )
    )

    if model_path:
        checkpoint = torch.load(model_path, map_location='cpu')
        model.load_state_dict(checkpoint['state_dict'], strict=False)

    return model

def extract_masks(seg_logits_list, data_samples, cls_num=None):
    """
    UniChange 版本：
    seg_logits_list 中的每个元素都对应一个 CD query 的输出。
    每个输出形状通常是 [1, 3, H, W]，其中第 3 个通道是 cd_logits。
    最终返回 [num_queries, H, W] 的 pred_mask。
    """
    if len(seg_logits_list) == 0:
        raise ValueError("seg_logits_list is empty. No mask logits were generated.")

    pred_masks_list = []

    for seg_logits in seg_logits_list:
        if seg_logits.dim() != 4:
            raise ValueError(f"Unexpected seg_logits shape: {seg_logits.shape}")

        # 常见情况：[1, 3, H, W] -> 取 cd_logits
        if seg_logits.shape[1] == 3:
            _, _, cd_logits = torch.split(seg_logits, [1, 1, 1], dim=1)
        # 如果 decoder 只返回单通道，也兼容
        elif seg_logits.shape[1] == 1:
            cd_logits = seg_logits
        else:
            raise ValueError(
                f"Unexpected channel size in seg_logits: {seg_logits.shape}"
            )

        pred_masks_list.append(cd_logits)

    # [num_queries, 1, H, W]
    pred_cd_logits = torch.cat(pred_masks_list, dim=0)

    # [num_queries, H, W]
    pred_mask = pred_cd_logits.squeeze(1)

    gt_semantic_segs_cd = [s['gt_sem_seg']['data'] for s in data_samples]
    gt_cd = torch.stack(gt_semantic_segs_cd, dim=0)
    # gt_cd shape: [1, 1, H, W] -> squeeze to [H, W], kept as tensor
    gt_mask = gt_cd[0].squeeze(0).detach()

    return pred_mask, gt_mask


class UniChangeMetaModel:
    def __init__(
        self,
        config,
        **kwargs,
    ):
        super(UniChangeMetaModel, self).__init__(config)

        self.config = config

        # ============================================================
        # Robust config / kwargs fallback
        # ============================================================

        # train_mask_decoder
        if "train_mask_decoder" in kwargs:
            self.config.train_mask_decoder = kwargs["train_mask_decoder"]
        elif not hasattr(self.config, "train_mask_decoder"):
            self.config.train_mask_decoder = True

        # out_dim
        if "out_dim" in kwargs:
            self.config.out_dim = kwargs["out_dim"]
        elif not hasattr(self.config, "out_dim"):
            self.config.out_dim = 256

        # vision_pretrained
        self.vision_pretrained = kwargs.get(
            "vision_pretrained",
            getattr(self.config, "vision_pretrained", None),
        )

        if self.vision_pretrained is None:
            raise ValueError(
                "vision_pretrained is None. "
                "Please pass --vision_pretrained or add vision_pretrained to config.json."
            )

        # 写回 config，保证后续 save/load 都能拿到
        self.config.vision_pretrained = self.vision_pretrained

        # vision_tower / mm_vision_tower 也顺手兜底
        vision_tower = kwargs.get(
            "vision_tower",
            getattr(self.config, "vision_tower", None),
        )

        if vision_tower is None:
            vision_tower = getattr(self.config, "mm_vision_tower", None)

        if vision_tower is not None:
            self.config.vision_tower = vision_tower
            self.config.mm_vision_tower = vision_tower

        # ============================================================
        # Initialize UniChange modules
        # ============================================================
        self.initialize_UniChange_modules(self.config)

    def initialize_UniChange_modules(self, config):
        self.visual_model = create_model(self.vision_pretrained)

        for param in self.visual_model.parameters():
            param.requires_grad = True

        if config.train_mask_decoder:
            self.visual_model.decode_head.train()
            for param in self.visual_model.decode_head.parameters():
                param.requires_grad = True

        # Projection layer
        in_dim = config.hidden_size
        out_dim = config.out_dim

        text_fc = [
            nn.Linear(in_dim, in_dim),
            nn.ReLU(inplace=True),
            nn.Linear(in_dim, out_dim),
            nn.Dropout(0.0),
        ]

        self.text_hidden_fcs = nn.ModuleList([nn.Sequential(*text_fc)])
        self.text_hidden_fcs.train()

        for param in self.text_hidden_fcs.parameters():
            param.requires_grad = True

class UniChangeModel(UniChangeMetaModel, LlavaLlamaModel):
    def __init__(
        self,
        config,
        **kwargs,
    ):
        self.config = config
        super(UniChangeModel, self).__init__(config, **kwargs)
        self.initialize_UniChange_modules(self.config)
        self.config.use_cache = False
        self.config.vision_tower = self.config.mm_vision_tower
        self.config.mm_vision_select_feature = "patch"
        self.config.image_aspect_ratio = "square"
        self.config.image_grid_pinpoints = None
        self.config.tune_mm_mlp_adapter = False
        self.config.freeze_mm_mlp_adapter = True
        self.config.pretrain_mm_mlp_adapter = None
        self.config.mm_use_im_patch_token = False


class UniChangeForCausalLM(LlavaLlamaForCausalLM):
    def __init__(
        self,
        config,
        **kwargs,
    ):
        self.ce_loss_weight = kwargs.pop("ce_loss_weight", None)
        self.dice_loss_weight = kwargs.pop("dice_loss_weight", None)
        self.bce_loss_weight = kwargs.pop("bce_loss_weight", None)
        self.seg_token_idx = kwargs.pop("seg_token_idx", None)

        if self.seg_token_idx is None:
            self.seg_token_idx = getattr(config, "seg_token_idx", None)

        if self.seg_token_idx is None:
            raise ValueError(
                "seg_token_idx is required but not found in kwargs or config. "
                "Please pass seg_token_idx to from_pretrained() or add it to config.json."
            )

        if not hasattr(config, "train_mask_decoder"):
            config.mm_use_im_start_end = kwargs.pop("use_mm_start_end", True)
            config.mm_vision_tower = kwargs.get(
                "vision_tower", "openai/clip-vit-large-patch14"
            )
        else:
            config.mm_vision_tower = config.vision_tower

        super().__init__(config)

        self.model = UniChangeModel(config, **kwargs)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self.post_init()

    def forward(self, **kwargs):
        if "past_key_values" in kwargs:
            return super().forward(**kwargs)
        return self.model_forward(**kwargs)

    def model_forward(
        self,
        images_t1: torch.FloatTensor,
        images_t2: torch.FloatTensor,
        images_clip_t1: torch.FloatTensor,
        images_clip_t2: torch.FloatTensor,
        input_ids: torch.LongTensor,
        labels: torch.LongTensor,
        attention_masks: torch.LongTensor,
        offset: torch.LongTensor,
        masks_list: List[torch.FloatTensor],
        label_list: List[torch.Tensor],
        resize_list: List[tuple],
        inference: bool = False,
        # ChangeRef 格式：dataloader 已处理好
        rsinputs: torch.FloatTensor = None,
        rsdata_samples: List[dict] = None,
        label1_list=None,
        label2_list=None,
        **kwargs,
    ):
        """
        基于 LISA.py 的数据加载流程，但使用 FoundationEncoderDecoder
        进行双时相特征提取和 mask 生成。

        支持两种数据格式:
        1. LEVIR-CD+ 风格: 在 forward 内部从 images_t1/t2 生成 rsinputs/rsdata_samples
        2. ChangeRef 风格: rsinputs/rsdata_samples 由 dataloader (process_single_sample_change_ref) 生成
        """
        batch_size = images_t1.shape[0]
        assert batch_size == len(offset) - 1

        # ========== LLM Forward (来自 LISA.py，保持不变) ==========
        if inference:
            n_batch = 1
            length = input_ids.shape[0]
            assert images_clip_t2.shape[0] == 1
            images_clip_t1_extend = images_clip_t1.expand(length, -1, -1, -1).contiguous()
            images_clip_t2_extend = images_clip_t2.expand(length, -1, -1, -1).contiguous()
            output_hidden_states = []
            for i in range(n_batch):
                start_i, end_i = i * length, min((i + 1) * length, input_ids.shape[0])
                output_i = super().forward(
                    images_t1=images_clip_t1_extend[: end_i - start_i],
                    images_t2=images_clip_t2_extend[: end_i - start_i],
                    attention_mask=attention_masks[start_i:end_i],
                    input_ids=input_ids[start_i:end_i],
                    output_hidden_states=True,
                )
                output_hidden_states.append(output_i.hidden_states)
                torch.cuda.empty_cache()

            output_hidden_states_list = []
            output_hidden_states_level = torch.cat(output_hidden_states, dim=0)
            output_hidden_states_list.append(output_hidden_states_level)
            output_hidden_states = output_hidden_states_list
            output = None
        else:
            images_clip_t1_list = []
            images_clip_t2_list = []
            for i in range(len(offset) - 1):
                start_i, end_i = offset[i], offset[i + 1]
                images_clip_t1_i = (
                    images_clip_t1[i]
                    .unsqueeze(0)
                    .expand(end_i - start_i, -1, -1, -1)
                    .contiguous()
                )
                images_clip_t2_i = (
                    images_clip_t2[i]
                    .unsqueeze(0)
                    .expand(end_i - start_i, -1, -1, -1)
                    .contiguous()
                )
                images_clip_t1_list.append(images_clip_t1_i)
                images_clip_t2_list.append(images_clip_t2_i)

            images_clip_t1 = torch.cat(images_clip_t1_list, dim=0)
            images_clip_t2 = torch.cat(images_clip_t2_list, dim=0)

            output = super().forward(
                images_t1=images_clip_t1,
                images_t2=images_clip_t2,
                attention_mask=attention_masks,
                input_ids=input_ids,
                labels=labels,
                output_hidden_states=True,
            )
            output_hidden_states = output.hidden_states

        # ========== 提取 text embeddings (来自 LISA.py) ==========
        hidden_states = []
        assert len(self.model.text_hidden_fcs) == 1
        hidden_states.append(self.model.text_hidden_fcs[0](output_hidden_states[-1]))
        last_hidden_state = torch.stack(hidden_states, dim=-1).sum(dim=-1)

        # 动态计算 seg token 在扩展后的 hidden_state 中的物理索引
        seg_token_mask = torch.zeros(
            (last_hidden_state.shape[0], last_hidden_state.shape[1]),
            dtype=torch.bool,
            device=last_hidden_state.device
        )

        for b_idx in range(input_ids.shape[0]):
            cur_input_ids = input_ids[b_idx]
            seg_indices = torch.where(cur_input_ids == self.seg_token_idx)[0]
            image_indices = torch.where(cur_input_ids == -200)[0]
            num_images = len(image_indices)
            if num_images > 0:
                patch_per_image = (last_hidden_state.shape[1] - input_ids.shape[1]) // num_images
            else:
                patch_per_image = 0
            for seg_idx in seg_indices:
                images_before_seg = (image_indices < seg_idx).sum()
                physical_idx = seg_idx + images_before_seg * patch_per_image
                if physical_idx < seg_token_mask.shape[1]:
                    seg_token_mask[b_idx, physical_idx] = True

        pred_embeddings = last_hidden_state[seg_token_mask]

        seg_token_counts = seg_token_mask.int().sum(-1)
        seg_token_offset = seg_token_counts.cumsum(-1)
        seg_token_offset = torch.cat(
            [torch.zeros(1).long().cuda(), seg_token_offset], dim=0
        )
        seg_token_offset = seg_token_offset[offset]

        pred_embeddings_ = []
        for i in range(len(seg_token_offset) - 1):
            start_i, end_i = seg_token_offset[i], seg_token_offset[i + 1]
            pred_embeddings_.append(pred_embeddings[start_i:end_i])
        pred_embeddings = pred_embeddings_



        # ========== FoundationEncoderDecoder 预处理 ==========
        # 支持两种数据格式:
        # 1. ChangeRef 格式: rsinputs/rsdata_samples 已由 dataloader 生成
        # 2. LEVIR-CD+ 风格: 在 forward 内部从 images_t1/t2 生成
        if rsinputs is None or rsdata_samples is None:
            # LEVIR-CD+ 风格: 从 images_t1/t2 生成
            images_t1_3ch = images_t1
            images_t2_3ch = images_t2
            if images_t1_3ch.shape[1] == 6:
                images_t1_3ch, images_t2_3ch = torch.split(images_t1_3ch, 3, dim=1)

            rsinputs = torch.cat([images_t1_3ch, images_t2_3ch], dim=1)

            rsdata_samples = []
            for i in range(batch_size):
                h, w = label_list[i].shape
                rsdata_samples.append({
                    'metainfo': {
                        'img_shape': (h, w),
                        'ori_shape': (h, w),
                        'padding_size': [0, 0, 0, 0],
                    },
                    'gt_sem_seg': {
                        'data': masks_list[i] if i < len(masks_list) else torch.zeros((1, h, w), device=rsinputs.device)
                    },
                })

            model_data = {
                'inputs': rsinputs,
                'data_samples': rsdata_samples
            }
            data = self.model.visual_model.data_preprocessor(model_data, False)
            inputs = data['inputs'].to(torch.bfloat16)
            data_samples_list = data['data_samples']
        else:
            # ChangeRef 格式: 直接使用 dataloader 生成的 rsinputs/rsdata_samples
            # 注意: dataloader 返回的 rsinputs 是 6 通道 Tensor, rsdata_samples 是 list of dict
            inputs = rsinputs.to(torch.bfloat16)
            data_samples_list = rsdata_samples

        # ========== FoundationEncoderDecoder 双时相特征提取 ==========
        x = self.model.visual_model.extract_feat(inputs)
        b = int(len(x[0]) / 2)
        x_tensor = x[0]
        first_half = x_tensor[:b]
        second_half = x_tensor[b:]
        x_list = []
        for i in range(b):
            pair = torch.stack([first_half[i], second_half[i]], dim=0)
            x_list.append((pair,))

        # ========== FoundationDecoder_v1 mask 生成 ==========
        all_gt_masks = []
        all_pred_masks = []

        for i in range(len(pred_embeddings)):
            seg_logits_list = []

            # CD (change detection) query
            cls_num = pred_embeddings[i].shape[0]
            for j in range(cls_num):
                seg_query = pred_embeddings[i][j].unsqueeze(0)
                data_samples = [data_samples_list[i]]
                x = x_list[i]
                flag = "CD"
                seg_logits = self.model.visual_model.decode_head.forward(
                    x, data_samples, seg_query, None, None, flag, None
                )
                seg_logits_list.append(seg_logits)

            pred_mask, gt_mask = extract_masks(seg_logits_list, data_samples)
            all_gt_masks.append(gt_mask)
            all_pred_masks.append(pred_mask)

        model_output = output
        gt_masks = masks_list

        if inference:
            return {
                "pred_masks": all_pred_masks,
                "gt_masks": all_gt_masks,
            }

        # ========== Loss 计算 ==========
        ce_loss = model_output.loss
        ce_loss = ce_loss * self.ce_loss_weight
        mask_bce_loss = 0
        mask_dice_loss = 0
        num_masks = 0
        for batch_idx in range(len(all_pred_masks)):
            gt_mask = gt_masks[batch_idx]

            if not isinstance(gt_mask, torch.Tensor):
                gt_mask = torch.tensor(gt_mask, device=all_pred_masks[batch_idx].device)
            else:
                gt_mask = gt_mask.to(device=all_pred_masks[batch_idx].device)

            pred_mask = all_pred_masks[batch_idx]

            # 保证 dtype 一致
            gt_mask = gt_mask.to(dtype=pred_mask.dtype)

            # 保证至少是 [N, H, W]
            if gt_mask.dim() == 2:
                gt_mask = gt_mask.unsqueeze(0)
            if pred_mask.dim() == 2:
                pred_mask = pred_mask.unsqueeze(0)

            # 只要空间尺寸不一致，就把 pred logits resize 到 gt 尺寸
            if pred_mask.shape[-2:] != gt_mask.shape[-2:]:
                pred_mask = F.interpolate(
                    pred_mask.unsqueeze(1),               # [N,1,H,W]
                    size=gt_mask.shape[-2:],              # 例如 (480, 640)
                    mode="bilinear",
                    align_corners=False,
                ).squeeze(1)                              # [N,H,W]

            # query 数必须一致
            assert gt_mask.shape[0] == pred_mask.shape[0], \
                f"gt_mask.shape: {gt_mask.shape}, pred_mask.shape: {pred_mask.shape}"

            mask_bce_loss += (
                sigmoid_ce_loss(pred_mask, gt_mask, num_masks=gt_mask.shape[0])
                * gt_mask.shape[0]
            )
            mask_dice_loss += (
                dice_loss(pred_mask, gt_mask, num_masks=gt_mask.shape[0])
                * gt_mask.shape[0]
            )
            num_masks += gt_mask.shape[0]

        mask_bce_loss = self.bce_loss_weight * mask_bce_loss / (num_masks + 1e-8)
        mask_dice_loss = self.dice_loss_weight * mask_dice_loss / (num_masks + 1e-8)
        mask_loss = mask_bce_loss + mask_dice_loss

        loss = ce_loss + mask_loss

        return {
            "loss": loss,
            "ce_loss": ce_loss,
            "mask_bce_loss": mask_bce_loss,
            "mask_dice_loss": mask_dice_loss,
            "mask_loss": mask_loss,
        }
        
    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        images_t1=None,
        images_t2=None,
        **kwargs,
    ):
        model_inputs = super().prepare_inputs_for_generation(
            input_ids=input_ids,
            past_key_values=past_key_values,
            attention_mask=attention_mask,
            inputs_embeds=inputs_embeds,
            **kwargs,
        )

        if images_t1 is not None:
            model_inputs["images_t1"] = images_t1
        if images_t2 is not None:
            model_inputs["images_t2"] = images_t2

        return model_inputs

    def evaluate(
        self,
        images_clip_t1,
        images_t1,
        images_clip_t2,
        images_t2,
        input_ids,
        resize_list_t1,
        original_size_list_t1,
        resize_list_t2,
        original_size_list_t2,
        max_new_tokens=32,
        tokenizer=None,
        rsinputs=None,
        rsdata_samples=None,
    ):
        with torch.no_grad():
            # 1. LLM 生成
            outputs = self.generate(
                images_t1=images_clip_t1,
                images_t2=images_clip_t2,
                input_ids=input_ids,
                max_new_tokens=max_new_tokens,
                num_beams=1,
                output_hidden_states=True,
                return_dict_in_generate=True,
            )

            output_hidden_states = outputs.hidden_states[-1]
            output_ids = outputs.sequences

            # 2. 动态找到 [SEG] token 在扩展后的 hidden_state 中的物理索引
            hidden_states = []
            assert len(self.model.text_hidden_fcs) == 1
            hidden_states.append(self.model.text_hidden_fcs[0](output_hidden_states))
            last_hidden_state = torch.stack(hidden_states, dim=-1).sum(dim=-1)

            seg_token_mask = torch.zeros(
                (last_hidden_state.shape[0], last_hidden_state.shape[1]),
                dtype=torch.bool,
                device=last_hidden_state.device
            )

            for b_idx in range(output_ids.shape[0]):
                cur_output_ids = output_ids[b_idx]

                # 找生成结果里的 [SEG]
                seg_indices = torch.where(cur_output_ids == self.seg_token_idx)[0]

                # 找 image token，和训练保持一致
                image_indices = torch.where(cur_output_ids == -200)[0]

                num_images = len(image_indices)
                if num_images > 0:
                    patch_per_image = (last_hidden_state.shape[1] - output_ids.shape[1]) // num_images
                else:
                    patch_per_image = 0

                for seg_idx in seg_indices:
                    images_before_seg = (image_indices < seg_idx).sum()
                    physical_idx = seg_idx + images_before_seg * patch_per_image
                    if physical_idx < seg_token_mask.shape[1]:
                        seg_token_mask[b_idx, physical_idx] = True

            pred_embeddings = last_hidden_state[seg_token_mask]

            seg_token_counts = seg_token_mask.int().sum(-1)
            seg_token_offset = seg_token_counts.cumsum(-1)
            seg_token_offset = torch.cat(
                [torch.zeros(1, device=seg_token_offset.device, dtype=torch.long), seg_token_offset],
                dim=0
            )

            pred_embeddings_ = []
            for i in range(len(seg_token_offset) - 1):
                start_i, end_i = seg_token_offset[i], seg_token_offset[i + 1]
                pred_embeddings_.append(pred_embeddings[start_i:end_i])
            pred_embeddings = pred_embeddings_

            # 3. FoundationEncoderDecoder 预处理
            batch_size = images_t1.shape[0]
            if rsinputs is None or rsdata_samples is None:
                # LEVIR-CD+ 风格
                images_t1_3ch = images_t1
                images_t2_3ch = images_t2
                if images_t1_3ch.shape[1] == 6:
                    images_t1_3ch, images_t2_3ch = torch.split(images_t1_3ch, 3, dim=1)

                rsinputs = torch.cat([images_t1_3ch, images_t2_3ch], dim=1)

                rsdata_samples = []
                for i in range(batch_size):
                    h, w = original_size_list_t2[i]
                    rsdata_samples.append({
                        'metainfo': {
                            'img_shape': (h, w),
                            'ori_shape': (h, w),
                            'padding_size': [0, 0, 0, 0],
                        },
                        'gt_sem_seg': {
                            'data': torch.zeros((1, h, w), device=rsinputs.device)
                        },
                    })

                model_data = {
                    'inputs': rsinputs,
                    'data_samples': rsdata_samples
                }
                data = self.model.visual_model.data_preprocessor(model_data, False)
                inputs = data['inputs'].to(torch.bfloat16)
                data_samples_list = data['data_samples']
            else:
                # ChangeRef 格式
                inputs = rsinputs.to(torch.bfloat16)
                data_samples_list = rsdata_samples

            # 4. 双时相特征提取
            x = self.model.visual_model.extract_feat(inputs)
            b = int(len(x[0]) / 2)
            x_tensor = x[0]
            first_half = x_tensor[:b]
            second_half = x_tensor[b:]
            x_list = []
            for i in range(b):
                pair = torch.stack([first_half[i], second_half[i]], dim=0)
                x_list.append((pair,))

            # 5. Mask 生成
            pred_masks = []
            for i in range(len(pred_embeddings)):
                seg_logits_list = []

                cls_num = pred_embeddings[i].shape[0]
                
                if cls_num == 0:
                    raise ValueError(
                        f"No [SEG] token/query found for sample {i}. "
                        f"Please check input_ids, prompt template, or seg token insertion."
                    )
        
                for j in range(cls_num):
                    seg_query = pred_embeddings[i][j].unsqueeze(0)
                    data_samples = [data_samples_list[i]]
                    x = x_list[i]
                    flag = "CD"
                    seg_logits = self.model.visual_model.decode_head.forward(
                        x, data_samples, seg_query, None, None, flag, None
                    )
                    seg_logits_list.append(seg_logits)

                pred_mask, _ = extract_masks(seg_logits_list, data_samples, cls_num)
                pred_masks.append(pred_mask)

        return output_ids, pred_masks
