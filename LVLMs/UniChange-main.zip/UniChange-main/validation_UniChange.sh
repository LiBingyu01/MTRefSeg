# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp1: train -> val
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =============================================================================
deepspeed --master_port=24999 train_UniChange.py \
  --version "run_7B/UniChange_bi_fusion_7B" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14" \
  --vision_pretrained "pretrained_weights/ViT_L.pth" \
  --dataset "change_refer" \
  --dataset_dir="/lby_data01/zhaozy/lby" \
  --change_refer_seg_data "ChangeRef_Clear|train_FINAL_CLEAN" \
  --val_dataset "ChangeRef_Clear|val_FINAL_CLEAN" \
  --exp_name "UniChange-bitemporal-run" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --eval_only \
  --epochs 10 2>&1 | tee train_val_7B.log
# =============================================================================

# # # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# # # exp1: NS
# # # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# # # =============================================================================
# deepspeed --master_port=24999 train_UniChange.py \
#   --version "run_7B/UniChange_bi_fusion_7B_NS" \
#   --vision-tower "pretrained_weights/clip-vit-large-patch14" \
#   --vision_pretrained "pretrained_weights/ViT_L.pth" \
#   --dataset "change_refer" \
#   --dataset_dir="/lby_data01/zhaozy/lby" \
#   --change_refer_seg_data "ChangeRef_Clear|NS_FINAL_CLEAN_train" \
#   --val_dataset "ChangeRef_Clear|NS_FINAL_CLEAN_val" \
#   --exp_name "UniChange-bitemporal-run-NS" \
#   --log_base_dir "run_7B" \
#   --steps_per_epoch 500 \
#   --eval_only \
#   --epochs 10 2>&1 | tee train_NS_7B.log
# # # =============================================================================


# # # # =============================================================================
# deepspeed --master_port=24999 train_UniChange.py \
#   --version "run_7B/UniChange_bi_fusion_7B_RS" \
#   --vision-tower "pretrained_weights/clip-vit-large-patch14" \
#   --vision_pretrained "pretrained_weights/ViT_L.pth" \
#   --dataset "change_refer" \
#   --dataset_dir="/lby_data01/zhaozy/lby" \
#   --change_refer_seg_data "ChangeRef_Clear|RS_FINAL_CLEAN_train" \
#   --val_dataset "ChangeRef_Clear|RS_FINAL_CLEAN_val" \
#   --exp_name "UniChange-bitemporal-run-RS" \
#   --log_base_dir "run_7B" \
#   --steps_per_epoch 500 \
#   --eval_only \
#   --epochs 10 2>&1 | tee train_RS_7B.log
# # # # =============================================================================
