#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LVLM_ROOT="$(cd "${ROOT_DIR}/.." && pwd)"
DATA_ROOT="$(bash "${LVLM_ROOT}/prepare_vis_subset.sh")"
OUTPUT_ROOT="${LVLM_ROOT}/vis_segmap/UniChange-main"
UNICHANGE_PYTHON="/lby_data01/zhaozy/lby/miniconda3/envs/unichange/bin/python"
UNICHANGE_SITE_PACKAGES="/lby_data01/zhaozy/lby/miniconda3/envs/unichange/lib/python3.10/site-packages"
mkdir -p "${OUTPUT_ROOT}"

(
  cd "${ROOT_DIR}"
  export PYTHONPATH="${ROOT_DIR}/ARSeg:${UNICHANGE_SITE_PACKAGES}${PYTHONPATH:+:${PYTHONPATH}}"
  CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" "${UNICHANGE_PYTHON}" "${ROOT_DIR}/vis_from_validation_pipeline.py" \
    --version "${ROOT_DIR}/run_7B/UniChange_bi_fusion_7B" \
    --vision-tower "${ROOT_DIR}/pretrained_weights/clip-vit-large-patch14" \
    --vision_pretrained "${ROOT_DIR}/pretrained_weights/ViT_L.pth" \
    --dataset "change_refer" \
    --precision bf16 \
    --dataset_dir "${LVLM_ROOT}/vis_segmap/subset_data" \
    --val_dataset "ChangeRef_Clear|val_FINAL_CLEAN" \
    --output_dir "${OUTPUT_ROOT}" \
    --workers 0 \
    --max_samples 150
)
