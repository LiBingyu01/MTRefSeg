cd ./run_7B/UniChange-bitemporal-run-RS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/UniChange-main
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LLaVA-Lightning-7B-delta-v1-1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/ViT_L.pth" \
  --weight="./run_7B/UniChange-bitemporal-run-RS/pytorch_model.bin" \
  --save_path="./run_7B/UniChange_bi_fusion_7B_RS"




cd ./run_7B/UniChange-bitemporal-run-NS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/UniChange-main
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LLaVA-Lightning-7B-delta-v1-1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/ViT_L.pth" \
  --weight="./run_7B/UniChange-bitemporal-run-NS/pytorch_model.bin" \
  --save_path="./run_7B/UniChange_bi_fusion_7B_NS"




cd ./run_7B/UniChange-bitemporal-run/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /lby_data01/zhaozy/lby/ChangeVLM-Other_MLLM_RCD/LVLM/UniChange-main
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LLaVA-Lightning-7B-delta-v1-1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/ViT_L.pth" \
  --weight="./run_7B/UniChange-bitemporal-run/pytorch_model.bin" \
  --save_path="./run_7B/UniChange_bi_fusion_7B"
