import argparse
import glob
import json
import os
import re
from typing import Any, Dict, Optional

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, CLIPImageProcessor

from ARSeg.PytorchRSBuilding.dataset.rsfunction import train_process_single_sample
from model.UniChange import UniChangeForCausalLM
from model.llava import conversation as conversation_lib
from model.llava.mm_utils import tokenizer_image_token
from model.segment_anything.utils.transforms import ResizeLongestSide
from utils.utils import (
    DEFAULT_IMAGE_TOKEN,
    DEFAULT_IMAGE_TOKEN_T1,
    DEFAULT_IMAGE_TOKEN_T2,
    DEFAULT_IM_END_TOKEN,
    DEFAULT_IM_START_TOKEN,
)


def parse_args(args):
    parser = argparse.ArgumentParser(description="Batch visualization for dual-temporal UniChange")
    parser.add_argument("--version", required=True, help="Path or HF id of checkpoint")
    parser.add_argument("--vision_pretrained", required=True, type=str, help="Path to ViT_L.pth")
    parser.add_argument("--precision", default="bf16", choices=["fp32", "bf16", "fp16"])
    parser.add_argument("--image_size", default=1024, type=int)
    parser.add_argument("--model_max_length", default=512, type=int)
    parser.add_argument("--out_dim", default=256, type=int)
    parser.add_argument("--vision-tower", default="openai/clip-vit-large-patch14", type=str)
    parser.add_argument("--local-rank", default=0, type=int)
    parser.add_argument("--use_mm_start_end", action="store_true", default=True)
    parser.add_argument("--conv_type", default="llava_v1", choices=["llava_v1", "llava_llama_2"])

    parser.add_argument("--json_dir", required=True)
    parser.add_argument("--image_dir_A", required=True)
    parser.add_argument("--image_dir_B", required=True)
    parser.add_argument("--mask_root", default=None)
    parser.add_argument("--output_dir", default="./vis_output_batch")

    parser.add_argument("--max_samples", default=-1, type=int)
    parser.add_argument("--max_expressions", default=-1, type=int)
    parser.add_argument("--save_gt", action="store_true")
    parser.add_argument("--save_canvas", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--only_json", default=None)
    return parser.parse_args(args)


def preprocess(
    x,
    pixel_mean=torch.Tensor([123.675, 116.28, 103.53]).view(-1, 1, 1),
    pixel_std=torch.Tensor([58.395, 57.12, 57.375]).view(-1, 1, 1),
    img_size=1024,
) -> torch.Tensor:
    x = (x - pixel_mean) / pixel_std
    h, w = x.shape[-2:]
    return F.pad(x, (0, img_size - w, 0, img_size - h))


def cast_tensor_precision(x, precision):
    if precision == "bf16":
        return x.bfloat16()
    if precision == "fp16":
        return x.half()
    return x.float()


def move_rsdata_samples_to_cuda(rsdata_samples):
    moved = []
    for sample in rsdata_samples:
        if isinstance(sample, dict):
            sample = dict(sample)
            for k, v in list(sample.items()):
                if isinstance(v, dict):
                    nested = dict(v)
                    for kk, vv in list(nested.items()):
                        if isinstance(vv, torch.Tensor):
                            nested[kk] = vv.cuda(non_blocking=True)
                    sample[k] = nested
                elif isinstance(v, torch.Tensor):
                    sample[k] = v.cuda(non_blocking=True)
        moved.append(sample)
    return moved


def prepare_single_image(image_path, clip_image_processor, transform, args):
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"File not found: {image_path}")

    image_np = cv2.imread(image_path)
    if image_np is None:
        raise ValueError(f"Failed to read image: {image_path}")
    image_np = cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB)
    original_size_list = [image_np.shape[:2]]

    image_clip = clip_image_processor.preprocess(image_np, return_tensors="pt")["pixel_values"][0].unsqueeze(0).cuda()
    image_clip = cast_tensor_precision(image_clip, args.precision)

    image = transform.apply_image(image_np)
    resize_list = [image.shape[:2]]
    image = preprocess(torch.from_numpy(image).permute(2, 0, 1).contiguous(), img_size=args.image_size).unsqueeze(0).cuda()
    image = cast_tensor_precision(image, args.precision)

    return image_np, image_clip, image, resize_list, original_size_list


def build_changeref_inputs(image_path_t1, image_path_t2, label_path, args):
    # ARSeg's only_cd_label pipeline expects label_cd to be an iterable of paths.
    sample = train_process_single_sample(image_path_t1, image_path_t2, [label_path])
    rsinputs = sample["inputs"].unsqueeze(0).cuda(non_blocking=True)
    rsinputs = cast_tensor_precision(rsinputs, args.precision)
    rsdata_samples = move_rsdata_samples_to_cuda([sample["data_samples"]])
    return rsinputs, rsdata_samples


def load_model(args):
    tokenizer = AutoTokenizer.from_pretrained(
        args.version,
        cache_dir=None,
        model_max_length=args.model_max_length,
        padding_side="right",
        use_fast=False,
    )
    tokenizer.pad_token = tokenizer.unk_token
    tokenizer.add_tokens("[SEG]")
    args.seg_token_idx = tokenizer("[SEG]", add_special_tokens=False).input_ids[0]

    if args.use_mm_start_end:
        tokenizer.add_tokens([DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN], special_tokens=True)

    torch_dtype = torch.float32
    if args.precision == "bf16":
        torch_dtype = torch.bfloat16
    elif args.precision == "fp16":
        torch_dtype = torch.float16

    model = UniChangeForCausalLM.from_pretrained(
        args.version,
        torch_dtype=torch_dtype,
        low_cpu_mem_usage=True,
        attn_implementation="flash_attention_2",
        train_mask_decoder=True,
        out_dim=args.out_dim,
        ce_loss_weight=1.0,
        dice_loss_weight=0.5,
        bce_loss_weight=2.0,
        seg_token_idx=args.seg_token_idx,
        vision_pretrained=args.vision_pretrained,
        vision_tower=args.vision_tower,
        use_mm_start_end=args.use_mm_start_end,
    )
    model.config.eos_token_id = tokenizer.eos_token_id
    model.config.bos_token_id = tokenizer.bos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    model.resize_token_embeddings(len(tokenizer))
    model.get_model().initialize_vision_modules(model.get_model().config)
    model = model.to(dtype=torch_dtype, device="cuda")
    model.eval()

    clip_image_processor = CLIPImageProcessor.from_pretrained(model.config.vision_tower)
    transform = ResizeLongestSide(args.image_size)
    conversation_lib.default_conversation = conversation_lib.conv_templates[args.conv_type]
    return model, tokenizer, clip_image_processor, transform


def build_prompt(user_prompt, use_mm_start_end):
    prompt = (
        DEFAULT_IMAGE_TOKEN_T1
        + " is the earlier image, and "
        + DEFAULT_IMAGE_TOKEN_T2
        + " is the later image.\n"
        + f"\n Compare the two images and segment {user_prompt}. Please output segmentation mask."
    )
    return prompt


def run_one_expression(
    model,
    tokenizer,
    args,
    image_clip_t1,
    image_t1,
    resize_list_t1,
    original_size_list_t1,
    image_clip_t2,
    image_t2,
    resize_list_t2,
    original_size_list_t2,
    expr: str,
    rsinputs=None,
    rsdata_samples=None,
):
    conv = conversation_lib.conv_templates[args.conv_type].copy()
    conv.messages = []
    conv.append_message(conv.roles[0], build_prompt(expr, args.use_mm_start_end))
    conv.append_message(conv.roles[1], "[SEG].")
    full_prompt = conv.get_prompt()

    replace_token = DEFAULT_IMAGE_TOKEN
    if args.use_mm_start_end:
        replace_token = DEFAULT_IM_START_TOKEN + DEFAULT_IMAGE_TOKEN + DEFAULT_IM_END_TOKEN
    full_prompt = (
        full_prompt.replace(DEFAULT_IMAGE_TOKEN_T1, replace_token)
        .replace(DEFAULT_IMAGE_TOKEN_T2, replace_token)
    )

    input_ids = tokenizer_image_token(full_prompt, tokenizer, return_tensors="pt").unsqueeze(0).cuda()
    attention_masks = input_ids.ne(tokenizer.pad_token_id)

    h, w = original_size_list_t1[0]
    dummy_label = torch.ones((h, w), device=input_ids.device) * 255
    dummy_masks = torch.zeros((1, h, w), device=input_ids.device)

    with torch.no_grad():
        output_dict = model(
            images_t1=image_t1,
            images_t2=image_t2,
            images_clip_t1=image_clip_t1,
            images_clip_t2=image_clip_t2,
            input_ids=input_ids,
            labels=input_ids,
            attention_masks=attention_masks,
            offset=torch.tensor([0, 1], device=input_ids.device),
            masks_list=[dummy_masks],
            label_list=[dummy_label],
            resize_list=resize_list_t1,
            inference=True,
            conversation_list=[full_prompt],
            rsinputs=rsinputs,
            rsdata_samples=rsdata_samples,
        )
    return "[SEG].", output_dict["pred_masks"]


def safe_name(text: str, max_len: int = 120) -> str:
    text = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff._-]+", "_", text).strip("_")
    return (text or "expr")[:max_len]


def overlay_mask(image_rgb: np.ndarray, mask: np.ndarray, color=(255, 0, 0), alpha=0.5):
    out = image_rgb.copy().astype(np.float32)
    if mask.dtype != np.bool_:
        mask = mask.astype(bool)
    out[mask] = out[mask] * (1 - alpha) + np.array(color, dtype=np.float32) * alpha
    return out.astype(np.uint8)


def put_caption(image_rgb: np.ndarray, text: str):
    canvas = image_rgb.copy()
    words = text.split(" ")
    lines, cur = [], ""
    for w in words:
        nxt = w if not cur else cur + " " + w
        if len(nxt) > 42:
            if cur:
                lines.append(cur)
            cur = w
        else:
            cur = nxt
    if cur:
        lines.append(cur)

    y = 24
    for line in lines[:4]:
        cv2.putText(canvas, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.putText(canvas, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1, cv2.LINE_AA)
        y += 24
    return canvas


def resolve_mask(mask_info: Dict[str, Any], json_dir: str, mask_root: Optional[str], h: int, w: int):
    mask = np.zeros((h, w), dtype=np.uint8)
    loaded = False

    if isinstance(mask_info, dict) and "path" in mask_info:
        raw_path = mask_info["path"]
        candidates = [raw_path] if os.path.isabs(raw_path) else [os.path.join(json_dir, raw_path)]
        if mask_root is not None and not os.path.isabs(raw_path):
            candidates.extend([os.path.join(mask_root, raw_path), os.path.join(mask_root, os.path.basename(raw_path))])
        for p in candidates:
            if os.path.exists(p):
                m = cv2.imread(p, 0)
                if m is not None:
                    mask = (m > 0).astype(np.uint8)
                    loaded = True
                    break

    if (not loaded) and isinstance(mask_info, dict) and "polygons" in mask_info and mask_info["polygons"]:
        for poly in mask_info["polygons"]:
            pts = np.array(poly, dtype=np.int32).reshape((-1, 2))
            cv2.fillPoly(mask, [pts], 1)
        loaded = True

    return mask if loaded else None


def resolve_mask_by_index(mask_root: Optional[str], file_id: str, expr_idx: int, h: int, w: int):
    if mask_root is None:
        return None
    mask = np.zeros((h, w), dtype=np.uint8)
    mask_path = os.path.join(mask_root, file_id, f"{expr_idx}.png")
    if not os.path.exists(mask_path):
        return None
    m = cv2.imread(mask_path, 0)
    if m is None:
        return None
    mask[m > 0] = 1
    return mask


def infer_vis_mode(expr: str) -> str:
    e = expr.strip().lower()
    disappear_keywords = ["disappear", "disappeared", "vanish", "removed", "demolished", "gone", "missing", "消失", "拆除", "移除", "不见"]
    appear_keywords = ["appear", "appeared", "added", "new", "newly", "built", "constructed", "出现", "新增", "新建"]
    has_disappear = any(k in e for k in disappear_keywords)
    has_appear = any(k in e for k in appear_keywords)
    if has_disappear and not has_appear:
        return "A"
    if has_appear and not has_disappear:
        return "B"
    return "AB"


def build_overlay_items(vis_mode: str, image_np_t1: np.ndarray, image_np_t2: np.ndarray, mask: np.ndarray, color=(255, 0, 0)):
    items = []
    if vis_mode in ("A", "AB"):
        items.append(("_A", overlay_mask(image_np_t1, mask, color=color, alpha=0.5), "on A/T1"))
    if vis_mode in ("B", "AB"):
        items.append(("_B", overlay_mask(image_np_t2, mask, color=color, alpha=0.5), "on B/T2"))
    return items


def save_canvas_dynamic(items, save_path):
    panels = [put_caption(img, cap) for img, cap in items]
    canvas = np.concatenate(panels, axis=1)
    cv2.imwrite(save_path, cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR))


def collect_jsons(args):
    if args.only_json is not None:
        return [args.only_json]
    json_paths = sorted(glob.glob(os.path.join(args.json_dir, "*.json")))
    if args.max_samples > 0:
        json_paths = json_paths[: args.max_samples]
    return json_paths


def maybe_mkdir(path):
    os.makedirs(path, exist_ok=True)


def main(cli_args):
    args = parse_args(cli_args)
    maybe_mkdir(args.output_dir)
    model, tokenizer, clip_image_processor, transform = load_model(args)
    json_paths = collect_jsons(args)

    if not json_paths:
        raise RuntimeError(f"No json files found in {args.json_dir}")

    print(f"Found {len(json_paths)} json files")

    for sample_idx, json_path in enumerate(json_paths):
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        file_id = os.path.splitext(os.path.basename(json_path))[0]
        img_name_A = f"{file_id}.jpg"
        img_name_B = f"{file_id}.jpg"
        ref_expressions = data.get("referring_expressions", [])
        mask_infos = data.get("mask", None)

        if args.max_expressions > 0:
            ref_expressions = ref_expressions[: args.max_expressions]
            if isinstance(mask_infos, list):
                mask_infos = mask_infos[: args.max_expressions]

        image_path_t1 = os.path.join(args.image_dir_A, img_name_A)
        image_path_t2 = os.path.join(args.image_dir_B, img_name_B)

        print(f"\n[{sample_idx + 1}/{len(json_paths)}] {os.path.basename(json_path)}")
        print(f"  T1: {image_path_t1}")
        print(f"  T2: {image_path_t2}")
        print(f"  num expressions: {len(ref_expressions)}")

        try:
            image_np_t1, image_clip_t1, image_t1, resize_list_t1, original_size_list_t1 = prepare_single_image(image_path_t1, clip_image_processor, transform, args)
            image_np_t2, image_clip_t2, image_t2, resize_list_t2, original_size_list_t2 = prepare_single_image(image_path_t2, clip_image_processor, transform, args)
        except Exception as e:
            print(f"  image loading error: {e}")
            continue

        sample_stem = os.path.splitext(os.path.basename(json_path))[0]
        sample_out_dir = os.path.join(args.output_dir, sample_stem)
        maybe_mkdir(sample_out_dir)

        for expr_idx, expr in enumerate(ref_expressions):
            expr_slug = safe_name(expr)
            expr_prefix = os.path.join(sample_out_dir, f"{expr_idx:02d}_{expr_slug}")
            pred_mask_path = expr_prefix + "_pred_mask.png"

            if (not args.overwrite) and os.path.exists(pred_mask_path):
                print(f"  skip existing: {pred_mask_path}")
                continue

            try:
                label_path = os.path.join(args.mask_root, file_id, f"{expr_idx}.png") if args.mask_root is not None else None
                rsinputs = None
                rsdata_samples = None
                if label_path is not None and os.path.exists(label_path):
                    rsinputs, rsdata_samples = build_changeref_inputs(image_path_t1, image_path_t2, label_path, args)

                text_output, pred_masks = run_one_expression(
                    model=model,
                    tokenizer=tokenizer,
                    args=args,
                    image_clip_t1=image_clip_t1,
                    image_t1=image_t1,
                    resize_list_t1=resize_list_t1,
                    original_size_list_t1=original_size_list_t1,
                    image_clip_t2=image_clip_t2,
                    image_t2=image_t2,
                    resize_list_t2=resize_list_t2,
                    original_size_list_t2=original_size_list_t2,
                    expr=expr,
                    rsinputs=rsinputs,
                    rsdata_samples=rsdata_samples,
                )
            except Exception as e:
                print(f"  expr[{expr_idx}] inference error: {e}")
                continue

            if len(pred_masks) == 0 or pred_masks[0].shape[0] == 0:
                print(f"  expr[{expr_idx}] no predicted masks")
                continue

            pred_mask_tensor = pred_masks[0].detach().float().cpu()
            pred_prob = torch.sigmoid(pred_mask_tensor[0]).numpy()
            pred_bin = (pred_prob > 0.5).astype(np.uint8)
            print(
                "  expr[{idx}] pred stats: logit[min={mn:.4f}, max={mx:.4f}, mean={me:.4f}] "
                "prob_mean={pm:.4f} fg@0.5={fg:.6f}".format(
                    idx=expr_idx,
                    mn=float(pred_mask_tensor[0].min()),
                    mx=float(pred_mask_tensor[0].max()),
                    me=float(pred_mask_tensor[0].mean()),
                    pm=float(pred_prob.mean()),
                    fg=float(pred_bin.mean()),
                )
            )
            cv2.imwrite(pred_mask_path, pred_bin * 255)

            vis_mode = infer_vis_mode(expr)
            pred_items = build_overlay_items(vis_mode, image_np_t1, image_np_t2, pred_bin.astype(bool), color=(255, 0, 0))
            for suffix, vis_img, _ in pred_items:
                cv2.imwrite(expr_prefix + f"_pred_overlay{suffix}.png", cv2.cvtColor(vis_img, cv2.COLOR_RGB2BGR))

            gt_items = []
            if args.save_gt:
                gt_mask = resolve_mask_by_index(args.mask_root, file_id, expr_idx, image_np_t1.shape[0], image_np_t1.shape[1])
                if gt_mask is None and isinstance(mask_infos, list) and expr_idx < len(mask_infos):
                    gt_mask = resolve_mask(mask_infos[expr_idx], args.json_dir, args.mask_root, image_np_t1.shape[0], image_np_t1.shape[1])
                if gt_mask is not None:
                    cv2.imwrite(expr_prefix + "_gt_mask.png", gt_mask * 255)
                    gt_items = build_overlay_items(vis_mode, image_np_t1, image_np_t2, gt_mask.astype(bool), color=(0, 255, 0))
                    for suffix, vis_img, _ in gt_items:
                        cv2.imwrite(expr_prefix + f"_gt_overlay{suffix}.png", cv2.cvtColor(vis_img, cv2.COLOR_RGB2BGR))

            if args.save_canvas:
                canvas_items = [(image_np_t1, "T1"), (image_np_t2, "T2")]
                canvas_items.extend([(img, f"Pred {cap}") for _, img, cap in pred_items])
                canvas_items.extend([(img, f"GT {cap}") for _, img, cap in gt_items])
                save_canvas_dynamic(canvas_items, expr_prefix + "_canvas.png")

            with open(expr_prefix + "_text.txt", "w", encoding="utf-8") as f:
                f.write(f"expression: {expr}\n")
                f.write(f"generated: {text_output}\n")

            print(f"  expr[{expr_idx}] saved -> {expr_prefix}_*")


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
