import argparse
import os
import sys

import torch
import transformers
from peft import LoraConfig, get_peft_model

from model.UniChange import UniChangeForCausalLM
from utils.utils import DEFAULT_IM_END_TOKEN, DEFAULT_IM_START_TOKEN


def parse_args(args):
    parser = argparse.ArgumentParser(
        description="merge lora weights and save model with hf format"
    )

    parser.add_argument(
        "--version",
        default="liuhaotian/llava-llama-2-13b-chat-lightning-preview",
        type=str,
    )
    parser.add_argument("--vis_save_path", default="./vis_output", type=str)

    parser.add_argument(
        "--precision",
        default="bf16",
        type=str,
        choices=["fp32", "bf16", "fp16"],
        help="precision for loading model",
    )

    # SAM / LISA visual model checkpoint
    parser.add_argument(
        "--vision_pretrained",
        default="PATH_TO_SAM_ViT-H",
        type=str,
        help="Path to SAM / LISA visual model checkpoint, e.g. ViT_L.pth",
    )

    # CLIP vision tower
    parser.add_argument(
        "--vision-tower",
        dest="vision_tower",
        default="openai/clip-vit-large-patch14",
        type=str,
        help="Path or HF name of CLIP vision tower",
    )

    parser.add_argument("--out_dim", default=256, type=int)
    parser.add_argument("--image_size", default=1024, type=int)
    parser.add_argument("--model_max_length", default=512, type=int)

    parser.add_argument("--lora_r", default=8, type=int)
    parser.add_argument("--lora_alpha", default=16, type=int)
    parser.add_argument("--lora_dropout", default=0.05, type=float)
    parser.add_argument("--lora_target_modules", default="q_proj,v_proj", type=str)

    parser.add_argument("--local-rank", default=0, type=int, help="node rank")
    parser.add_argument("--train_mask_decoder", action="store_true", default=True)
    parser.add_argument("--use_mm_start_end", action="store_true", default=True)

    parser.add_argument(
        "--conv_type",
        default="llava_v1",
        type=str,
        choices=["llava_v1", "llava_llama_2"],
    )

    parser.add_argument("--weight", default="", type=str, required=True)
    parser.add_argument("--save_path", default="./lisa_model", type=str, required=True)

    return parser.parse_args(args)


def set_unichange_config(model, args):
    """
    Ensure all required UniChange / LISA / vision config fields exist.

    This fixes errors like:
      TypeError: expected str, bytes or os.PathLike object, not NoneType

    caused by config.vision_pretrained being None.
    """

    # Outer config
    model.config.vision_tower = args.vision_tower
    model.config.mm_vision_tower = args.vision_tower
    model.config.vision_pretrained = args.vision_pretrained
    model.config.train_mask_decoder = args.train_mask_decoder
    model.config.out_dim = args.out_dim
    model.config.seg_token_idx = args.seg_token_idx
    model.config.image_size = args.image_size
    model.config.use_mm_start_end = args.use_mm_start_end

    # Inner model config
    inner_config = model.get_model().config
    inner_config.vision_tower = args.vision_tower
    inner_config.mm_vision_tower = args.vision_tower
    inner_config.vision_pretrained = args.vision_pretrained
    inner_config.train_mask_decoder = args.train_mask_decoder
    inner_config.out_dim = args.out_dim
    inner_config.seg_token_idx = args.seg_token_idx
    inner_config.image_size = args.image_size
    inner_config.use_mm_start_end = args.use_mm_start_end


def main(args):
    args = parse_args(args)
    os.makedirs(args.vis_save_path, exist_ok=True)
    os.makedirs(args.save_path, exist_ok=True)

    print("=" * 80)
    print("Merge LoRA weights and save UniChange HF model")
    print("=" * 80)
    print(f"Base version       : {args.version}")
    print(f"Vision tower       : {args.vision_tower}")
    print(f"Vision pretrained  : {args.vision_pretrained}")
    print(f"Weight             : {args.weight}")
    print(f"Save path          : {args.save_path}")
    print(f"Precision          : {args.precision}")
    print("=" * 80)

    if not os.path.exists(args.weight):
        raise FileNotFoundError(f"Weight file not found: {args.weight}")

    if args.vision_pretrained in [None, "", "PATH_TO_SAM_ViT-H"]:
        raise ValueError(
            "Invalid --vision_pretrained. Please pass a real SAM / ViT checkpoint path."
        )

    # ---------------------------------------------------------------------
    # Tokenizer
    # ---------------------------------------------------------------------
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        args.version,
        cache_dir=None,
        model_max_length=args.model_max_length,
        padding_side="right",
        use_fast=False,
    )

    tokenizer.pad_token = tokenizer.unk_token

    tokenizer.add_tokens("[SEG]")
    args.seg_token_idx = tokenizer("[SEG]", add_special_tokens=False).input_ids[0]

    if args.use_mm_start_end:
        tokenizer.add_tokens(
            [DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN],
            special_tokens=True,
        )

    # ---------------------------------------------------------------------
    # Model args
    # ---------------------------------------------------------------------
    model_args = {
        "train_mask_decoder": args.train_mask_decoder,
        "out_dim": args.out_dim,
        "seg_token_idx": args.seg_token_idx,

        # CLIP vision tower
        "vision_tower": args.vision_tower,
        "mm_vision_tower": args.vision_tower,

        # SAM / LISA visual model checkpoint
        "vision_pretrained": args.vision_pretrained,
    }

    torch_dtype = torch.float32
    if args.precision == "bf16":
        torch_dtype = torch.bfloat16
    elif args.precision == "fp16":
        torch_dtype = torch.float16

    # ---------------------------------------------------------------------
    # Load base model
    # ---------------------------------------------------------------------
    model = UniChangeForCausalLM.from_pretrained(
        args.version,
        torch_dtype=torch_dtype,
        low_cpu_mem_usage=True,
        **model_args,
    )

    model.config.eos_token_id = tokenizer.eos_token_id
    model.config.bos_token_id = tokenizer.bos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id

    # Critical fix: make sure configs contain required paths
    set_unichange_config(model, args)

    # ---------------------------------------------------------------------
    # Initialize vision / LISA modules
    # ---------------------------------------------------------------------
    model.get_model().initialize_vision_modules(model.get_model().config)

    vision_tower = model.get_model().get_vision_tower()
    if vision_tower is not None:
        vision_tower.to(dtype=torch_dtype)

    # Re-apply config before LISA module initialization
    set_unichange_config(model, args)
    model.get_model().initialize_UniChange_modules(model.get_model().config)

    # ---------------------------------------------------------------------
    # Add LoRA wrapper
    # ---------------------------------------------------------------------
    lora_r = args.lora_r

    if lora_r > 0:

        def find_linear_layers(model, lora_target_modules):
            cls = torch.nn.Linear
            lora_module_names = set()

            for name, module in model.named_modules():
                if (
                    isinstance(module, cls)
                    and all(
                        x not in name
                        for x in [
                            "visual_model",
                            "vision_tower",
                            "mm_projector",
                            "text_hidden_fcs",
                        ]
                    )
                    and any(x in name for x in lora_target_modules)
                ):
                    lora_module_names.add(name)

            return sorted(list(lora_module_names))

        lora_target_modules = find_linear_layers(
            model,
            args.lora_target_modules.split(","),
        )

        print("LoRA target modules:")
        for name in lora_target_modules:
            print("  ", name)

        lora_config = LoraConfig(
            r=args.lora_r,
            lora_alpha=args.lora_alpha,
            target_modules=lora_target_modules,
            lora_dropout=args.lora_dropout,
            bias="none",
            task_type="CAUSAL_LM",
        )

        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()

    # ---------------------------------------------------------------------
    # Resize embeddings after tokenizer update
    # ---------------------------------------------------------------------
    model.resize_token_embeddings(len(tokenizer))

    # ---------------------------------------------------------------------
    # Load trained / reconstructed fp32 state dict
    # ---------------------------------------------------------------------
    print(f"Loading weight from: {args.weight}")
    state_dict = torch.load(args.weight, map_location="cpu")

    missing, unexpected = model.load_state_dict(state_dict, strict=False)

    print("=" * 80)
    print("load_state_dict finished.")
    print(f"Missing keys: {len(missing)}")
    print(f"Unexpected keys: {len(unexpected)}")

    if len(missing) > 0:
        print("First 20 missing keys:")
        for k in missing[:20]:
            print("  ", k)

    if len(unexpected) > 0:
        print("First 20 unexpected keys:")
        for k in unexpected[:20]:
            print("  ", k)
    print("=" * 80)

    # 如果你确认权重必须完全匹配，可以把 strict=False 改回 strict=True。
    # 但在很多 LoRA/视觉模块保存场景中，strict=False 更稳。

    # ---------------------------------------------------------------------
    # Merge LoRA
    # ---------------------------------------------------------------------
    if hasattr(model, "merge_and_unload"):
        print("Merging LoRA weights...")
        model = model.merge_and_unload()
    else:
        print("No merge_and_unload found. Skip LoRA merge.")

    # Make sure config paths are saved into config.json
    set_unichange_config(model, args)

    # ---------------------------------------------------------------------
    # Save HF model
    # ---------------------------------------------------------------------
    save_state_dict = {}

    for k, v in model.state_dict().items():
        # Keep your original behavior: do not save CLIP vision tower weights.
        # The config will store vision_tower path for future loading.
        if "vision_tower" not in k:
            save_state_dict[k] = v

    print(f"Saving merged model to: {args.save_path}")
    model.save_pretrained(args.save_path, state_dict=save_state_dict)
    tokenizer.save_pretrained(args.save_path)

    print("=" * 80)
    print("Done.")
    print(f"Saved to: {args.save_path}")
    print("=" * 80)


if __name__ == "__main__":
    main(sys.argv[1:])