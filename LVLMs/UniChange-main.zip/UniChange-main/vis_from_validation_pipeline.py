#!/usr/bin/env python3
import argparse
import os
import re
from functools import partial
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
import tqdm
import transformers

from model.UniChange import UniChangeForCausalLM
from model.llava import conversation as conversation_lib
from utils.dataset import ValDataset, collate_fn
from utils.utils import (
    DEFAULT_IM_END_TOKEN,
    DEFAULT_IM_START_TOKEN,
    dict_to_cuda,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="UniChange visualization using the validation pipeline"
    )
    parser.add_argument("--version", required=True, type=str)
    parser.add_argument("--vision-tower", required=True, type=str)
    parser.add_argument("--vision_pretrained", required=True, type=str)
    parser.add_argument("--dataset", default="change_refer", type=str)
    parser.add_argument("--dataset_dir", required=True, type=str)
    parser.add_argument("--val_dataset", required=True, type=str)
    parser.add_argument("--output_dir", required=True, type=str)
    parser.add_argument(
        "--precision",
        default="bf16",
        choices=["fp32", "bf16", "fp16"],
        type=str,
    )
    parser.add_argument("--image_size", default=1024, type=int)
    parser.add_argument("--model_max_length", default=512, type=int)
    parser.add_argument("--out_dim", default=256, type=int)
    parser.add_argument("--workers", default=0, type=int)
    parser.add_argument("--val_batch_size", default=1, type=int)
    parser.add_argument("--max_samples", default=-1, type=int)
    parser.add_argument("--use_mm_start_end", action="store_true", default=True)
    parser.add_argument(
        "--conv_type",
        default="llava_v1",
        choices=["llava_v1", "llava_llama_2"],
        type=str,
    )
    return parser.parse_args()


def rsdata_samples_to_cuda(input_dict):
    if input_dict.get("rsdata_samples") is not None:
        for sample in input_dict["rsdata_samples"]:
            if isinstance(sample, dict):
                for k, v in sample.items():
                    if isinstance(v, dict):
                        for kk, vv in v.items():
                            if isinstance(vv, torch.Tensor):
                                sample[k][kk] = vv.cuda(non_blocking=True)
                    elif isinstance(v, torch.Tensor):
                        sample[k] = v.cuda(non_blocking=True)
    return input_dict


def cast_batch_precision(input_dict, precision):
    if precision == "fp16":
        dtype = torch.half
    elif precision == "bf16":
        dtype = torch.bfloat16
    else:
        dtype = torch.float32

    if "images_t1" in input_dict:
        input_dict["images_t1"] = input_dict["images_t1"].to(dtype)
        input_dict["images_t2"] = input_dict["images_t2"].to(dtype)
        input_dict["images_clip_t1"] = input_dict["images_clip_t1"].to(dtype)
        input_dict["images_clip_t2"] = input_dict["images_clip_t2"].to(dtype)
    else:
        input_dict["images"] = input_dict["images"].to(dtype)
        input_dict["images_clip"] = input_dict["images_clip"].to(dtype)

    if input_dict.get("rsinputs") is not None:
        input_dict["rsinputs"] = input_dict["rsinputs"].to(dtype)
    return input_dict


def load_model(args):
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        args.version,
        cache_dir=None,
        model_max_length=args.model_max_length,
        padding_side="right",
        use_fast=False,
    )
    tokenizer.pad_token = tokenizer.unk_token
    tokenizer.add_tokens("[SEG]")
    args.seg_token_idx = tokenizer("[SEG]", add_special_tokens=False).input_ids[0]

    if args.use_mm_start_end:
        tokenizer.add_tokens(
            [DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN], special_tokens=True
        )

    if args.precision == "bf16":
        torch_dtype = torch.bfloat16
    elif args.precision == "fp16":
        torch_dtype = torch.float16
    else:
        torch_dtype = torch.float32

    model = UniChangeForCausalLM.from_pretrained(
        args.version,
        torch_dtype=torch_dtype,
        low_cpu_mem_usage=True,
        attn_implementation="flash_attention_2",
        train_mask_decoder=True,
        out_dim=args.out_dim,
        ce_loss_weight=1.0,
        dice_loss_weight=0.5,
        bce_loss_weight=2.0,
        seg_token_idx=args.seg_token_idx,
        vision_pretrained=args.vision_pretrained,
        vision_tower=args.vision_tower,
        use_mm_start_end=args.use_mm_start_end,
    )
    model.config.eos_token_id = tokenizer.eos_token_id
    model.config.bos_token_id = tokenizer.bos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    model.resize_token_embeddings(len(tokenizer))
    model.get_model().initialize_vision_modules(model.get_model().config)
    conversation_lib.default_conversation = conversation_lib.conv_templates[
        args.conv_type
    ]

    model = model.to(device="cuda", dtype=torch_dtype)
    model.eval()
    return model, tokenizer


def load_rgb(path):
    image = cv2.imread(str(path))
    if image is None:
        raise FileNotFoundError(f"Failed to read image: {path}")
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)


def safe_name(text, max_len=120):
    text = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff._-]+", "_", text)
    text = text.strip("_")
    if not text:
        text = "expr"
    return text[:max_len]


def overlay_mask(image_rgb, mask, color=(255, 0, 0), alpha=0.5):
    out = image_rgb.copy()
    mask = mask.astype(bool)
    color_arr = np.array(color, dtype=np.float32)
    out_f = out.astype(np.float32)
    out_f[mask] = out_f[mask] * (1 - alpha) + color_arr * alpha
    return out_f.astype(np.uint8)


def put_caption(image_rgb, text):
    canvas = image_rgb.copy()
    lines = []
    words = text.split(" ")
    cur = ""
    for word in words:
        nxt = word if not cur else cur + " " + word
        if len(nxt) > 42:
            if cur:
                lines.append(cur)
            cur = word
        else:
            cur = nxt
    if cur:
        lines.append(cur)

    y = 24
    for line in lines[:4]:
        cv2.putText(
            canvas,
            line,
            (10, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            canvas,
            line,
            (10, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 0, 0),
            1,
            cv2.LINE_AA,
        )
        y += 24
    return canvas


def normalize_expr(expr):
    return expr.strip().lower()


def contains_keyword(expr, keyword):
    if re.search(r"[\u4e00-\u9fff]", keyword):
        return keyword in expr
    pattern = r"\b{}\b".format(re.escape(keyword))
    return re.search(pattern, expr) is not None


def infer_vis_mode(expr):
    expr = normalize_expr(expr)

    disappear_keywords = [
        "disappear",
        "disappeared",
        "disappearing",
        "vanish",
        "vanished",
        "removed",
        "demolished",
        "gone",
        "lost",
        "deleted",
        "missing",
        "消失",
        "拆除",
        "去掉",
        "移除",
        "不见",
    ]
    appear_keywords = [
        "appear",
        "appeared",
        "appearing",
        "added",
        "new",
        "newly",
        "emerged",
        "built",
        "constructed",
        "出现",
        "新增",
        "新建",
    ]
    change_keywords = [
        "change",
        "changed",
        "changing",
        "became",
        "become",
        "turned",
        "repaved",
        "repainted",
        "converted",
        "transformed",
        "modified",
        "increased",
        "decreased",
        "expanded",
        "shrunk",
        "color",
        "colour",
        "状态改变",
        "变成",
        "变为",
        "改变",
        "变化",
        "颜色",
    ]

    has_disappear = any(contains_keyword(expr, keyword) for keyword in disappear_keywords)
    has_appear = any(contains_keyword(expr, keyword) for keyword in appear_keywords)
    has_change = any(contains_keyword(expr, keyword) for keyword in change_keywords)

    if has_disappear and not has_appear and not has_change:
        return "A"
    if has_appear and not has_disappear and not has_change:
        return "B"
    if has_change or (has_disappear and has_appear):
        return "AB"
    return "AB"


def build_overlay_items(vis_mode, image_t1, image_t2, mask, color):
    items = []
    if vis_mode in ("A", "AB"):
        items.append(("_A", overlay_mask(image_t1, mask, color=color), "on A/T1"))
    if vis_mode in ("B", "AB"):
        items.append(("_B", overlay_mask(image_t2, mask, color=color), "on B/T2"))
    return items


def save_canvas(items, save_path):
    panels = [put_caption(image, caption) for image, caption in items]
    canvas = np.concatenate(panels, axis=1)
    cv2.imwrite(str(save_path), cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR))


def align_masks_for_vis(pred_masks, gt_masks):
    if gt_masks.dim() == 2:
        gt_masks = gt_masks.unsqueeze(0)
    gt_masks = gt_masks.float()

    if pred_masks.shape[-2:] != gt_masks.shape[-2:]:
        pred_masks = F.interpolate(
            pred_masks.unsqueeze(1).float(),
            size=gt_masks.shape[-2:],
            mode="bilinear",
            align_corners=False,
        ).squeeze(1)

    pred_prob = torch.sigmoid(pred_masks.float())
    pred_bin = (pred_prob > 0.5).float()
    gt_bin = (gt_masks > 0.5).float()
    return pred_bin, gt_bin


def derive_b_path(path_a):
    path_a = Path(path_a)
    return path_a.parents[1] / "B" / path_a.name


def save_sample_outputs(output_dir, path_a, exprs, pred_masks, gt_masks):
    sample_id = Path(path_a).stem
    path_b = derive_b_path(path_a)
    image_t1 = load_rgb(path_a)
    image_t2 = load_rgb(path_b)

    pred_bin, gt_bin = align_masks_for_vis(pred_masks, gt_masks)
    count = min(len(exprs), pred_bin.shape[0], gt_bin.shape[0])

    sample_dir = Path(output_dir) / sample_id
    sample_dir.mkdir(parents=True, exist_ok=True)

    for expr_idx in range(count):
        expr = exprs[expr_idx]
        expr_prefix = sample_dir / f"{expr_idx:02d}_{safe_name(expr)}"

        pred_mask = pred_bin[expr_idx].detach().float().cpu().numpy().astype(np.uint8)
        gt_mask = gt_bin[expr_idx].detach().float().cpu().numpy().astype(np.uint8)

        cv2.imwrite(str(expr_prefix) + "_pred_mask.png", pred_mask * 255)
        cv2.imwrite(str(expr_prefix) + "_gt_mask.png", gt_mask * 255)

        vis_mode = infer_vis_mode(expr)
        pred_overlay_items = build_overlay_items(
            vis_mode, image_t1, image_t2, pred_mask, color=(255, 0, 0)
        )
        gt_overlay_items = build_overlay_items(
            vis_mode, image_t1, image_t2, gt_mask, color=(0, 255, 0)
        )

        for suffix, overlay_rgb, _ in pred_overlay_items:
            cv2.imwrite(
                str(expr_prefix) + f"_pred_overlay{suffix}.png",
                cv2.cvtColor(overlay_rgb, cv2.COLOR_RGB2BGR),
            )
        for suffix, overlay_rgb, _ in gt_overlay_items:
            cv2.imwrite(
                str(expr_prefix) + f"_gt_overlay{suffix}.png",
                cv2.cvtColor(overlay_rgb, cv2.COLOR_RGB2BGR),
            )

        canvas_items = [(image_t1, "T1 / earlier"), (image_t2, "T2 / later")]
        for _, overlay_rgb, title in pred_overlay_items:
            canvas_items.append((overlay_rgb, f"Pred {title} | {expr}"))
        for _, overlay_rgb, title in gt_overlay_items:
            canvas_items.append((overlay_rgb, f"GT {title}"))
        save_canvas(canvas_items, str(expr_prefix) + "_canvas.jpg")


def build_loader(args, tokenizer):
    dataset = ValDataset(
        args.dataset_dir,
        tokenizer,
        args.vision_tower,
        args.val_dataset,
        args.image_size,
    )
    dataset.json_paths = sorted(dataset.json_paths)
    if args.max_samples > 0:
        dataset.json_paths = dataset.json_paths[: args.max_samples]
    print(f"Visualization set size: {len(dataset.json_paths)}")

    return torch.utils.data.DataLoader(
        dataset,
        batch_size=args.val_batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=False,
        collate_fn=partial(
            collate_fn,
            tokenizer=tokenizer,
            conv_type=args.conv_type,
            use_mm_start_end=args.use_mm_start_end,
            local_rank=0,
        ),
    )


def main():
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for UniChange visualization.")

    os.makedirs(args.output_dir, exist_ok=True)
    model, tokenizer = load_model(args)
    loader = build_loader(args, tokenizer)

    with torch.no_grad():
        for input_dict in tqdm.tqdm(loader, desc="Visualizing UniChange"):
            image_paths = input_dict["image_paths"]
            exprs_batch = input_dict["sampled_classes_list"]
            gt_masks_batch = input_dict["masks_list"]

            input_dict = dict_to_cuda(input_dict)
            input_dict = rsdata_samples_to_cuda(input_dict)
            input_dict = cast_batch_precision(input_dict, args.precision)

            output_dict = model(**input_dict)
            pred_masks_batch = output_dict["pred_masks"]

            for path_a, exprs, pred_masks, gt_masks in zip(
                image_paths, exprs_batch, pred_masks_batch, gt_masks_batch
            ):
                if pred_masks.shape[0] == 0 or len(exprs) == 0:
                    continue
                save_sample_outputs(
                    args.output_dir,
                    path_a,
                    exprs,
                    pred_masks,
                    gt_masks,
                )


if __name__ == "__main__":
    main()
