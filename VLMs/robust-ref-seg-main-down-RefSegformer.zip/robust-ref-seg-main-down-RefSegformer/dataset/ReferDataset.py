import os 
import sys 
import torch.utils.data as data
import torch 
import numpy as np 
from PIL import Image 

import transformers

from dataset.refer import REFER

class ReferDataset(data.Dataset):
    def __init__(self,
                 args,
                 image_transforms=None,
                 max_tokens=20, 
                 split='train',
                 eval_mode=True,
                 logger=None) -> None:
        """
        parameters:
            args: argparse obj
            image_transforms: transforms apply to image and mask
            max_tokens: determined the max length of token 
            split: ['train','val','testA','testB']
            eval_mode: whether in training or evaluating 
        """

        self.classes = []
        self.image_transforms = image_transforms
        self.split = split
        self.args = args
        self.eval_mode=eval_mode
        self.refer=REFER(args.refer_data_root, args.dataset, args.splitBy)

        self.max_tokens=max_tokens

        self.get_ids()
        
        if logger:
            logger.info(f"=> loaded successfully '{args.dataset}', split by {args.splitBy}, split {split}")

    def get_ids(self):
        ref_ids=self.refer.getRefIds(split=self.split)
        img_ids=self.refer.getImgIds(ref_ids)
        # change dict to list
        all_imgs=self.refer.Imgs
        self.imgs=list(all_imgs[i] for i in img_ids)
        
        self.ref_ids=ref_ids
        # input_ids -> input sentence 对应的id
        # attention_masks -> mask掉pad的部分
        self.input_ids=[]
        self.attention_masks=[]
        self.tokenizer = transformers.BertTokenizer.from_pretrained('pretrained_weights/bert-base-uncased')
        
        # pad_id=[0]
        # pad_id = self.tokenizer.convert_tokens_to_ids(self.tokenizer.tokenize('[PAD]'))
        for r in self.ref_ids:
            # for each image
            ref=self.refer.Refs[r]
            # List[Tensor] Tensor shape [1,len]
            sentences_for_ref=[]
            attentions_for_ref=[]
            # for each sentence
            for el in ref['sentences']:
                sentence_raw = el['raw']
                attention_mask = [0] * self.max_tokens
                padded_input_ids = [0] * self.max_tokens
                # `add_special_tokens=True`加入<SOS>和<EOS>
                input_ids = self.tokenizer.encode(text=sentence_raw, add_special_tokens=True)

                # truncation of tokens
                input_ids = input_ids[:self.max_tokens]

                padded_input_ids[:len(input_ids)] = input_ids
                attention_mask[:len(input_ids)] = [1]*len(input_ids)

                sentences_for_ref.append(torch.tensor(padded_input_ids).unsqueeze(0))
                attentions_for_ref.append(torch.tensor(attention_mask).unsqueeze(0))
            # List[List[Tensor]]
            self.input_ids.append(sentences_for_ref)
            self.attention_masks.append(attentions_for_ref)

    def get_classes(self):
        return self.classes

    def get_exist(self, ref, sent_index):
        if "exist" in ref["sentences"][sent_index].keys():
            exist = torch.Tensor([ref["sentences"][sent_index]["exist"]])
        else:
            exist = torch.Tensor([True])
        return exist
        
    def __len__(self):
        return len(self.ref_ids)
    
    def __getitem__(self, index):
            # ... (前面的代码保持不变) ...

            mask_np = np.array(mask)
            target = np.zeros_like(mask_np)
            target[mask_np > 0] = 1
            
            # 1. 这里生成的 target 是 PIL Image
            target_pil = Image.fromarray(target.astype(np.uint8), mode="P") 

            # 2. 同步变换 (Siamese Transform)
            if self.image_transforms is not None:
                seed = np.random.randint(2147483647) 
                
                # --- 变换 Image A ---
                random.seed(seed)
                torch.manual_seed(seed)
                if torch.cuda.is_available(): torch.cuda.manual_seed(seed)
                # 【修改点】传入 target_pil，接收转换后的 target_tensor
                img_A, target_tensor = self.image_transforms(img_A, target_pil)
                
                # --- 变换 Image B ---
                random.seed(seed)
                torch.manual_seed(seed)
                if torch.cuda.is_available(): torch.cuda.manual_seed(seed)
                # 【修改点】依然传入原始的 target_pil (因为 transform 需要 PIL 输入)
                # 我们不需要第二次变换后的 target，所以用 _ 忽略
                img_B, _ = self.image_transforms(img_B, target_pil) 

                # 将最终的 target 指向变换后的 tensor
                target = target_tensor
            else:
                # 如果没有 transform，需要手动转 tensor (视你代码逻辑而定，通常都有 transform)
                # 这里简单处理，假设总是有 transforms
                target = torch.as_tensor(np.array(target_pil), dtype=torch.int64)

            tensor_embeddings = sample['input_ids']
            attention_mask = sample['attention_mask']

            return img_A, img_B, target, tensor_embeddings, attention_mask, exist_tensor