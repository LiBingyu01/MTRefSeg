import os
import json
import torch
import torch.utils.data as data
from PIL import Image
import numpy as np
import random
import nltk
from nltk.tokenize import word_tokenize
from bert.tokenization_bert import BertTokenizer

class ChangeReferDataset(data.Dataset):
    def __init__(self,
                 args,
                 image_transforms=None,
                 target_transforms=None,
                 split='train',
                 eval_mode=False):

        self.image_transforms = image_transforms
        self.target_transform = target_transforms
        self.split = split
        self.max_tokens = 20  # 根据需要调整
        self.eval_mode = eval_mode

        # -----------------------------------------------------------
        # 1. 路径设置
        # -----------------------------------------------------------
        self.root = os.path.join(args.refer_data_root, split)
        print(f"self.root_{self.root}")
        self.dir_A = os.path.join(self.root, 'A')
        self.dir_B = os.path.join(self.root, 'B')
        self.dir_mask = os.path.join(self.root, 'masks')
        self.dir_json = os.path.join(self.root, 'referring_expression') # 注意：根据你提供的信息，文件夹加了 's'

        if not os.path.exists(self.dir_json):
            raise ValueError(f"Directory not found: {self.dir_json}")

        self.tokenizer = BertTokenizer.from_pretrained(args.bert_tokenizer)
        
        # -----------------------------------------------------------
        # 2. 构建样本列表并预处理文本
        # -----------------------------------------------------------
        self.dataset_samples = []
        json_files = sorted([f for f in os.listdir(self.dir_json) if f.endswith('.json')])

        print(f"Loading {split} dataset from {self.root}...")
        
        for j_file in json_files:
            file_id = os.path.splitext(j_file)[0]  # 例如 "000_1_00_0"
            with open(os.path.join(self.dir_json, j_file), 'r', encoding='utf-8') as f:
                data_info = json.load(f)

            expressions = data_info.get('referring_expressions', [])
            
            # 遍历所有的描述语句，利用 enumerate 获取对应的索引 idx
            for idx, sent_raw in enumerate(expressions):
                
                # 【修改核心】动态构建 mask 的相对路径： "000_1_00_0/0.png"
                mask_subpath = os.path.join(file_id, f"{idx}.png")

                # --- BERT Tokenization ---
                input_ids = self.tokenizer.encode(text=sent_raw, add_special_tokens=True)
                input_ids = input_ids[:self.max_tokens]
                
                padded_input_ids = [0] * self.max_tokens
                attention_mask = [0] * self.max_tokens
                padded_input_ids[:len(input_ids)] = input_ids
                attention_mask[:len(input_ids)] = [1] * len(input_ids)

                # --- 生成 Target Mask & Position Mask ---
                target_mask, position_mask = self.generate_linguistic_masks(sent_raw)

                self.dataset_samples.append({
                    'file_id': file_id,
                    'sent_raw': sent_raw,
                    'mask_subpath': mask_subpath,
                    'input_ids': torch.tensor(padded_input_ids, dtype=torch.long),
                    'attention_mask': torch.tensor(attention_mask, dtype=torch.long),
                    'target_mask': torch.tensor(target_mask, dtype=torch.long),
                    'position_mask': torch.tensor(position_mask, dtype=torch.long),
                    'img_ext': '.jpg' # 假设原图A和B的后缀是 jpg
                })

        print(f"Total samples in {split}: {len(self.dataset_samples)}")

    def generate_linguistic_masks(self, sentence_raw):
        """
        根据句子生成 Target Mask 和 Position Mask
        """
        tokenized_sentence = word_tokenize(sentence_raw)
        
        # 沿用原有简化版逻辑
        t_mask = [0] * self.max_tokens
        p_mask = [0] * self.max_tokens
        
        return t_mask, p_mask

    def __len__(self):
        return len(self.dataset_samples)

    def __getitem__(self, index):
        sample = self.dataset_samples[index]
        file_id = sample['file_id']
        
        # 1. 读取图像
        img_A_path = os.path.join(self.dir_A, f"{file_id}{sample['img_ext']}")
        img_B_path = os.path.join(self.dir_B, f"{file_id}{sample['img_ext']}")
        img_A = Image.open(img_A_path).convert("RGB")
        img_B = Image.open(img_B_path).convert("RGB")

        # 2. 读取 Label Mask (这一步不用改，前面的 mask_subpath 已经适配了这里的拼装逻辑)
        mask_path = os.path.join(self.dir_mask, sample['mask_subpath'])
        mask = Image.open(mask_path).convert("L")

        # 转为 0/1 标签
        mask_np = np.array(mask)
        target = np.zeros_like(mask_np)
        target[mask_np > 0] = 1
        target = Image.fromarray(target.astype(np.uint8), mode="P")

        # 3. 同步变换 (Sync Transforms)
        if self.image_transforms is not None:
            seed = np.random.randint(2147483647)

            # 保存一份原始 PIL mask，供 B 图像同步增强时使用
            target_for_B = target.copy()

            # Transform A + Label
            self._set_seed(seed)
            img_A, target = self.image_transforms(img_A, target)

            # Transform B，使用原始 PIL mask，而不是已经变成 Tensor 的 target
            self._set_seed(seed)
            img_B, _ = self.image_transforms(img_B, target_for_B)

        # 4. 获取文本相关数据
        tensor_embeddings = sample['input_ids']
        attention_mask = sample['attention_mask']
        target_mask = sample['target_mask']
        position_mask = sample['position_mask']
        
        # save_prefix 用于可视化或保存结果文件名
        save_prefix = f"{file_id}_{index}"

        return img_A, img_B, target, tensor_embeddings, attention_mask, target_mask, position_mask, save_prefix

    def _set_seed(self, seed):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)