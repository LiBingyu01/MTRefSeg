import numpy as np
import torch 
import torch.nn.functional as F
from .util import AverageMeter, reduce_tensor
import time
import numpy as np
import torch 
import torch.nn.functional as F
from .util import AverageMeter, reduce_tensor
import time
import tqdm

def validate(args, logger, data_loader, model, local_rank=0, eval_mode=True):
    """
    Evaluate ChangeRef / bi-temporal referring segmentation.

    Dataset returns:
        img_A, img_B, target, emb, att_mask, target_mask, position_mask, save_prefix

    Metrics:
        mIoU, oIoU, Pr@0.5, Pr@0.6, Pr@0.7, Pr@0.8, Pr@0.9
    """
    import torch
    import torch.nn.functional as F
    import numpy as np
    import tqdm
    import time

    seg_iou_list = [.5, .6, .7, .8, .9]
    seg_correct = np.zeros(len(seg_iou_list), dtype=np.int32)
    seg_total = 0

    with torch.no_grad():
        model.eval()

        batch_time = AverageMeter()
        I_meter = AverageMeter()
        U_meter = AverageMeter()
        mIOU_meter = AverageMeter()

        end = time.time()

        for idx, (
            img_A, img_B, target,
            emb, att_mask,
            target_mask, position_mask,
            save_prefix
        ) in enumerate(tqdm.tqdm(data_loader)):

            # -------------------------------------------------------
            # 1. Move data to GPU
            # -------------------------------------------------------
            img_A = img_A.cuda(local_rank, non_blocking=True)
            img_B = img_B.cuda(local_rank, non_blocking=True)
            target = target.cuda(local_rank, non_blocking=True)
            emb = emb.cuda(local_rank, non_blocking=True)
            att_mask = att_mask.cuda(local_rank, non_blocking=True)

            # target shape should be [B, H, W]
            if target.dim() == 4 and target.size(1) == 1:
                target = target.squeeze(1)

            # BERT tokens should be [B, L]
            if emb.dim() == 3 and emb.size(1) == 1:
                emb = emb.squeeze(1)
            if att_mask.dim() == 3 and att_mask.size(1) == 1:
                att_mask = att_mask.squeeze(1)

            B, _, _, _ = img_A.shape
            o_H, o_W = target.shape[-2:]

            # -------------------------------------------------------
            # 2. Forward
            # -------------------------------------------------------
            model_output = model(img_A, img_B, emb, att_mask)

            # Some models return (output, exist_pred), some return output only
            if isinstance(model_output, tuple):
                output = model_output[0]
            else:
                output = model_output

            # Some models return a list of predictions
            if isinstance(output, (list, tuple)):
                pred_mask = output[0]
            else:
                pred_mask = output

            # -------------------------------------------------------
            # 3. Resize prediction to target size
            # -------------------------------------------------------
            pred_mask = F.interpolate(
                pred_mask,
                size=(o_H, o_W),
                mode='bilinear',
                align_corners=True
            )

            # -------------------------------------------------------
            # 4. Convert logits to binary prediction
            # -------------------------------------------------------
            if pred_mask.size(1) == 1:
                # Binary sigmoid output: [B, 1, H, W]
                pred = (pred_mask.sigmoid() > 0.5).long().squeeze(1)
            else:
                # Multi-class output: [B, C, H, W]
                pred = pred_mask.argmax(1).long()

            target = target.long()

            # Make sure target is binary 0/1
            target = (target > 0).long()

            # -------------------------------------------------------
            # 5. Compute IoU sample by sample
            # -------------------------------------------------------
            batch_intersection = 0.0
            batch_union = 0.0
            batch_iou_sum = 0.0

            for i in range(B):
                pred_i = pred[i]
                target_i = target[i]

                intersection = torch.logical_and(pred_i == 1, target_i == 1).sum().item()
                union = torch.logical_or(pred_i == 1, target_i == 1).sum().item()

                # If both prediction and GT are empty, define IoU as 1.
                # Usually not expected in your current dataset, but keeps evaluation safe.
                if union == 0:
                    iou = 1.0
                else:
                    iou = intersection / (union + 1e-10)

                batch_intersection += intersection
                batch_union += union
                batch_iou_sum += iou

                for n_eval_iou, threshold in enumerate(seg_iou_list):
                    seg_correct[n_eval_iou] += int(iou >= threshold)

                seg_total += 1

            I_meter.update(batch_intersection)
            U_meter.update(batch_union)
            mIOU_meter.update(batch_iou_sum / B, n=B)

            batch_time.update(time.time() - end)
            end = time.time()

            if (idx + 1) % args.print_freq == 0:
                memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
                current_oIoU = 100.0 * float(I_meter.sum) / float(U_meter.sum + 1e-10)

                logger.info(
                    f'Test: [{idx + 1}/{len(data_loader)}] '
                    f'Time {batch_time.val:.3f} ({batch_time.avg:.3f}) '
                    f'mIoU {100.0 * mIOU_meter.avg:.3f} '
                    f'oIoU {current_oIoU:.3f} '
                    f'Mem {memory_used:.0f}MB'
                )

        # -----------------------------------------------------------
        # 6. Final metrics
        # -----------------------------------------------------------
        mIoU = 100.0 * mIOU_meter.avg
        oIoU = 100.0 * float(I_meter.sum) / float(U_meter.sum + 1e-10)

        results_str = ''
        precision_results = {}

        for n_eval_iou, threshold in enumerate(seg_iou_list):
            precision = seg_correct[n_eval_iou] * 100.0 / (seg_total + 1e-10)
            precision_results[f'Pr@{threshold}'] = precision
            results_str += f'Pr@{threshold} {precision:.2f} '

        logger.info(
            f'mIoU {mIoU:.3f} '
            f'oIoU {oIoU:.3f} '
            f'{results_str}'
        )

        return {
            "mIoU": mIoU,
            "oIoU": oIoU,
            "Pr@0.5": precision_results["Pr@0.5"],
            "Pr@0.6": precision_results["Pr@0.6"],
            "Pr@0.7": precision_results["Pr@0.7"],
            "Pr@0.8": precision_results["Pr@0.8"],
            "Pr@0.9": precision_results["Pr@0.9"],
            # keep rIoU for compatibility with main.py
            "rIoU": oIoU
        }