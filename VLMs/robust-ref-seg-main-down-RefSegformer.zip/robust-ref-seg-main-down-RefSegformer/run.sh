CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node 1 --master_port 12345 test_ns.py \
                    --exp MTRefSeg_ns \
                    --dataset MTRefSeg_ns \
                    --batch_size 16 \
                    --use_mask \
                    --use_exist \
                    --use_pixel_decoder \
                    --output ./logs_eval\
                    --epoch 20 \
                    --eval

CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node 1 --master_port 12345 test_rs.py \
                    --exp MTRefSeg_rs \
                    --dataset MTRefSeg_rs \
                    --batch_size 16 \
                    --use_mask \
                    --use_exist \
                    --use_pixel_decoder \
                    --output ./logs_eval\
                    --epoch 20 \
                    --eval

CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node 1 --master_port 12345 test.py \
                    --exp MTRefSeg \
                    --dataset MTRefSeg \
                    --batch_size 16 \
                    --use_mask \
                    --use_exist \
                    --use_pixel_decoder \
                    --output ./logs_eval\
                    --epoch 20 \
                    --eval



#########################
# Train
#########################

# CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node 1 --master_port 12345 main_ns.py \
#                     --exp MTRefSeg_ns \
#                     --dataset MTRefSeg_ns \
#                     --batch_size 16 \
#                     --use_mask \
#                     --use_exist \
#                     --use_pixel_decoder \
#                     --output ./logs\
#                     --epoch 20

# CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node 1 --master_port 12345 main_rs.py \
#                     --exp MTRefSeg_rs \
#                     --dataset MTRefSeg_rs \
#                     --batch_size 16 \
#                     --use_mask \
#                     --use_exist \
#                     --use_pixel_decoder \
#                     --output ./logs\
#                     --epoch 20

# CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node 1 --master_port 12345 main.py \
#                     --exp MTRefSeg \
#                     --dataset MTRefSeg \
#                     --batch_size 16 \
#                     --use_mask \
#                     --use_exist \
#                     --use_pixel_decoder \
#                     --output ./logs\
#                     --epoch 20