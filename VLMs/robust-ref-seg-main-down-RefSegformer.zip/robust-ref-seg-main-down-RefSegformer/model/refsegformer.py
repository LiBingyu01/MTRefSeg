import torch
import torch.nn as nn
import transformers
import torch.nn.functional as F
from utils.util import load_pretrained_swin

from model.swin_transformer_encoder_fusion import SwinTransformerEncoderFusion
from model.position_encoding import build_position_encoding
from model.segmentation_decoder_fusion import SegmentationDecoderFusion

class RefSegFormer(nn.Module):
    def __init__(self, config, args, logger):
        super().__init__()
        self.config = config
        self.args = args
        self.model_type = config.MODEL.TYPE
        self.model_name = config.MODEL.NAME

        self.position_encoding = build_position_encoding(args)

        self.text_encoder = transformers.BertModel.from_pretrained('pretrained_weights/bert-base-uncased')
        self.text_encoder.pooler = None
        
        # 1. 构建基础模型
        self.image_encoder, self.segmentation = build_model(self.config, logger, args, self.position_encoding)
        
        # ============================================================
        # 2. 【新增】定义融合层 (Fusion Layers)
        #    因为 cat 后通道翻倍，需要 1x1 卷积降维，才能送入 Decoder
        # ============================================================
        self.fusion_convs = nn.ModuleList() # 名字可以不改，但内部实质变了
        self.fusion_mem_projs = nn.ModuleList()
        
        # 获取 Swin 的基础参数
        embed_dim = config.MODEL.SWIN.EMBED_DIM
        num_stages = len(config.MODEL.SWIN.DEPTHS)
        
        for i in range(num_stages):
            curr_dim = embed_dim * (2 ** i)
            
            # 【核心修改点】使用 Linear + LayerNorm 替代 Conv2d + BatchNorm
            # Input shape: [B, L, 2*C] -> Output: [B, L, C]
            self.fusion_convs.append(
                nn.Sequential(
                    nn.Linear(curr_dim * 2, curr_dim),
                    nn.LayerNorm(curr_dim),
                    nn.ReLU(inplace=True)
                )
            )
            
            # Memory 融合层保持不变 (它本来就是 Linear)
            self.fusion_mem_projs.append(
                nn.Linear(curr_dim * 2, curr_dim)
            )
            
    def forward(self, img_A, img_B, emb, att_mask):
        _, _, H, _ = img_A.size()
        text_feature = self.text_encoder(emb, attention_mask=att_mask)[0]
        res_A = self.image_encoder(img_A, text_feature, att_mask)
        res_B = self.image_encoder(img_B, text_feature, att_mask)
        
        features_A, memories_A = res_A[0], res_A[1]
        features_B, memories_B = res_B[0], res_B[1]
        
        fused_features = []
        fused_memories = []
        
        for i, (fA, fB) in enumerate(zip(features_A, features_B)):
            # --- Feature Map Fusion ---
            feat_cat = torch.cat([fA, fB], dim=-1) 
            feat_out = self.fusion_convs[i](feat_cat)
            fused_features.append(feat_out)
            # --- Memory Fusion ---
            mA = memories_A[i]
            mB = memories_B[i]
            if mA is None or mB is None:
                fused_memories.append(None)
            else:
                mem_cat = torch.cat([mA, mB], dim=-1)
                mem_out = self.fusion_mem_projs[i](mem_cat)
                fused_memories.append(mem_out)
        # 4. 送入 Segmentation Decoder
        output = self.segmentation(fused_features, fused_memories, att_mask)

        out_list = []
        for pred in output["mask_list"]:
            _, _, h, _ = pred.size()
            assert H % h == 0
            out_list.append(F.interpolate(pred, scale_factor=int(H//h), mode='bilinear', align_corners=True))

        return out_list, output["exist_pred"]
    
# build_model 保持不变
def build_model(config, logger, args, position_encoding):
    model = SwinTransformerEncoderFusion(img_size=config.DATA.IMG_SIZE,
        patch_size=config.MODEL.SWIN.PATCH_SIZE,
        in_chans=config.MODEL.SWIN.IN_CHANS,
        num_classes=config.MODEL.NUM_CLASSES,
        embed_dim=config.MODEL.SWIN.EMBED_DIM,
        depths=config.MODEL.SWIN.DEPTHS,
        num_heads=config.MODEL.SWIN.NUM_HEADS,
        window_size=config.MODEL.SWIN.WINDOW_SIZE,
        mlp_ratio=config.MODEL.SWIN.MLP_RATIO,
        qkv_bias=config.MODEL.SWIN.QKV_BIAS,
        qk_scale=config.MODEL.SWIN.QK_SCALE,
        drop_rate=config.MODEL.DROP_RATE,
        drop_path_rate=config.MODEL.DROP_PATH_RATE,
        ape=config.MODEL.SWIN.APE,
        patch_norm=config.MODEL.SWIN.PATCH_NORM,
        use_checkpoint=config.TRAIN.USE_CHECKPOINT,
        num_mem=args.num_mem,
        num_neg_mem=args.num_neg_mem,
        hidden_dim=args.hidden_dim,
        position_encoding=position_encoding,
        args=args
    )
    load_pretrained_swin(config, model, logger)

    segmentation = SegmentationDecoderFusion(config, args, position_encoding)

    return model, segmentation