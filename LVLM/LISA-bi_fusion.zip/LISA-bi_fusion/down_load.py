
from huggingface_hub import snapshot_download

snapshot_download(
    repo_id="xinlai/LISA-13B-llama2-v1",
    repo_type="model",
    local_dir="pretrained_weights/LISA-13B-llama2-v1",
    local_dir_use_symlinks=False
)