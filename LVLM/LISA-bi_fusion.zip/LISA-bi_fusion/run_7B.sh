# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp1: train -> val
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-7B-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "TV|train" \
  --val_dataset "TV|val" \
  --dataset_dir "//gemini/space/zhaozy/libingyu/ChangeRef_datasets" \
  --exp_name "lisa-bitemporal-run" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --epochs 10 \
# =============================================================================

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# exp1: NS -> RS
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-7B-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "TV|NS" \
  --val_dataset "TV|RS" \
  --dataset_dir "/gemini/space/zhaozy/libingyu/ChangeRef_datasets" \
  --exp_name "lisa-bitemporal-run-NS-RS" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --epochs 10 \
# =============================================================================


# =============================================================================
deepspeed --master_port=24999 train_ds.py \
  --version "pretrained_weights/LISA-7B-v1" \
  --vision-tower "pretrained_weights/clip-vit-large-patch14"\
  --vision_pretrained "pretrained_weights/sam_vit_h_4b8939.pth" \
  --dataset "change_refer" \
  --change_refer_seg_data "TV|RS" \
  --val_dataset "TV|NS" \
  --dataset_dir "/gemini/space/zhaozy/libingyu/ChangeRef_datasets" \
  --exp_name "lisa-bitemporal-run-RS-NS" \
  --log_base_dir "run_7B" \
  --steps_per_epoch 500 \
  --epochs 10 \
# =============================================================================
