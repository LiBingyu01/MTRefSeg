cd ./run_7B_bifusion/lisa-bitemporal-run-RS-NS/ckpt_model && python zero_to_fp32.py . ../pytorch_model.bin

cd /gemini/space/zhaozy/libingyu/LISA-main-new
CUDA_VISIBLE_DEVICES="" python merge_lora_weights_and_save_hf_model.py \
  --version="pretrained_weights/LISA-7B-v1" \
  --weight="./run_7B_bifusion/lisa-bitemporal-run-RS-NS/pytorch_model.bin" \
  --save_path="./run_7B_bifusion/LISA_bi_fusion_7B_RS_NS"
