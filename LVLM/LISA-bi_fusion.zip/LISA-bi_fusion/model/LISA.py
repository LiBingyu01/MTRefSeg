from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BitsAndBytesConfig, CLIPVisionModel

from utils.utils import (DEFAULT_IM_END_TOKEN, DEFAULT_IM_START_TOKEN,
                         DEFAULT_IMAGE_PATCH_TOKEN)

from .llava.model.language_model.llava_llama import (LlavaLlamaForCausalLM,
                                                     LlavaLlamaModel)
from .segment_anything import build_sam_vit_h


def dice_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    num_masks: float,
    scale=1000,  # 100000.0,
    eps=1e-6,
):
    """
    Compute the DICE loss, similar to generalized IOU for masks
    Args:
        inputs: A float tensor of arbitrary shape.
                The predictions for each example.
        targets: A float tensor with the same shape as inputs. Stores the binary
                 classification label for each element in inputs
                (0 for the negative class and 1 for the positive class).
    """
    inputs = inputs.sigmoid()
    inputs = inputs.flatten(1, 2)
    targets = targets.flatten(1, 2)
    numerator = 2 * (inputs / scale * targets).sum(-1)
    denominator = (inputs / scale).sum(-1) + (targets / scale).sum(-1)
    loss = 1 - (numerator + eps) / (denominator + eps)
    loss = loss.sum() / (num_masks + 1e-8)
    return loss


def sigmoid_ce_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    num_masks: float,
):
    """
    Args:
        inputs: A float tensor of arbitrary shape.
                The predictions for each example.
        targets: A float tensor with the same shape as inputs. Stores the binary
                 classification label for each element in inputs
                (0 for the negative class and 1 for the positive class).
    Returns:
        Loss tensor
    """
    loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction="none")
    loss = loss.flatten(1, 2).mean(1).sum() / (num_masks + 1e-8)
    return loss

class ChangeHead(nn.Module):
    def __init__(self, in_channels=2, hidden_channels=32, out_channels=1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, kernel_size=3, padding=1),
            nn.GroupNorm(8, hidden_channels), # 使用 GN 归一化更稳定
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, out_channels, kernel_size=1) # 输出 Logits
        )

    def forward(self, x):
        return self.net(x)
    
class LisaMetaModel:
    def __init__(
        self,
        config,
        **kwargs,
    ):
        super(LisaMetaModel, self).__init__(config)

        self.config = config
        if not hasattr(self.config, "train_mask_decoder"):
            self.config.train_mask_decoder = kwargs["train_mask_decoder"]
            self.config.out_dim = kwargs["out_dim"]
            self.vision_pretrained = kwargs.get("vision_pretrained", None)
        else:
            self.vision_pretrained = kwargs.get("vision_pretrained", None)
            self.initialize_lisa_modules(self.config)

    def initialize_lisa_modules(self, config):
        # SAM
        self.visual_model = build_sam_vit_h(self.vision_pretrained)
        for param in self.visual_model.parameters():
            param.requires_grad = False
        if config.train_mask_decoder:
            self.visual_model.mask_decoder.train()
            for param in self.visual_model.mask_decoder.parameters():
                param.requires_grad = True

        # Projection layer
        in_dim = config.hidden_size
        out_dim = config.out_dim
        text_fc = [
            nn.Linear(in_dim, in_dim),
            nn.ReLU(inplace=True),
            nn.Linear(in_dim, out_dim),
            nn.Dropout(0.0),
        ]
        self.text_hidden_fcs = nn.ModuleList([nn.Sequential(*text_fc)])
        self.text_hidden_fcs.train()
        for param in self.text_hidden_fcs.parameters():
            param.requires_grad = True


class LisaModel(LisaMetaModel, LlavaLlamaModel):
    def __init__(
        self,
        config,
        **kwargs,
    ):
        super(LisaModel, self).__init__(config, **kwargs)

        self.config.use_cache = False
        self.config.vision_tower = self.config.mm_vision_tower
        self.config.mm_vision_select_feature = "patch"
        self.config.image_aspect_ratio = "square"
        self.config.image_grid_pinpoints = None
        self.config.tune_mm_mlp_adapter = False
        self.config.freeze_mm_mlp_adapter = True
        self.config.pretrain_mm_mlp_adapter = None
        self.config.mm_use_im_patch_token = False

 
class BiTemporalFusion(nn.Module):
  def __init__(self, in_channels=256):
    super().__init__()
    # 降维
    self.project = nn.Sequential(
      nn.Linear(in_channels*3, in_channels),
      nn.ReLU(inplace=True)
    )
    # 融合后的处理
    self.fusion_conv = nn.Sequential(
      nn.Linear(in_channels, in_channels),
      nn.ReLU(inplace=True),
      nn.Linear(in_channels, in_channels)
    )

  def forward(self, emb1, emb2):
    # [B, C, H, W] -> [B, H, W, C]
    emb1 = emb1.permute(0, 2, 3, 1)
    emb2 = emb2.permute(0, 2, 3, 1)
    diff = torch.abs(emb1 - emb2)
    fused = self.project(torch.cat([emb1, emb2, diff], dim=-1))
    x = self.fusion_conv(fused)
    x = x.permute(0, 3, 1, 2)
    return x
    
class LISAForCausalLM(LlavaLlamaForCausalLM):
    def __init__(
        self,
        config,
        **kwargs,
    ):
        self.ce_loss_weight = kwargs.pop("ce_loss_weight", None)
        self.dice_loss_weight = kwargs.pop("dice_loss_weight", None)
        self.bce_loss_weight = kwargs.pop("bce_loss_weight", None)
        self.seg_token_idx = kwargs.pop("seg_token_idx")
        
        if not hasattr(config, "train_mask_decoder"):
            config.mm_use_im_start_end = kwargs.pop("use_mm_start_end", True)
            config.mm_vision_tower = kwargs.get(
                "vision_tower", "openai/clip-vit-large-patch14"
            )
        else:
            config.mm_vision_tower = config.vision_tower

        super().__init__(config)

        self.model = LisaModel(config, **kwargs)

        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        # Initialize weights and apply final processing
        self.post_init()
        
        self.fusion_module = BiTemporalFusion(in_channels=256)

    def get_visual_embs(self, pixel_values: torch.FloatTensor):
        with torch.no_grad():
            image_embeddings_list = []
            for i in range(pixel_values.shape[0]):
                torch.cuda.empty_cache()
                image_embeddings = self.model.visual_model.image_encoder(
                    pixel_values[i].unsqueeze(0)
                )
                image_embeddings_list.append(image_embeddings)
            torch.cuda.empty_cache()
            image_embeddings = torch.cat(image_embeddings_list, 0)
        return image_embeddings

    def forward(self, **kwargs):
        if "past_key_values" in kwargs:
            return super().forward(**kwargs)
        return self.model_forward(**kwargs)

    def model_forward(
        self,
        images_t1: torch.FloatTensor, # [B, C, H, W]
        images_t2: torch.FloatTensor, # [B, C, H, W]
        images_clip_t1: torch.FloatTensor,
        images_clip_t2: torch.FloatTensor,
        input_ids: torch.LongTensor,
        labels: torch.LongTensor,
        attention_masks: torch.LongTensor,
        offset: torch.LongTensor,
        masks_list: List[torch.FloatTensor],
        label_list: List[torch.Tensor],
        resize_list: List[tuple],
        inference: bool = False,
        **kwargs,
    ):
        image_embeddings_1 = self.get_visual_embs(images_t1) 
        image_embeddings_2 = self.get_visual_embs(images_t2)
        fused_image_embeddings = self.fusion_module(image_embeddings_1, image_embeddings_2)
        batch_size = image_embeddings_1.shape[0]
        assert batch_size == len(offset) - 1
        if inference:
            n_batch = 1
            length = input_ids.shape[0]
            assert images_clip_t2.shape[0] == 1
            images_clip_t1_extend = images_clip_t1.expand(length, -1, -1, -1).contiguous()
            images_clip_t2_extend = images_clip_t2.expand(length, -1, -1, -1).contiguous()
            output_hidden_states = []
            for i in range(n_batch):
                start_i, end_i = i * length, min((i + 1) * length, input_ids.shape[0])
                output_i = super().forward(
                    images_t1=images_clip_t1_extend[: end_i - start_i],
                    images_t2=images_clip_t2_extend[: end_i - start_i],
                    attention_mask=attention_masks[start_i:end_i],
                    input_ids=input_ids[start_i:end_i],
                    output_hidden_states=True,
                )
                output_hidden_states.append(output_i.hidden_states)
                torch.cuda.empty_cache()

            output_hidden_states_list = []
            output_hidden_states_level = torch.cat(output_hidden_states, dim=0)
            output_hidden_states_list.append(output_hidden_states_level)
            output_hidden_states = output_hidden_states_list
            output = None
        else:
            images_clip_t1_list = []
            images_clip_t2_list = []
            for i in range(len(offset) - 1):
                start_i, end_i = offset[i], offset[i + 1]
                images_clip_t1_i = (
                    images_clip_t1[i]
                    .unsqueeze(0)
                    .expand(end_i - start_i, -1, -1, -1)
                    .contiguous()
                )
                images_clip_t2_i = (
                    images_clip_t2[i]
                    .unsqueeze(0)
                    .expand(end_i - start_i, -1, -1, -1)
                    .contiguous()
                )
                images_clip_t1_list.append(images_clip_t1_i)
                images_clip_t2_list.append(images_clip_t2_i)

            images_clip_t1 = torch.cat(images_clip_t1_list, dim=0)
            images_clip_t2 = torch.cat(images_clip_t2_list, dim=0)

            output = super().forward(
                images_t1=images_clip_t1,
                images_t2=images_clip_t2,
                attention_mask=attention_masks,
                input_ids=input_ids,
                labels=labels,
                output_hidden_states=True,
            )
            output_hidden_states = output.hidden_states


        hidden_states = []
        assert len(self.model.text_hidden_fcs) == 1
        hidden_states.append(self.model.text_hidden_fcs[0](output_hidden_states[-1]))
        last_hidden_state = torch.stack(hidden_states, dim=-1).sum(dim=-1)
        # ================================================
        raw_seg_token_mask = (input_ids == self.seg_token_idx) # [B, Seq_Len_Raw]

        # 2. 动态计算扩展后的 mask
        # 因为 images 被替换成了特征序列（比如每个 image 256个 patch），
        # 实际的 hidden_state 长度会发生变化。
        
        # 我们创建一个和 last_hidden_state 长度一致的空 mask
        seg_token_mask = torch.zeros(
            (last_hidden_state.shape[0], last_hidden_state.shape[1]), 
            dtype=torch.bool, 
            device=last_hidden_state.device
        )

        # 3. 遍历 Batch，计算每个样本中 [SEG] 的实际物理索引
        # 根据 LLaVA 的逻辑，IMAGE_TOKEN_INDEX (-200) 会被替换为视觉序列
        for b_idx in range(input_ids.shape[0]):
            cur_input_ids = input_ids[b_idx]
            # 找到 [SEG] 在当前样本原始序列里的所有索引位置
            seg_indices = torch.where(cur_input_ids == self.seg_token_idx)[0]
            # 找到图像 Token 在原始序列里的位置
            image_indices = torch.where(cur_input_ids == -200)[0]
            # 每个图像 Token 实际占据的长度（例如 256 或 576）
            # 这里的 255 或 575 取决于你的 vision_tower 产生的 patch 数减 1
            # 也可以动态通过 (last_hidden_state.shape[1] - input_ids.shape[1]) / num_images 计算
            num_images = len(image_indices)
            if num_images > 0:
                patch_per_image = (last_hidden_state.shape[1] - input_ids.shape[1]) // num_images
            else:
                patch_per_image = 0
            for seg_idx in seg_indices:
                # 【计算物理索引的关键公式】：
                # 实际索引 = 原始索引 + (该 SEG 之前出现的图像数 * (每张图的 patch 数 - 1))
                images_before_seg = (image_indices < seg_idx).sum()
                physical_idx = seg_idx + images_before_seg * patch_per_image
                # 在扩展后的 mask 中填入 True
                if physical_idx < seg_token_mask.shape[1]:
                    seg_token_mask[b_idx, physical_idx] = True

        # 4. 现在可以安全地提取了
        pred_embeddings = last_hidden_state[seg_token_mask]
        # ================================================    
    
        seg_token_counts = seg_token_mask.int().sum(-1)  # [bs, ]

        seg_token_offset = seg_token_counts.cumsum(-1)
        seg_token_offset = torch.cat(
            [torch.zeros(1).long().cuda(), seg_token_offset], dim=0
        )
        seg_token_offset = seg_token_offset[offset]


        pred_embeddings_ = []
        for i in range(len(seg_token_offset) - 1):
            start_i, end_i = seg_token_offset[i], seg_token_offset[i + 1]
            pred_embeddings_.append(pred_embeddings[start_i:end_i])
        pred_embeddings = pred_embeddings_

        pred_change_masks = []
        for i in range(len(pred_embeddings)):
            (
                sparse_embeddings,
                dense_embeddings,
            ) = self.model.visual_model.prompt_encoder(
                points=None,
                boxes=None,
                masks=None,
                text_embeds=pred_embeddings[i].unsqueeze(1),
            )
            sparse_embeddings = sparse_embeddings.to(pred_embeddings[i].dtype)
            low_res_masks, _ = self.model.visual_model.mask_decoder(
                image_embeddings=fused_image_embeddings[i].unsqueeze(0),
                image_pe=self.model.visual_model.prompt_encoder.get_dense_pe(),
                sparse_prompt_embeddings=sparse_embeddings,
                dense_prompt_embeddings=dense_embeddings,
                multimask_output=False,
            )
            pred_change_mask = self.model.visual_model.postprocess_masks(
                low_res_masks,
                input_size=resize_list[i],
                original_size=label_list[i].shape
            )[:, 0]
            pred_change_masks.append(pred_change_mask)
    
        model_output = output
        gt_masks = masks_list
        
        if inference:
            return {
                "pred_masks": pred_change_masks,
                "gt_masks": gt_masks,
            }

        ce_loss = model_output.loss
        ce_loss = ce_loss * self.ce_loss_weight
        mask_bce_loss = 0
        mask_dice_loss = 0
        num_masks = 0
        for batch_idx in range(len(pred_change_masks)):
            gt_mask = gt_masks[batch_idx]
            pred_mask = pred_change_masks[batch_idx]

            assert (
                gt_mask.shape[0] == pred_mask.shape[0]
            ), "gt_mask.shape: {}, pred_mask.shape: {}".format(
                gt_mask.shape, pred_mask.shape
            )
            mask_bce_loss += (
                sigmoid_ce_loss(pred_mask, gt_mask, num_masks=gt_mask.shape[0])
                * gt_mask.shape[0]
            )
            mask_dice_loss += (
                dice_loss(pred_mask, gt_mask, num_masks=gt_mask.shape[0])
                * gt_mask.shape[0]
            )
            num_masks += gt_mask.shape[0]

        mask_bce_loss = self.bce_loss_weight * mask_bce_loss / (num_masks + 1e-8)
        mask_dice_loss = self.dice_loss_weight * mask_dice_loss / (num_masks + 1e-8)
        mask_loss = mask_bce_loss + mask_dice_loss

        loss = ce_loss + mask_loss

        return {
            "loss": loss,
            "ce_loss": ce_loss,
            "mask_bce_loss": mask_bce_loss,
            "mask_dice_loss": mask_dice_loss,
            "mask_loss": mask_loss,
        }
    def evaluate_via_forward(
        self,
        images_clip_t1,
        images_t1,
        images_clip_t2,
        images_t2,
        input_ids,
        resize_list_t2,
        original_size_list_t2,
    ):
        attention_masks = input_ids.ne(self.config.pad_token_id).long()
        offset = torch.tensor([0, input_ids.shape[0]], device=input_ids.device)

        # 推理时没有 GT，这里给占位
        dummy_masks_list = []
        dummy_label_list = [
            torch.zeros(size, device=images_t2.device) for size in original_size_list_t2
        ]

        return self.model_forward(
            images_t1=images_t1,
            images_t2=images_t2,
            images_clip_t1=images_clip_t1,
            images_clip_t2=images_clip_t2,
            input_ids=input_ids,
            labels=None,
            attention_masks=attention_masks,
            offset=offset,
            masks_list=dummy_masks_list,
            label_list=dummy_label_list,
            resize_list=resize_list_t2,
            inference=True,
    )
    def prepare_inputs_for_generation(self,
                                    input_ids,
                                    past_key_values=None,
                                    attention_mask=None,
                                    inputs_embeds=None,
                                    images_t1=None,
                                    images_t2=None,
                                    **kwargs,
                                ):
        model_inputs = super().prepare_inputs_for_generation(
            input_ids=input_ids,
            past_key_values=past_key_values,
            attention_mask=attention_mask,
            inputs_embeds=inputs_embeds,
            **kwargs,
        )

        if images_t1 is not None:
            model_inputs["images_t1"] = images_t1
        if images_t2 is not None:
            model_inputs["images_t2"] = images_t2

        return model_inputs
    def evaluate(
                self,
                images_clip_t1,
                images_t1,
                images_clip_t2,
                images_t2,
                input_ids,
                resize_list_t1,
                original_size_list_t1,
                resize_list_t2,
                original_size_list_t2,
                max_new_tokens=32,
                tokenizer=None,
            ):
        with torch.no_grad():
            # 1. LLM 生成，走双时相图像输入
            outputs = self.generate(
                images_t1=images_clip_t1,
                images_t2=images_clip_t2,
                input_ids=input_ids,
                max_new_tokens=max_new_tokens,
                num_beams=1,
                output_hidden_states=True,
                return_dict_in_generate=True,
            )

            output_hidden_states = outputs.hidden_states[-1]
            output_ids = outputs.sequences

            # 2. 找到 [SEG] token
            seg_token_mask = output_ids[:, 1:] == self.seg_token_idx

            # hack for IMAGE_TOKEN_INDEX
            # 原来单图时前面补 255
            # 现在双图输入，前面有两个图像 token block，所以补 255 * 2
            seg_token_mask = torch.cat(
                [
                    torch.zeros((seg_token_mask.shape[0], 255 * 2)).bool().cuda(),
                    seg_token_mask,
                ],
                dim=1,
            )

            hidden_states = []

            assert len(self.model.text_hidden_fcs) == 1
            hidden_states.append(self.model.text_hidden_fcs[0](output_hidden_states))

            last_hidden_state = torch.stack(hidden_states, dim=-1).sum(dim=-1)
            pred_embeddings = last_hidden_state[seg_token_mask]

            seg_token_counts = seg_token_mask.int().sum(-1)  # [bs, ]
            seg_token_offset = seg_token_counts.cumsum(-1)
            seg_token_offset = torch.cat(
                [torch.zeros(1).long().cuda(), seg_token_offset], dim=0
            )

            pred_embeddings_ = []
            for i in range(len(seg_token_offset) - 1):
                start_i, end_i = seg_token_offset[i], seg_token_offset[i + 1]
                pred_embeddings_.append(pred_embeddings[start_i:end_i])
            pred_embeddings = pred_embeddings_

            # 3. 分别提取 T1 / T2 的视觉特征
            image_embeddings_t1 = self.get_visual_embs(images_t1)
            image_embeddings_t2 = self.get_visual_embs(images_t2)

            # 4. 双时相融合
            fused_image_embeddings = self.fusion_module(
                image_embeddings_t1, image_embeddings_t2
            )

            multimask_output = False
            pred_masks = []
            for i in range(len(pred_embeddings)):
                (
                    sparse_embeddings,
                    dense_embeddings,
                ) = self.model.visual_model.prompt_encoder(
                    points=None,
                    boxes=None,
                    masks=None,
                    text_embeds=pred_embeddings[i].unsqueeze(1),
                )

                sparse_embeddings = sparse_embeddings.to(pred_embeddings[i].dtype)
                low_res_masks, iou_predictions = self.model.visual_model.mask_decoder(
                    image_embeddings=fused_image_embeddings[i].unsqueeze(0),
                    image_pe=self.model.visual_model.prompt_encoder.get_dense_pe(),
                    sparse_prompt_embeddings=sparse_embeddings,
                    dense_prompt_embeddings=dense_embeddings,
                    multimask_output=multimask_output,
                )

                # 一般输出 mask 对齐到 T2 尺寸
                pred_mask = self.model.visual_model.postprocess_masks(
                    low_res_masks,
                    input_size=resize_list_t2[i],
                    original_size=original_size_list_t2[i],
                )
                
                pred_masks.append(pred_mask[:, 0])

        return output_ids, pred_masks    