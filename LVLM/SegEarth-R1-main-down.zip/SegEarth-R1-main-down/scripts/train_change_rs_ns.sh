#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# train_change_rs_ns.sh  –  Train on RS (Remote Sensing), Test on NS (Natural Scene)
#                            for bi-temporal change detection
#
# Cross-domain generalization: Train on remote sensing change detection data,
# validate on natural scene change detection data
#
# Usage:
#   bash scripts/train_change_rs_ns.sh [RS_DATA] [NS_DATA] [MODEL] [VISION_TOWER] [OUTPUT] [GPUS]
#
# Positional arguments (all optional):
#   1. RS_DATA_PATH    – root dir of RS change-detection training dataset
#   2. NS_DATA_PATH    – root dir of NS change-detection validation dataset
#   3. MODEL_PATH      – pre-trained phi-1.5 / SegEarth-R1 checkpoint
#   4. VISION_TOWER    – Swin-B weights (.pkl)
#   5. OUTPUT_DIR      – where to save the fine-tuned model
#   6. GPU_IDS         – comma-separated GPU IDs, e.g. "0,1,2,3"   (default: "0,1")
# ─────────────────────────────────────────────────────────────────────────────
set -e

RS_DATA_PATH="${1:-/path/to/rs_change_detection}"
NS_DATA_PATH="${2:-/path/to/ns_change_detection}"
MODEL_PATH="${3:-pre_trained/phi-1_5_dev}"
VISION_TOWER="${4:-pre_trained/Swin_base/model_final_54b88a.pkl}"
OUTPUT_DIR="${5:-./checkpoint/SegEarth-R1_Change_RS_NS}"
GPU_IDS="${6:-0,1}"

MASK_CONFIG="segearth_r1/mask_config/maskformer2_swin_base_384_bs16_50ep.yaml"
VERSION="llava_phi"
IMAGE_SIZE=1024

# ── Build the include string for deepspeed ────────────────────────────────────
IFS=',' read -ra GPU_ARR <<< "$GPU_IDS"
NUM_GPUS=${#GPU_ARR[@]}
INCLUDE_STR="localhost:${GPU_IDS}"

echo "======================================================"
echo "  SegEarth-R1 Change Detection Cross-Domain"
echo "  Train: RS (Remote Sensing)"
echo "  Test:  NS (Natural Scene)"
echo "  RS_DATA    : ${RS_DATA_PATH}"
echo "  NS_DATA    : ${NS_DATA_PATH}"
echo "  MODEL_PATH : ${MODEL_PATH}"
echo "  OUTPUT_DIR : ${OUTPUT_DIR}"
echo "  GPUs       : ${GPU_IDS}  (${NUM_GPUS} GPU(s))"
echo "======================================================"

deepspeed --master_port 29501 \
          --include "${INCLUDE_STR}" \
  segearth_r1/train/train.py \
    --deepspeed ./scripts/zero2.json \
    \
    --data_path "${RS_DATA_PATH}" \
    --dataset_type "change_detection" \
    --val_data_path "${NS_DATA_PATH}" \
    --val_dataset_type "change_detection" \
    \
    --model_name_or_path "${MODEL_PATH}" \
    --version "${VERSION}" \
    \
    --vision_tower "${VISION_TOWER}" \
    --mask_config "${MASK_CONFIG}" \
    --mm_vision_select_layer -2 \
    --mm_use_im_start_end False \
    --mm_use_im_patch_token False \
    --mm_projector_type "SparseConv_1" \
    \
    --output_dir "${OUTPUT_DIR}" \
    --num_train_epochs 3 \
    --per_device_train_batch_size 32 \
    --gradient_accumulation_steps 4 \
    --evaluation_strategy "no" \
    --save_strategy "epoch" \
    --learning_rate 1e-4 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --model_max_length 2048 \
    --gradient_checkpointing True \
    --lazy_preprocess True \
    --seg_task "referring" \
    --freeze_mm_mlp_adapter False \
    --bf16 True \
    --train_backbone False \
    --save_total_limit 3 \
    --dataloader_drop_last True

echo "Training finished. Checkpoint saved to ${OUTPUT_DIR}"
