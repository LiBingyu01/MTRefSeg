#!/bin/bash
# scripts/train_all.sh - 依次运行三种变化检测训练实验
# 每轮训练结束后由 ChangeDetectionEvalCallback 自动在验证集上评测（mIoU / oIoU / Prec@k）
# 评测结果实时打印到终端，无需 HuggingFace 内置 evaluation_strategy

export WANDB_DISABLED=True

# ── 1. 标准训练验证（train → val） ────────────────────────────────────────────
# 参数顺序: TRAIN_DATA  VAL_DATA  MODEL  VISION_TOWER  OUTPUT  GPUS
echo "============================================================"
echo "  [1/3] train_change_train_val: TV/train -> TV/val"
echo "============================================================"
bash scripts/train_change_train_val.sh \
 "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV/TT" \
 "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV/val" \
 "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/phi-1_5_dev" \
 "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/model_final_9d7f02.pkl" \
 "./checkpoint/train_change_train_val" \
 0,1,2,3

# # ── 2. 跨域：RS训练 → NS测试 ──────────────────────────────────────────────────
# # 参数顺序: RS_TRAIN_DATA  NS_VAL_DATA  MODEL  VISION_TOWER  OUTPUT  GPUS
# echo "============================================================"
# echo "  [2/3] train_change_rs_ns: TV/RS(train) -> TV/NS(val)"
# echo "============================================================"
# bash scripts/train_change_rs_ns.sh \
#  "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV/RS" \
#  "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV/NS" \
#  "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/phi-1_5_dev" \
#  "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/model_final_9d7f02.pkl" \
#  "./checkpoint/train_change_rs_ns" \
#  0,1,2,3

# # ── 3. 跨域：NS训练 → RS测试 ──────────────────────────────────────────────────
# # 参数顺序: NS_TRAIN_DATA  RS_VAL_DATA  MODEL  VISION_TOWER  OUTPUT  GPUS
# echo "============================================================"
# echo "  [3/3] train_change_ns_rs: TV/NS(train) -> TV/RS(val)"
# echo "============================================================"
# bash scripts/train_change_ns_rs.sh \
#  "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV/NS" \
#  "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV/RS" \
#  "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/phi-1_5_dev" \
#  "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/model_final_9d7f02.pkl" \
#  "./checkpoint/train_change_ns_rs" \
#  0,1,2,3

# echo "============================================================"
# echo "  All experiments finished."
# echo "============================================================"
