#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# train_change_train_val.sh  –  Train on train set, validate on val set
#                                 for bi-temporal change detection
#
# Usage:
#   bash scripts/train_change_train_val.sh [TRAIN_DATA] [VAL_DATA] [MODEL] [VISION_TOWER] [OUTPUT] [GPUS]
#
# Positional arguments (all optional):
#   1. TRAIN_DATA_PATH – root dir of training change-detection dataset
#   2. VAL_DATA_PATH   – root dir of validation change-detection dataset
#   3. MODEL_PATH      – pre-trained phi-1.5 / SegEarth-R1 checkpoint
#   4. VISION_TOWER    – Swin-B weights (.pkl)
#   5. OUTPUT_DIR      – where to save the fine-tuned model
#   6. GPU_IDS         – comma-separated GPU IDs, e.g. "0,1,2,3"   (default: "0,1")
# ─────────────────────────────────────────────────────────────────────────────
set -e

TRAIN_DATA_PATH="${1:-/path/to/change_detection_train}"
VAL_DATA_PATH="${2:-/path/to/change_detection_val}"
MODEL_PATH="${3:-pre_trained/phi-1_5_dev}"
VISION_TOWER="${4:-pre_trained/Swin_base/model_final_54b88a.pkl}"
OUTPUT_DIR="${5:-./checkpoint/SegEarth-R1_Change_TrainVal}"
GPU_IDS="${6:-0,1}"

MASK_CONFIG="segearth_r1/mask_config/maskformer2_swin_base_384_bs16_50ep.yaml"
VERSION="llava_phi"
IMAGE_SIZE=1024

# ── Build the include string for deepspeed ─────────────────────────────���──────
IFS=',' read -ra GPU_ARR <<< "$GPU_IDS"
NUM_GPUS=${#GPU_ARR[@]}
INCLUDE_STR="localhost:${GPU_IDS}"

echo "======================================================"
echo "  SegEarth-R1 Change Detection: Train->Val"
echo "  TRAIN_DATA : ${TRAIN_DATA_PATH}"
echo "  VAL_DATA   : ${VAL_DATA_PATH}"
echo "  MODEL_PATH : ${MODEL_PATH}"
echo "  OUTPUT_DIR : ${OUTPUT_DIR}"
echo "  GPUs       : ${GPU_IDS}  (${NUM_GPUS} GPU(s))"
echo "======================================================"

deepspeed --master_port 29501 \
          --include "${INCLUDE_STR}" \
  segearth_r1/train/train.py \
    --deepspeed ./scripts/zero2.json \
    \
    --data_path "${TRAIN_DATA_PATH}" \
    --dataset_type "change_detection" \
    --val_data_path "${VAL_DATA_PATH}" \
    --val_dataset_type "change_detection" \
    \
    --model_name_or_path "${MODEL_PATH}" \
    --version "${VERSION}" \
    \
    --vision_tower "${VISION_TOWER}" \
    --mask_config "${MASK_CONFIG}" \
    --mm_vision_select_layer -2 \
    --mm_use_im_start_end False \
    --mm_use_im_patch_token False \
    --mm_projector_type "SparseConv_1" \
    \
    --output_dir "${OUTPUT_DIR}" \
    --num_train_epochs 3 \
    --per_device_train_batch_size 32 \
    --gradient_accumulation_steps 4 \
    --evaluation_strategy "no" \
    --save_strategy "epoch" \
    --learning_rate 1e-4 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --model_max_length 2048 \
    --gradient_checkpointing True \
    --lazy_preprocess True \
    --seg_task "referring" \
    --freeze_mm_mlp_adapter False \
    --bf16 True \
    --train_backbone False \
    --save_total_limit 3 \
    --dataloader_drop_last True

echo "Training finished. Checkpoint saved to ${OUTPUT_DIR}"
