# Task 0: TV Val
bash scripts/eval_change.sh \
    "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV" \
    val \
    0,1,2,3

# Task 1: RS
bash scripts/eval_change.sh \
    "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV" \
    RS \
    0,1,2,3

# Task 2: NS
bash scripts/eval_change.sh \
    "/gemini/space/zhaozy/libingyu/SegEarth-R1-main/pretrained_weights/SegEarth-R1-RRSIS-D" \
    "/gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV" \
    NS \
    0,1,2,3