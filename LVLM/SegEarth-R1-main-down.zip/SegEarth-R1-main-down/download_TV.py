from huggingface_hub import snapshot_download

# snapshot_download(
#     repo_id="earth-insights/SegEarth-R1-RRSIS-D",
#     repo_type="model",
#     local_dir="pretrained_weights/SegEarth-R1-RRSIS-D",
#     local_dir_use_symlinks=False
# )

snapshot_download(
    repo_id="susnato/phi-1_5_dev",
    repo_type="model",
    local_dir="pretrained_weights/phi-1_5_dev",
    local_dir_use_symlinks=False
)