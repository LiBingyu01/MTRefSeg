"""
Evaluation script for bi-temporal referring change detection with SegEarth-R1.

Single-GPU usage:
  python segearth_r1/eval_and_test/eval_change.py \
      --model_path /path/to/checkpoint \
      --base_data_path /path/to/change_dataset \
      --data_split val \
      --mask_config segearth_r1/mask_config/maskformer2_swin_base_384_bs16_50ep.yaml \
      --version llava_phi

Multi-GPU usage (via torchrun):
  torchrun --nproc_per_node=4 segearth_r1/eval_and_test/eval_change.py \
      --model_path /path/to/checkpoint \
      --base_data_path /path/to/change_dataset \
      --data_split val \
      --mask_config segearth_r1/mask_config/maskformer2_swin_base_384_bs16_50ep.yaml \
      --version llava_phi
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import cv2
import torch
import numpy as np
from enum import Enum
from tqdm import tqdm
from dataclasses import dataclass, field
from typing import Optional
import transformers
import torch.distributed as dist
from torch.utils.data import DataLoader, DistributedSampler

from eval_dataset.change_val_dataset import ChangeValDataset, ChangeValDataCollector
from segearth_r1.model.builder import load_pretrained_model
from segearth_r1.utils import disable_torch_init
from segearth_r1.mm_utils import get_model_name_from_path
from segearth_r1 import conversation as conversation_lib


# ──────────────────────── metrics helpers ────────────────────────────────────

class Summary(Enum):
    NONE    = 0
    AVERAGE = 1
    SUM     = 2
    COUNT   = 3


class AverageMeter:
    def __init__(self, name, fmt=":f", summary_type=Summary.AVERAGE):
        self.name = name
        self.fmt  = fmt
        self.summary_type = summary_type
        self.reset()

    def reset(self):
        self.val = self.avg = self.sum = self.count = 0

    def update(self, val, n=1):
        self.val    = val
        self.sum   += val * n
        self.count += n
        self.avg    = self.sum / self.count

    def all_reduce(self):
        device = "cuda" if torch.cuda.is_available() else "cpu"
        if isinstance(self.sum, np.ndarray):
            total = torch.tensor(
                self.sum.tolist() + [self.count],
                dtype=torch.float32, device=device,
            )
        else:
            total = torch.tensor(
                [self.sum, self.count], dtype=torch.float32, device=device,
            )
        dist.all_reduce(total, dist.ReduceOp.SUM, async_op=False)
        if total.shape[0] > 2:
            self.sum, self.count = total[:-1].cpu().numpy(), total[-1].cpu().item()
        else:
            self.sum, self.count = total.tolist()
        self.avg = self.sum / (self.count + 1e-5)

    def summary(self):
        if self.summary_type is Summary.AVERAGE:
            return f"{self.name} {self.avg:.3f}"
        if self.summary_type is Summary.SUM:
            return f"{self.name} {self.sum:.3f}"
        return ""


def intersectionAndUnionGPU(output, target, K, ignore_index=255):
    assert output.dim() in [1, 2, 3]
    assert output.shape == target.shape
    output = output.view(-1)
    target = target.view(-1)
    output[target == ignore_index] = ignore_index
    intersection = output[output == target]
    area_intersection = torch.histc(intersection.float(), bins=K, min=0, max=K - 1)
    area_output       = torch.histc(output.float(),       bins=K, min=0, max=K - 1)
    area_target       = torch.histc(target.float(),       bins=K, min=0, max=K - 1)
    area_union = area_output + area_target - area_intersection
    return area_intersection, area_union, area_target


def compute_metric(intersection_meter, union_meter, acc_iou_meter,
                   pr_meters, cur_res, gt):
    thresholds = [0.5, 0.6, 0.7, 0.8, 0.9]
    for i, result in enumerate(cur_res):
        gt_mask    = gt[i].squeeze(0).int().cuda().contiguous()
        pred_masks = result["pred_masks"].int().cuda().contiguous()

        if result["scores"] is not None:
            scores  = result["scores"]
            top_idx = torch.topk(scores, 1).indices.cpu().numpy()
            preds_to_eval = pred_masks[top_idx, :]
        else:
            preds_to_eval = [pred_masks] if pred_masks.dim() == 2 \
                            else [pred_masks[0]]

        max_acc_iou = -1
        best_iou = best_intersection = best_union = None

        for pred in preds_to_eval:
            inter, union, _ = intersectionAndUnionGPU(pred, gt_mask, 2, ignore_index=255)
            inter, union = inter.cpu().numpy(), union.cpu().numpy()
            acc_iou = inter / (union + 1e-5)
            acc_iou[union == 0] = 1.0
            fg_iou = acc_iou[1]
            if fg_iou > max_acc_iou:
                max_acc_iou  = fg_iou
                best_iou     = acc_iou
                best_intersection = inter
                best_union   = union

        intersection_meter.update(best_intersection)
        union_meter.update(best_union)
        acc_iou_meter.update(best_iou, n=1)
        for thr in thresholds:
            pr_meters[thr].update(1.0 if best_iou[1] > thr else 0.0, n=1)


# ────────────────────────── argument dataclass ───────────────────────────────

@dataclass
class EvalArgs:
    model_path:            str = field(default="/path/to/model")
    base_data_path:        str = field(default="/path/to/change_dataset")
    mask_config:           str = field(
        default="./segearth_r1/mask_config/maskformer2_swin_base_384_bs16_50ep.yaml")
    version:               str = field(default="llava_phi")
    data_split:            str = field(default="val")
    image_size:            int = field(default=1024)
    eval_batch_size:       int = field(default=4)
    dataloader_num_workers:int = field(default=4)
    use_seg_query:        bool = field(default=False)
    vis_path:    Optional[str] = field(default=None)
    model_map_name:        str = field(default="segearth_r1")


# ──────────────────────────── evaluation ─────────────────────────────────────
def evaluation():
    parser = transformers.HfArgumentParser(EvalArgs)
    args = parser.parse_args_into_dataclasses()[0]

    # ── distributed setup ────────────────────────────────────────────────────
    local_rank = int(os.environ.get("LOCAL_RANK", -1))
    distributed = local_rank >= 0
    if distributed:
        torch.cuda.set_device(local_rank)
        dist.init_process_group(backend="nccl")
        rank = dist.get_rank()
        world_size = dist.get_world_size()
    else:
        rank = 0
        world_size = 1

    disable_torch_init()
    model_name = get_model_name_from_path(args.model_path)
    if rank == 0:
        print(f"Model: {args.model_path}")

    device = f"cuda:{local_rank}" if distributed else "cuda"

    tokenizer, model, context_len = load_pretrained_model(
        args.model_path,
        None,
        model_name,
        model_args=args,
        mask_config=args.mask_config,
        use_seg_query=args.use_seg_query,
        device=device,
    )
    conversation_lib.default_conversation = conversation_lib.conv_templates[args.version]

    dataset = ChangeValDataset(
        base_data_path=args.base_data_path,
        tokenizer=tokenizer,
        split=args.data_split,
        image_size=args.image_size,
    )
    collator = ChangeValDataCollector(tokenizer=tokenizer)

    if distributed:
        sampler = DistributedSampler(dataset, shuffle=False)
        dataloader = DataLoader(
            dataset,
            batch_size=args.eval_batch_size,
            sampler=sampler,
            collate_fn=collator,
            num_workers=args.dataloader_num_workers,
            pin_memory=True,
        )
    else:
        dataloader = DataLoader(
            dataset,
            batch_size=args.eval_batch_size,
            collate_fn=collator,
            num_workers=args.dataloader_num_workers,
            pin_memory=True,
        )

    model.to(device=device, dtype=torch.float).eval()

    # ── new metrics: mIoU / overall IoU / Precision@k ───────────────────────
    eval_seg_iou_list = [0.5, 0.6, 0.7, 0.8, 0.9]

    # 用 tensor 方便 distributed all_reduce
    seg_correct = torch.zeros(len(eval_seg_iou_list), device=device, dtype=torch.float64)
    seg_total = torch.zeros(1, device=device, dtype=torch.float64)

    sum_iou = torch.zeros(1, device=device, dtype=torch.float64)   # for mIoU
    cum_I = torch.zeros(1, device=device, dtype=torch.float64)     # for overall IoU
    cum_U = torch.zeros(1, device=device, dtype=torch.float64)

    if rank == 0 and args.vis_path is not None:
        os.makedirs(args.vis_path, exist_ok=True)

    with torch.no_grad():
        for inputs in tqdm(
            dataloader,
            desc=f"Eval [{args.data_split}]",
            disable=(rank != 0),
        ):
            gt = inputs.pop("masks")  # expected shape: [B,1,H,W] or [B,H,W]

            # Move tensors to device
            for k in list(inputs.keys()):
                if torch.is_tensor(inputs[k]):
                    inputs[k] = inputs[k].to(device)
            gt = gt.to(device)

            if "token_refer_id" in inputs:
                inputs["token_refer_id"] = [ids.to(device) for ids in inputs["token_refer_id"]]

            outputs = model.eval_seg(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                images=inputs["images"].float(),
                images_t2=inputs["images_t2"].float(),
                masks=gt,
                token_refer_id=inputs.get("token_refer_id"),
                refer_embedding_indices=inputs.get("refer_embedding_indices"),
                labels=inputs.get("labels"),
                token_answer_id=None,
                answer_embedding_indices=None,
            )

            # ── collect pred masks to [B,H,W] ────────────────────────────────
            pred_masks = []
            for j in range(len(outputs)):
                pred_mask = outputs[j]["pred_masks"]
                # 常见情况: [1,H,W] / [H,W]
                if pred_mask.dim() > 2:
                    pred_mask = pred_mask[0]
                pred_masks.append(pred_mask)

            pred_masks = torch.stack(pred_masks, dim=0).float()  # [B,H,W]

            # GT -> [B,H,W]
            if gt.dim() == 4 and gt.shape[1] == 1:
                gt_masks = gt.squeeze(1).float()
            elif gt.dim() == 3:
                gt_masks = gt.float()
            else:
                raise ValueError(f"Unexpected gt shape: {gt.shape}")

            # 如果 pred 已经是概率图 [0,1]，则直接用；否则走 sigmoid
            if pred_masks.min() >= 0 and pred_masks.max() <= 1:
                pred_prob = pred_masks
            else:
                pred_prob = torch.sigmoid(pred_masks)

            pred_bin = (pred_prob > 0.5).float()
            gt_bin = (gt_masks > 0.5).float()

            batch_size = pred_bin.shape[0]
            pred_flat = pred_bin.reshape(batch_size, -1)
            gt_flat = gt_bin.reshape(batch_size, -1)

            # foreground IoU
            intersection_tensor = (pred_flat * gt_flat).sum(dim=1)
            union_tensor = pred_flat.sum(dim=1) + gt_flat.sum(dim=1) - intersection_tensor
            iou_tensor = intersection_tensor / (union_tensor + 1e-6)

            # accumulate
            cum_I += intersection_tensor.sum().double()
            cum_U += union_tensor.sum().double()
            sum_iou += iou_tensor.sum().double()
            seg_total += batch_size

            for idx, thr in enumerate(eval_seg_iou_list):
                seg_correct[idx] += (iou_tensor >= thr).sum().double()

            # ── optional visualization (rank 0 only) ────────────────────────
            if rank == 0 and args.vis_path is not None:
                for j, img_name in enumerate(inputs.get("image_name", [])):
                    gt_mask_vis = (gt_bin[j] * 255).detach().cpu().numpy().astype(np.uint8)
                    pred_mask_vis = (pred_bin[j] * 255).detach().cpu().numpy().astype(np.uint8)

                    cv2.imwrite(
                        os.path.join(args.vis_path, f"{img_name}_gt.png"),
                        gt_mask_vis,
                    )
                    cv2.imwrite(
                        os.path.join(args.vis_path, f"{img_name}_pred.png"),
                        pred_mask_vis,
                    )

    # ── aggregate metrics across all ranks ───────────────────────────────────
    if distributed:
        dist.all_reduce(seg_correct, op=dist.ReduceOp.SUM)
        dist.all_reduce(seg_total, op=dist.ReduceOp.SUM)
        dist.all_reduce(sum_iou, op=dist.ReduceOp.SUM)
        dist.all_reduce(cum_I, op=dist.ReduceOp.SUM)
        dist.all_reduce(cum_U, op=dist.ReduceOp.SUM)

    if rank == 0:
        total_samples = int(seg_total.item())

        if total_samples == 0:
            print(
                f"\n[WARNING] No samples were evaluated for split '{args.data_split}'. "
                "Please check --base_data_path and --data_split."
            )
            if distributed:
                dist.destroy_process_group()
            return 0.0, 0.0

        mIoU = (sum_iou / seg_total).item() if total_samples > 0 else 0.0
        overall_IoU = (cum_I / (cum_U + 1e-6)).item() if cum_U.item() > 0 else 0.0

        print("\n" + "=" * 40)
        print(f"Evaluation Results [{args.data_split}]")
        print("=" * 40)
        print(f"Mean IoU (mIoU):    {mIoU * 100:.2f}")
        print(f"Overall IoU (oIoU): {overall_IoU * 100:.2f}")
        print("-" * 40)

        for idx, thr in enumerate(eval_seg_iou_list):
            precision_k = (seg_correct[idx] / seg_total).item() if total_samples > 0 else 0.0
            print(f"Precision @ {thr:.1f}: {precision_k * 100:.2f}%")

        print("=" * 40 + "\n")

    if distributed:
        dist.destroy_process_group()

    return (mIoU * 100.0, overall_IoU * 100.0) if rank == 0 else (0.0, 0.0)


if __name__ == "__main__":
    ss = evaluation()
    print(f"result_{ss}")
