CUDA_VISIBLE_DEVICES=1 python vis_result.py \
    --model lavt \
    --swin_type base \
    --refer_data_root /gemini/space/zhaozy/libingyu/ChangeRef_datasets/TV \
    --split val \
    --resume output/change_ref/model_save/rrsis-main-down-LGCE_trainval.pth \
    --window12 \
    --output_dir ./vis_output