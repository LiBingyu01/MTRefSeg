from collections import OrderedDict
import sys
import torch
from torch import nn
from torch.nn import functional as F
from bert.modeling_bert import BertModel
from einops import rearrange, repeat


class BiTemporalLAVT(nn.Module):
    def __init__(self, backbone, classifier):
        super().__init__()
        self.backbone = backbone
        self.classifier = classifier

    def forward(self, img_A, img_B, l_feats, l_mask):
        """
        Args:
            img_A: T1时刻图像 [B, 3, H, W]
            img_B: T2时刻图像 [B, 3, H, W]
            l_feats: 语言特征 (BERT output) [B, L, C]
            l_mask: 语言mask [B, L]
        """
        input_shape = img_A.shape[-2:]
        # 1. 孪生骨干网络 (Siamese Backbone)
        # 共享权重，分别提取特征。Backbone 内部会融合语言特征 l_feats
        # Swin 输出特征层级通常是从小到大 [c1, c2, c3, c4]
        features_A = self.backbone(img_A, l_feats, l_mask) 
        features_B = self.backbone(img_B, l_feats, l_mask) 

        # 2. 特征差分融合 (Feature Difference)
        x_c1 = torch.cat([features_A[0], features_B[0]], dim=1)
        x_c2 = torch.cat([features_A[1], features_B[1]], dim=1)
        x_c3 = torch.cat([features_A[2], features_B[2]], dim=1)
        x_c4 = torch.cat([features_A[3], features_B[3]], dim=1)
        
        # SimpleDecoding
        output = self.classifier(x_c4, x_c3, x_c2, x_c1, l_feats)
        output = F.interpolate(output, size=input_shape, mode='bilinear', align_corners=True)
        return output
    
class _LAVTSimpleDecode(nn.Module):
    def __init__(self, backbone, classifier):
        super(_LAVTSimpleDecode, self).__init__()
        self.backbone = backbone
        self.classifier = classifier
        #self.gtoken = torch.nn.Parameter(torch.randn([1,768,20]))
        #self.gtoken = torch.nn.Parameter(torch.ones([1,768,20]))

    def forward(self, x, l_feats, l_mask):
        input_shape = x.shape[-2:]
        features = self.backbone(x, l_feats, l_mask)
        x_c1, x_c2, x_c3, x_c4 = features
        B = x.shape[0]
        #gtoken = repeat(self.gtoken, '1 c d -> b c d', b = B)
        gtoken = l_feats
        x = self.classifier(x_c4, x_c3, x_c2, x_c1, gtoken)
        x = F.interpolate(x, size=input_shape, mode='bilinear', align_corners=True)

        return x


class LAVT(_LAVTSimpleDecode):
    pass


###############################################
# LAVT One: put BERT inside the overall model #
###############################################
class _LAVTOneSimpleDecode(nn.Module):
    def __init__(self, backbone, classifier, args):
        super(_LAVTOneSimpleDecode, self).__init__()
        self.backbone = backbone
        self.classifier = classifier
        self.text_encoder = BertModel.from_pretrained(args.ck_bert)
        self.text_encoder.pooler = None
        #self.gtoken = torch.Parameter(torch.randn(l_feats.shape))

    def forward(self, x, text, l_mask):
        input_shape = x.shape[-2:]
        ### language inference ###
        l_feats = self.text_encoder(text, attention_mask=l_mask)[0]  # (6, 10, 768)
        l_feats = l_feats.permute(0, 2, 1)  # (B, 768, N_l) to make Conv1d happy
        l_mask = l_mask.unsqueeze(dim=-1)  # (batch, N_l, 1)
        ##########################
        features = self.backbone(x, l_feats, l_mask)
        x_c1, x_c2, x_c3, x_c4 = features
        x = self.classifier(x_c4, x_c3, x_c2, x_c1, l_feats)
        x = F.interpolate(x, size=input_shape, mode='bilinear', align_corners=True)

        return x


class LAVTOne(_LAVTOneSimpleDecode):
    pass
