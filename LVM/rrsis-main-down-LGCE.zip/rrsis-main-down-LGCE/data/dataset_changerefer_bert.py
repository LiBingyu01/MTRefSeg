import os
import json
import torch
import torch.utils.data as data
from PIL import Image, ImageOps
import numpy as np
import random
from bert.tokenization_bert import BertTokenizer

class ChangeReferDataset(data.Dataset):
    def __init__(self,
                 args,
                 image_transforms=None,
                 target_transforms=None,
                 split='train',
                 eval_mode=False,
                 cache_images=False): # 新增：缓存开关

        self.classes = []
        self.image_transforms = image_transforms
        self.target_transform = target_transforms
        self.split = split
        self.max_tokens = 20
        self.eval_mode = eval_mode
        self.cache_images = cache_images # 是否开启内存缓存
        self.cache = {} # 缓存字典

        self.root = os.path.join(args.refer_data_root, split)
        self.dir_A = os.path.join(self.root, 'A')
        self.dir_B = os.path.join(self.root, 'B')
        self.dir_mask = os.path.join(self.root, 'masks')
        self.dir_json = os.path.join(self.root, 'referring_expression')

        print(f"Dataset root: {self.root}")
        if not os.path.exists(self.dir_json):
            raise ValueError(f"Directory not found: {self.dir_json}")

        self.tokenizer = BertTokenizer.from_pretrained(args.bert_tokenizer)

        self.dataset_samples = []
        # 优化：如果是超大数据集，listdir可能会慢，但通常这里还好
        json_files = sorted([f for f in os.listdir(self.dir_json) if f.endswith('.json')])

        print(f"Loading {split} dataset info...")
        
        # 预处理：将所有元数据加载到内存
        for j_file in json_files:
            file_id = os.path.splitext(j_file)[0]
            with open(os.path.join(self.dir_json, j_file), 'r') as f:
                data_info = json.load(f)

            expressions = data_info['referring_expressions']
            masks_info = data_info.get('mask', [])
            
            for idx, sent_raw in enumerate(expressions):
                # Tokenization 放在 init 里是极好的做法，保持不变
                input_ids = self.tokenizer.encode(text=sent_raw, add_special_tokens=True)
                input_ids = input_ids[:self.max_tokens]
                padded_input_ids = [0] * self.max_tokens
                attention_mask = [0] * self.max_tokens
                padded_input_ids[:len(input_ids)] = input_ids
                attention_mask[:len(input_ids)] = [1] * len(input_ids)

                mask_subpath = masks_info[idx]['path']
                
                # 预先构建好完整的路径，减少 getitem 中的字符串操作
                img_A_path = os.path.join(self.dir_A, f"{file_id}.jpg") # 假设是 jpg
                img_B_path = os.path.join(self.dir_B, f"{file_id}.jpg")
                mask_path_full = os.path.join(self.dir_mask, mask_subpath)

                self.dataset_samples.append({
                    'img_A_path': img_A_path,
                    'img_B_path': img_B_path,
                    'mask_path': mask_path_full,
                    'input_ids': torch.tensor(padded_input_ids, dtype=torch.long), # 明确 dtype
                    'attention_mask': torch.tensor(attention_mask, dtype=torch.long),
                    # 'sent_raw': sent_raw # 如果训练不需要原始文本，可以注释掉以节省内存
                })

        print(f"Total samples in {split}: {len(self.dataset_samples)}")

    def __len__(self):
        return len(self.dataset_samples)

    def _load_image(self, path, mode="RGB"):
        """辅助函数：处理读取和缓存"""
        if self.cache_images and path in self.cache:
            return self.cache[path].copy() # 返回副本以防 transform 修改原图
        
        try:
            img = Image.open(path).convert(mode)
            if self.cache_images:
                self.cache[path] = img.copy() # 存入缓存
            return img
        except Exception:
            # 处理文件不存在的情况，生成全黑图
            # 注意：这里需要知道图片尺寸，若文件损坏可能需要默认尺寸
            # 简单起见，这里抛出异常或返回 None 由上层处理
            return None

    def __getitem__(self, index):
        sample = self.dataset_samples[index]

        # 1. 优化 I/O：使用 try-except 代替 os.path.exists
        # 读取 A 和 B
        img_A = self._load_image(sample['img_A_path'])
        img_B = self._load_image(sample['img_B_path'])
        
        # 容错处理：如果 A 或 B 读取失败（极其罕见），生成一个空的
        if img_A is None: img_A = Image.new('RGB', (256, 256))
        if img_B is None: img_B = Image.new('RGB', (256, 256))

        # 读取 Mask
        try:
            if self.cache_images and sample['mask_path'] in self.cache:
                mask = self.cache[sample['mask_path']].copy()
            else:
                mask = Image.open(sample['mask_path']).convert("L")
                if self.cache_images:
                    self.cache[sample['mask_path']] = mask.copy()
        except FileNotFoundError:
            # 如果 mask 文件确实不存在
            mask = Image.new('L', img_A.size, 0)

        # 2. 优化计算：使用 PIL 原生 point 方法代替 Numpy 转换
        # 这比 np.array -> indexing -> Image.fromarray 快得多
        # 将大于0的像素设为1，其余为0
        target = mask.point(lambda p: 1 if p > 0 else 0, mode='L')

        # 3. 增强同步 (保持原有逻辑，但代码更紧凑)
        if self.image_transforms is not None:
            # 生成一个种子，确保 A、B、Mask 的 RandomCrop/Flip 等行为一致
            seed = np.random.randint(2147483647) 
            
            # 对 A 和 Target 做变换
            random.seed(seed)
            torch.manual_seed(seed)
            # torch.cuda.manual_seed(seed) # 一般 transform 运行在 CPU，这行通常不需要，除非 transforms 涉及 GPU 操作
            img_A, target = self.image_transforms(img_A, target)
            
            # 对 B 做变换 (不需要 mask)
            random.seed(seed)
            torch.manual_seed(seed)
            img_B, _ = self.image_transforms(img_B, target) 

        tensor_embeddings = sample['input_ids']
        attention_mask = sample['attention_mask']

        return img_A, img_B, target, tensor_embeddings, attention_mask