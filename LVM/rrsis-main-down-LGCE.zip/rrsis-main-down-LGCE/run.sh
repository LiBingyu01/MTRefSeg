# mkdir ./output
# mkdir ./output/change_ref

# CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python -m torch.distributed.launch --nproc_per_node 8 --master_port 12345 train.py \
#                     --dataset change_ref \
#                     --batch-size 16 \
#                     --lr 0.00005 \
#                     --wd 1e-2 \
#                     --swin_type base \
#                     --pretrained_swin_weights ./pretrained_weights/swin_base_patch4_window12_384_22k.pth \
#                     --epochs 10 \
#                     --output_dir ./output/change_ref/model_save \
#                     --resume output/change_ref/model_save/model_best_lavt.pth \
#                     --img_size 480 2>&1 | tee ./output/change_ref/train_print

# NS --> RS               
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python -m torch.distributed.launch --nproc_per_node 8 --master_port 12345 train_NS_RS.py \
                    --dataset change_ref \
                    --batch-size 16 \
                    --lr 0.00005 \
                    --wd 1e-2 \
                    --swin_type base \
                    --pretrained_swin_weights ./pretrained_weights/swin_base_patch4_window12_384_22k.pth \
                    --epochs 10 \
                    --output_dir ./output/change_ref_ns_rs/model_save \
                    --resume output/change_ref_ns_rs/model_save/model_best_lavt.pth \
                    --pin_mem \
                    --img_size 480 2>&1 | tee ./output/change_ref_ns_rs/train_print

# RS --> NS  
# CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python -m torch.distributed.launch --nproc_per_node 8 --master_port 12345 train_RS_NS.py \
#                     --dataset change_ref \
#                     --batch-size 16 \
#                     --lr 0.00005 \
#                     --wd 1e-2 \
#                     --swin_type base \
#                     --pretrained_swin_weights ./pretrained_weights/swin_base_patch4_window12_384_22k.pth \
#                     --epochs 10 \
#                     --output_dir ./output/change_ref_rs_ns/model_save \
#                     --resume output/change_ref_rs_ns/model_save/model_best_lavt.pth \
#                     --img_size 480 2>&1 | tee ./output/change_ref_rs_ns/train_print