"""
RRSIS 可视化脚本 —— 输出格式与 GSVA batch_chat_visualize.py 一致

输出结构 (每个样本):
    vis_test/{sample_name}/
        00_{expr_slug}_pred_mask.png          # 二值预测 mask (0/255)
        00_{expr_slug}_pred_overlay_A.png     # 预测叠加在 T1 (红色)
        00_{expr_slug}_pred_overlay_B.png     # 预测叠加在 T2 (红色)
        00_{expr_slug}_gt_mask.png            # 二值 GT mask (0/255)
        00_{expr_slug}_gt_overlay_A.png       # GT 叠加在 T1 (绿色)
        00_{expr_slug}_gt_overlay_B.png       # GT 叠加在 T2 (绿色)
        00_{expr_slug}_canvas.jpg             # 拼接大图 (带标注)
        00_{expr_slug}_meta.txt               # 元信息文件

用法:
    python vis_result.py \
        --model lavt \
        --swin_type base \
        --dataset changerefer \
        --split test \
        --resume output/model_best.pth \
        --window12 \
        --img_size 480 \
        --output_dir ./vis_output \
        --max_vis 500
"""

import argparse
import datetime
import os
import re
import time
import warnings

import cv2
import numpy as np
import torch
import torch.utils.data
from tqdm import tqdm

import transforms as T
from bert.modeling_bert import BertModel
from lib import segmentation

warnings.filterwarnings("ignore")
cv2.setNumThreads(0)

# ============================================================================
# 参数解析
# ============================================================================

def get_parser():
    from args import get_parser as _base_parser
    parser = _base_parser()

    parser.set_defaults(output_dir='./vis_output')

    parser.add_argument('--max_vis', default=5000, type=int,
                        help='Maximum number of samples to visualize')

    parser.set_defaults(save_gt=True, save_canvas=True)
    parser.add_argument('--no_save_gt', dest='save_gt', action='store_false')
    parser.add_argument('--no_save_canvas', dest='save_canvas', action='store_false')

    return parser


# ============================================================================
# 数据集加载
# ============================================================================

def get_transform(args):
    transforms = [
        T.Resize(args.img_size, args.img_size),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ]
    return T.Compose(transforms)


def get_dataset(image_set, transform, args):
    """加载 ChangeRefer 双时相数据集"""
    from data.dataset_changerefer_bert import ChangeReferDataset
    ds = ChangeReferDataset(
        args,
        split=image_set,
        image_transforms=transform,
        target_transforms=None,
        eval_mode=True,
    )
    return ds


# ============================================================================
# 模型加载
# ============================================================================

def load_model(args):
    """构建并加载 RRSIS 模型和 BERT 模型"""
    device = torch.device(args.device)

    print(f"Building model: {args.model}")
    single_model = segmentation.__dict__[args.model](pretrained='', args=args)

    checkpoint = torch.load(args.resume, map_location='cpu', weights_only=False)
    single_model.load_state_dict(checkpoint['model'], strict=False)
    model = single_model.to(device)
    print(f"Loaded checkpoint from: {args.resume}")

    if args.model != 'lavt_one':
        model_class = BertModel
        single_bert_model = model_class.from_pretrained(args.ck_bert)
        # 训练时 pooler 通常被去掉，checkpoint 中不包含 pooler 权重
        # 先置空 pooler，再用 strict=False 加载，避免 key mismatch
        single_bert_model.pooler = None
        single_bert_model.load_state_dict(checkpoint['bert_model'], strict=False)
        bert_model = single_bert_model.to(device)
    else:
        bert_model = None

    model.eval()
    if bert_model is not None:
        bert_model.eval()

    return model, bert_model, device


# ============================================================================
# 模型推理
# ============================================================================

def model_inference(model, bert_model, img_A, img_B, sentences, attentions):
    """
    执行模型前向推理，返回预测 mask (numpy, uint8, {0,1})。

    RRSIS 输出: [B, 2, H, W] logits → argmax(dim=1) → binary mask
    """
    if bert_model is not None:
        last_hidden_states = bert_model(sentences, attention_mask=attentions)[0]
        embedding = last_hidden_states.permute(0, 2, 1)
        output = model(img_A, img_B, embedding, l_mask=attentions.unsqueeze(dim=-1))
    else:
        output = model(img_A, img_B, sentences, attentions)

    # [B, 2, H, W] -> [B, H, W] (argmax over class dim)
    output_mask = output.cpu().argmax(1).data.numpy()  # shape: [B, H, W]
    return output_mask


# ============================================================================
# tensor → RGB numpy 图像 (反归一化)
# ============================================================================

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406])
IMAGENET_STD = np.array([0.229, 0.224, 0.225])


def tensor_to_rgb(img_tensor):
    """
    将 ImageNet 归一化后的 tensor [B,3,H,W] or [3,H,W]
    还原为 RGB uint8 numpy [H,W,3]
    """
    if img_tensor.dim() == 4:
        img_tensor = img_tensor[0]
    img = img_tensor.detach().cpu().float().numpy()   # [3,H,W]
    img = np.transpose(img, (1, 2, 0))                # [H,W,3]
    # 反 normalize
    img = img * IMAGENET_STD + IMAGENET_MEAN
    img = (img * 255.0).clip(0, 255).astype(np.uint8)
    return img


# ============================================================================
# GSVA-style visualization helpers
# ============================================================================

def safe_name(text, max_len=120):
    """将表达式文本转换为安全的文件名"""
    text = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff._-]+", "_", text)
    text = text.strip("_")
    if not text:
        text = "expr"
    return text[:max_len]


def overlay_mask(image_rgb, mask, color=(255, 0, 0), alpha=0.5):
    """在 RGB 图像上叠加彩色半透明 mask"""
    out = image_rgb.copy()
    if mask.dtype != np.bool_:
        mask = mask.astype(bool)
    color_arr = np.array(color, dtype=np.float32)
    out_f = out.astype(np.float32)
    out_f[mask] = out_f[mask] * (1 - alpha) + color_arr * alpha
    return out_f.astype(np.uint8)


def put_caption(image_rgb, text):
    """在图像左上角添加文字标注"""
    canvas = image_rgb.copy()
    lines = []
    words = text.split(" ")
    cur = ""
    for w in words:
        nxt = w if not cur else cur + " " + w
        if len(nxt) > 42:
            if cur:
                lines.append(cur)
            cur = w
        else:
            cur = nxt
    if cur:
        lines.append(cur)

    y = 24
    for line in lines[:4]:
        cv2.putText(
            canvas, line, (10, y),
            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA,
        )
        cv2.putText(
            canvas, line, (10, y),
            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1, cv2.LINE_AA,
        )
        y += 24
    return canvas


def normalize_expr(expr):
    return expr.strip().lower()


def infer_vis_mode(expr):
    """
    根据表达式内容推断可视化模式:
    'A'  -> 仅在 T1 上叠加 (消失类)
    'B'  -> 仅在 T2 上叠加 (出现类)
    'AB' -> 同时在 T1/T2 上叠加 (变化类)
    """
    e = normalize_expr(expr)

    disappear_keywords = [
        "disappear", "disappeared", "disappearing", "vanish", "vanished",
        "removed", "demolished", "gone", "lost", "deleted", "missing",
        "消失", "拆除", "去掉", "移除", "不见"
    ]
    appear_keywords = [
        "appear", "appeared", "appearing", "added", "new", "newly",
        "emerged", "built", "constructed", "出现", "新增", "新建"
    ]
    change_keywords = [
        "change", "changed", "changing", "became", "become", "turned",
        "repaved", "repainted", "converted", "transformed", "modified",
        "increased", "decreased", "expanded", "shrunk", "color", "colour",
        "状态改变", "变成", "变为", "改变", "变化", "颜色"
    ]

    has_disappear = any(k in e for k in disappear_keywords)
    has_appear = any(k in e for k in appear_keywords)
    has_change = any(k in e for k in change_keywords)

    if has_disappear and not has_appear and not has_change:
        return "A"
    if has_appear and not has_disappear and not has_change:
        return "B"
    if has_change or (has_disappear and has_appear):
        return "AB"
    return "AB"


def build_overlay_items(vis_mode, image_rgb_t1, image_rgb_t2, mask, color=(255, 0, 0)):
    """根据 vis_mode 构建 overlay 列表"""
    items = []
    if vis_mode in ("A", "AB"):
        items.append(("_A", overlay_mask(image_rgb_t1, mask, color=color, alpha=0.5), "on A/T1"))
    if vis_mode in ("B", "AB"):
        items.append(("_B", overlay_mask(image_rgb_t2, mask, color=color, alpha=0.5), "on B/T2"))
    return items


def save_canvas_dynamic(items, save_path):
    """将多个 (image_rgb, caption) 拼接成一张大图保存"""
    panels = [put_caption(img, cap) for img, cap in items]
    canvas = np.concatenate(panels, axis=1)
    cv2.imwrite(save_path, cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR))


# ============================================================================
# IoU / Precision 计算
# ============================================================================

def compute_iou_and_prec(pred_mask, gt_mask):
    pred = pred_mask.astype(bool)
    gt = gt_mask.astype(bool)

    inter = np.logical_and(pred, gt).sum()
    union = np.logical_or(pred, gt).sum()
    iou = float(inter) / float(union + 1e-6)

    prec_dict = {}
    for thr in [0.5, 0.6, 0.7, 0.8, 0.9]:
        prec_dict[f'Pr@{thr:.1f}'] = 1.0 if iou >= thr else 0.0
    return iou, prec_dict


# ============================================================================
# GSVA 格式保存
# ============================================================================

def save_visualization_gsva_format(
    imgA_rgb, imgB_rgb, pred_mask, gt_mask,
    sample_out_dir, expr_idx, expr_str,
    img_path_A="", img_path_B="",
    save_gt=True, save_canvas=True,
):
    """
    按照 GSVA batch_chat_visualize.py 的格式保存可视化结果:
    - {prefix}_pred_mask.png          : 二值预测 mask (0/255)
    - {prefix}_pred_overlay_A.png     : 预测 mask 叠加在 T1 上 (红色)
    - {prefix}_pred_overlay_B.png     : 预测 mask 叠加在 T2 上 (红色)
    - {prefix}_gt_mask.png            : 二值 GT mask (0/255)
    - {prefix}_gt_overlay_A.png       : GT mask 叠加在 T1 上 (绿色)
    - {prefix}_gt_overlay_B.png       : GT mask 叠加在 T2 上 (绿色)
    - {prefix}_canvas.jpg             : 拼接大图 (带标注)
    - {prefix}_meta.txt               : 元信息文件
    """
    os.makedirs(sample_out_dir, exist_ok=True)

    expr_slug = safe_name(expr_str)
    expr_prefix = os.path.join(sample_out_dir, f"{expr_idx:02d}_{expr_slug}")

    h, w = imgA_rgb.shape[:2]

    # 确保 pred_mask 尺寸一致
    if pred_mask.shape[:2] != (h, w):
        pred_mask = cv2.resize(pred_mask.astype(np.uint8), (w, h),
                               interpolation=cv2.INTER_NEAREST)
        pred_mask = (pred_mask > 0).astype(np.uint8)

    # ---- vis_mode ----
    vis_mode = infer_vis_mode(expr_str)

    # ---- 保存 meta 文件 ----
    with open(expr_prefix + "_meta.txt", "w", encoding="utf-8") as fw:
        fw.write(f"img_A: {img_path_A}\n")
        fw.write(f"img_B: {img_path_B}\n")
        fw.write(f"expression: {expr_str}\n")
        fw.write(f"visualization_mode: {vis_mode}\n")

    # ---- 保存 pred mask ----
    cv2.imwrite(expr_prefix + "_pred_mask.png", pred_mask * 255)

    # ---- 保存 pred overlay ----
    pred_overlay_items = build_overlay_items(
        vis_mode, imgA_rgb, imgB_rgb, pred_mask, color=(255, 0, 0))
    for suffix, overlay_rgb, _ in pred_overlay_items:
        cv2.imwrite(
            expr_prefix + f"_pred_overlay{suffix}.png",
            cv2.cvtColor(overlay_rgb, cv2.COLOR_RGB2BGR),
        )

    # ---- 保存 GT mask + overlay ----
    gt_overlay_items = []
    if save_gt and gt_mask is not None:
        # 确保 gt_mask 尺寸一致
        if gt_mask.shape[:2] != (h, w):
            gt_mask = cv2.resize(gt_mask.astype(np.uint8), (w, h),
                                 interpolation=cv2.INTER_NEAREST)
            gt_mask = (gt_mask > 0).astype(np.uint8)

        cv2.imwrite(expr_prefix + "_gt_mask.png", gt_mask.astype(np.uint8) * 255)
        gt_overlay_items = build_overlay_items(
            vis_mode, imgA_rgb, imgB_rgb, gt_mask, color=(0, 255, 0))
        for suffix, overlay_rgb, _ in gt_overlay_items:
            cv2.imwrite(
                expr_prefix + f"_gt_overlay{suffix}.png",
                cv2.cvtColor(overlay_rgb, cv2.COLOR_RGB2BGR),
            )

    # ---- 保存 canvas 拼接图 ----
    if save_canvas:
        canvas_items = [(imgA_rgb, "T1 / earlier"), (imgB_rgb, "T2 / later")]
        for _, overlay_rgb, title in pred_overlay_items:
            canvas_items.append((overlay_rgb, f"Pred {title} | {expr_str}"))
        for _, overlay_rgb, title in gt_overlay_items:
            canvas_items.append((overlay_rgb, f"GT {title}"))
        save_canvas_dynamic(canvas_items, expr_prefix + "_canvas.jpg")

    return expr_prefix


# ============================================================================
# 主流程
# ============================================================================

def main():
    parser = get_parser()
    args = parser.parse_args()

    print(f"Image size: {args.img_size}")
    print(f"Model: {args.model}")
    print(f"Checkpoint: {args.resume}")

    # ---- 创建输出目录 ----
    vis_dir = os.path.join(args.output_dir, "vis_test")
    os.makedirs(vis_dir, exist_ok=True)

    # ---- 加载数据集 ----
    dataset = get_dataset(args.split, get_transform(args), args)
    data_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=1,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=True,
        drop_last=False,
    )
    print(f"Dataset loaded: {len(dataset)} samples")

    # ---- 加载模型 ----
    model, bert_model, device = load_model(args)

    # ---- 统计变量 ----
    total_iou = 0.0
    total_count = 0
    prec_meter = {f'Pr@{thr:.1f}': 0.0 for thr in [0.5, 0.6, 0.7, 0.8, 0.9]}

    vis_count = 0
    max_vis = args.max_vis

    tbar = tqdm(data_loader, total=len(data_loader), ncols=120, desc="RRSIS Vis")
    start_time = time.time()

    with torch.no_grad():
        for idx, batch in enumerate(tbar):
            # ---- 解包 ChangeReferDataset 返回值 ----
            # (img_A, img_B, target, input_ids, attention_mask)
            img_A, img_B, target, sentences, attentions = batch

            img_A = img_A.to(device)
            img_B = img_B.to(device)
            sentences = sentences.to(device)
            attentions = attentions.to(device)

            # ---- 模型推理 ----
            output_mask = model_inference(
                model, bert_model, img_A, img_B,
                sentences, attentions
            )

            # ---- 获取单样本数据 ----
            pred_mask = output_mask[0].astype(np.uint8)       # [H, W]
            gt_mask = target[0].cpu().numpy().astype(np.uint8) # [H, W]

            # ---- 获取表达式文本 ----
            sample_info = dataset.dataset_samples[idx]

            # 从 JSON 文件中读取原始表达式
            json_path = sample_info.get('img_A_path', '').replace('/A/', '/referring_expression/').replace('.jpg', '.json')
            if os.path.exists(json_path):
                import json
                with open(json_path, 'r') as f:
                    json_data = json.load(f)
                    # 假设每个 JSON 只有一个表达式，或者取第一个
                    expr_str = json_data.get('referring_expressions', [f'sample_{idx:06d}'])[0]
            else:
                expr_str = f'sample_{idx:06d}'

            file_id = os.path.basename(sample_info.get('img_A_path', '')).replace('.jpg', '')

            # ---- 图像路径 (用于 meta) ----
            img_path_A = sample_info.get('img_A_path', '')
            img_path_B = sample_info.get('img_B_path', '')

            # ---- 计算 IoU ----
            if gt_mask.sum() > 0 or pred_mask.sum() > 0:
                cur_iou, cur_prec = compute_iou_and_prec(pred_mask, gt_mask)
                total_iou += cur_iou
                total_count += 1
                for k in prec_meter:
                    prec_meter[k] += cur_prec[k]
                tbar.set_postfix(IoU=f"{total_iou / max(total_count, 1):.4f}")

            # ---- GSVA 格式可视化 ----
            if vis_count < max_vis:
                # tensor → RGB numpy
                imgA_rgb = tensor_to_rgb(img_A)
                imgB_rgb = tensor_to_rgb(img_B)

                # 样本子目录
                sample_name = f"{file_id}_{idx}"
                sample_out_dir = os.path.join(vis_dir, sample_name)

                save_visualization_gsva_format(
                    imgA_rgb=imgA_rgb,
                    imgB_rgb=imgB_rgb,
                    pred_mask=pred_mask,
                    gt_mask=gt_mask,
                    sample_out_dir=sample_out_dir,
                    expr_idx=0,
                    expr_str=expr_str,
                    img_path_A=img_path_A,
                    img_path_B=img_path_B,
                    save_gt=args.save_gt,
                    save_canvas=args.save_canvas,
                )
                vis_count += 1

            if vis_count >= max_vis:
                break

    # ---- 汇总输出 ----
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))

    print(f"\n{'='*60}")
    print(f"Total test time: {total_time_str}")

    if total_count > 0:
        mean_iou = total_iou / total_count
        prec_result = {k: v / total_count for k, v in prec_meter.items()}
        print(f"Mean IoU: {mean_iou:.4f}")
        print("Precision:")
        for k, v in prec_result.items():
            print(f"    {k} = {v:.4f}")
    else:
        print("No valid GT masks found for IoU computation.")

    print(f"\nVisualization saved to: {vis_dir}")
    print(f"Total samples visualized: {vis_count}")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()
